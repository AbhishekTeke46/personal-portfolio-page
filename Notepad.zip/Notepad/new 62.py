import subprocess
import os

def lambda_handler(event, context):
    #os.remove("git-2.14.6-1.62.amzn1.x86_64.rpm")
    os.chdir("/tmp")
    git_rpm_download_url ='http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm'
    install_git = subprocess.check_output(
        ' && '.join([
            #'rm -fr %s' % git_rpm_install_tmp_dir, #remove the directory if it exists previously 
            #'mkdir %s' % git_rpm_install_tmp_dir, #Creation of the directory
            #'cd %s' % git_rpm_install_tmp_dir, #changing path to the directory
            'curl -s -O %s' % git_rpm_download_url, #download git rpm package
            'rpm -K %s' % git_rpm_download_dir,  # Check the GnuPG signature
            'rpm2cpio %s | cpio -id' % git_rpm_download_dir, #Extracting Git package
            #'rm %s' % git_rpm_download_dir #After installation removing the download directory with downloaded package
        ]),
        stderr=subprocess.STDOUT,
        shell=True)
    print(install_git)   
    
    #result = subprocess.check_output([command], stderr=subprocess.STDOUT, shell=True)
    lst = os.listdir("/tmp/")
    print('Tmp file List: ',lst)