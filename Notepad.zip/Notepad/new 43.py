import subprocess
import requests
def curl_request(url):
    
    # Define the command to execute using curl
    command = ['curl', '-s', '-o', '-', url]

    # Execute the curl command and capture the output
    result = subprocess.run(command, capture_output=True, text=True)
    
    # Return the stdout of the curl command
    return result.stdout

# Make a curl request to https://www.google.com/
response = curl_request('http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm')

# Make a curl request to https://www.google.com/
print(response)

-----------------

import urllib3

url ="http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm"
print (url)

http = urllib3.PoolManager()
r = http.request('GET', url)

data1 = r.data
# b'User-agent: *\nDisallow: /deny\n'
Status1 = r.status
# 200

#url ="http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm"
#print (url)
#resp = requests.get(url)
#print (resp.status_code)

def lambda_handler(event, context):
    return Status1
    
-------------

import subprocess
def curl_request(url):
    
    # Define the command to execute using curl
    command = ['curl', '-s', '-o', '-', url]

    # Execute the curl command and capture the output
    result = subprocess.run(command, capture_output=True, text=True)
    
    # Return the stdout of the curl command
    return result.stdout

def lambda_handler(event, context):
    # Make a curl request to https://www.google.com/
    response = curl_request('http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm')

    # Make a curl request to https://www.google.com/
    print(response)

