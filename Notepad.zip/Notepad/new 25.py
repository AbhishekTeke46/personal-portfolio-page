"""cp-gps-AthenaS3-dev python file takes subjectarea, ini_param_df, module as inputs
and executes query in Athena and copies filles to Integartion bucket


Modification Log:
-------------------------------------------------------------------------------
Date                Author             Description
-------------------------------------------------------------------------------
22/06/2021        Navya Nelluri         Initial Release
06/08/2021        V Naga Deekshitha     Moddified to get columns through ini and updated scripts to read credentials through secret manager
26/09/2022        Surjay Boral          Using cross account role to access commerce datalake account instead of using AWS access keys (CPAS-1744)
----------------------------------------------------------------------------------------------
Args:
subjectarea-Retailer for which we need to execute the script
module-method
ini_param_df- ini parameter dataframe which has both common ini and retailer ini parameters


 Processing:
1. It reads input arguments and sets Athena bucket,Athena directory,Target bucket, Target directory and executes query in Athena and copies filles to Integartion bucket.


"""
import boto3
import pandas as pd
import io
import re
import time
import json
import inspect
from awsglue.utils import getResolvedOptions
from utils_int_whl import secret_manager
import sys
import ast 
from botocore.config import Config


def athena_to_s3(ini_param_df):
    region = ini_param_df['ATHENA_REGION']
    bucket_details = ast.literal_eval(ini_param_df['athena_query_to_s3'.upper()])
    athena_database = bucket_details['athena_database']
    athena_bucket = bucket_details['athena_bucket']
    athena_bucket_directory = bucket_details['athena_bucket_directory'].replace('YYYYMMDD',ini_param_df['YYYYMMDD'])
    target_bucket=bucket_details['target_bucket']
    target_directory=bucket_details['target_directory'].replace('YYYYMMDD',ini_param_df['YYYYMMDD'])
    db_objects=ini_param_df['DB_OBJECT']
    db_objects=db_objects.replace('[', '').replace(']', '').split(',')
    #db_objects=['stripe_invoices_lines_v']
    cross_account_role_arn = bucket_details['cross_account_role_arn']
    
    for db_object in db_objects:
        column=ini_param_df['ATHENA_COLUMNS_'+db_object.upper()]
        query= 'select ' +column.replace('"','')+' from ' + db_object +';'
        #query='select * from stripe_invoices_lines_v;'
        print("Executing Query: ",query)
        session = boto3.Session()
        
        sts_client = boto3.client('sts')
        
        assumed_role_object=sts_client.assume_role(
            RoleArn = cross_account_role_arn,
            RoleSessionName = "AssumeRoleSession1"
        )
        
        # From the response that contains the assumed role, get the temporary credentials that can be used to make subsequent API calls
        credentials=assumed_role_object['Credentials']
        
        # Use the temporary credentials that AssumeRole returns 
        try:
            client = session.client('athena', region_name=region,  aws_access_key_id=credentials['AccessKeyId'], 
            aws_secret_access_key=credentials['SecretAccessKey'],aws_session_token=credentials['SessionToken'],config=Config(connect_timeout=5, read_timeout=60, retries={'max_attempts': 20}))
            response = client.start_query_execution(QueryString=query,QueryExecutionContext={'Database':athena_database }, WorkGroup = 'noPIIReportsAthena3', 
            ResultConfiguration={'OutputLocation': 's3://' + athena_bucket + '/' + athena_bucket_directory})
            execution_id = response['QueryExecutionId']
        except Exception as e:
            print("Error executing athena_qquery : {}".format(str(e)))
            raise Exception("Error executing athena_query")    
        execution_id = response['QueryExecutionId']    
        state = 'RUNNING'
        while (  state in ['RUNNING', 'QUEUED']):
            response_query = client.get_query_execution(QueryExecutionId = execution_id)
            print('Query Execution: ', response_query['QueryExecution'])
            state = response_query['QueryExecution']['Status']['State']
            if state == 'FAILED':
                return response_query
            elif state == 'SUCCEEDED':
                s3_path = response_query['QueryExecution']['ResultConfiguration']['OutputLocation']
                filename = re.findall('.*\/(.*)', s3_path)[0]
                s3_client = boto3.resource('s3', aws_access_key_id=credentials['AccessKeyId'], aws_secret_access_key=credentials['SecretAccessKey'],aws_session_token=credentials['SessionToken'])
                s3_client.Object(athena_bucket,athena_bucket_directory+db_object+'.csv').copy_from(CopySource=athena_bucket+'/'+athena_bucket_directory+filename)
                print("commerce s3_client", s3_client)
                s3_client = boto3.client('s3')
                print("s3_client", s3_client)
                s3_keys = []
                #listing files
                response = s3_client.list_objects(Bucket=athena_bucket,Prefix=athena_bucket_directory)
                for item in response['Contents']:
                    s3_keys.append(item['Key'])
                for source_key in s3_keys:
                    if ('/' in source_key) ==True:
                    #Below splitting is to get file name instead of entire path to source_key
                        index = source_key.rindex("/")
                        source_file=source_key[index + 1:]
                        if (source_file.endswith(db_object+'.csv')):
                            
                            print(source_file)
                            print(filename)
                            source_response = s3_client.get_object(Bucket=athena_bucket,Key=source_key)
                            print('source_responseeeeeeeee',source_response)
                            print('source_keyyyyyyyyy',source_key)
                            s3_resource = boto3.client("s3")
                            s3_resource.upload_fileobj(source_response['Body'],target_bucket,target_directory+source_file,ExtraArgs={"ServerSideEncryption": "AES256"}
                            #print('source_response bodyyyy',source_response['Body']
                            )

if __name__ == "__main__":
    args = getResolvedOptions(sys.argv, ['subjectarea','ini_param_df','module'])
    module = args['module']
    subjectarea = args['subjectarea'].upper()
    if module in 'manual':
        from utils_int_whl import config
        ini_param_df = config.config_param(subjectarea)
        print(ini_param_df)
    string_literals=args['ini_param_df']
    print(string_literals)
    ini_param_df=ast.literal_eval(string_literals) if string_literals!='null' else ini_param_df
    athena_to_s3(ini_param_df)

