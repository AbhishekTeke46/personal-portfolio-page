$ git clone --branch DEV --single-branch https://xateke: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@github.com/dataintelligencegroup/cp_elt_pipeline.git DEV



Glue/cp_etl_apps/cp_elt_pipeline/automation_framework/main/python/SQL/SLFC/DML/SLFC_SUBMISSION_dml.sql
Glue/cp_etl_apps/cp_elt_pipeline/automation_framework/main/python/SQL/SLFC/DML/STG_CP_ITEM_MASTER_SALESFORCE_dml.sql
Glue/cp_etl_apps/cp_elt_pipeline/automation_framework/main/python/SQL/SLFC/DML/STG_SLFC_SALESFORCE_dml.sql
Glue/cp_etl_apps/cp_elt_pipeline/automation_framework/main/python/Config/SLFC/SLFC_dml.ini
Notification/Report/SQL/AT_SLFC_DF.sql

git commit -m "Salesforce Design Change"


git clone --branch DEV --single-branch https://sukumarreddy79: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@github.com/dataintelligencegroup/cp_elt_pipeline.git DEV


WHEN LPAD(STG.GTIN, 14, 0) 
        IN (Select LPAD(API_VALUES, 14, 0) FROM {db}.{main_schema}.BARCODE_API_CALL_LIST WHERE CODE_TYPE = 'GTIN' AND SOURCE = 'CP_RETAILER' ) 
        THEN 'API_CALL_GTIN_CP_RETAILER'


CREATE OR REPLACE TABLE CP_DW_DB.CP_STAGING_INT_SCHEMA.STG_INT_GPM_WB_CP_IND
(
    CODE_TYPE VARCHAR(16777216)
  , BRCLKP_CLEAN_ATTR_VALUES VARCHAR(16777216)
  , BRCLKP_SRC_ATTR_VALUES VARCHAR(16777216)
  , IS_WB VARCHAR(1)
  , CREATED_TIMESTAMP TIMESTAMP_LTZ(9)
  , ELT_BATCH_ID NUMBER(38,0)
  , FILE_NAME VARCHAR(16777216)
  , ROW_NUMBER NUMBER(38,0)
);


TRUNCATE CP_DW_DB.CP_STAGING_INT_SCHEMA.STG_INT_GPM_WB_CP_IND;

COPY INTO CP_DW_DB.CP_STAGING_INT_SCHEMA.STG_INT_GPM_WB_CP_IND (
    CODE_TYPE 
  , BRCLKP_CLEAN_ATTR_VALUES
  , BRCLKP_SRC_ATTR_VALUES
  , IS_WB 
  , CREATED_TIMESTAMP 
  , ELT_BATCH_ID
  , FILE_NAME
  , ROW_NUMBER
)
FROM 
(
Select $1, $2, $3, $4, CURRENT_TIMESTAMP::TIMESTAMP_LTZ, '1234',METADATA$FILENAME, METADATA$FILE_ROW_NUMBER
FROM @CP_DW_DB.CP_STAGING_INT_SCHEMA.STAGE_S3_BRCLKP/in/20230210/
)
PATTERN = '.*GPM_WB_CP_Ind.*'--case sensitive
FILE_FORMAT = 
(   
	TYPE= CSV
	SKIP_HEADER=1 
	FIELD_DELIMITER='\t' 
	TRIM_SPACE = TRUE 
	RECORD_DELIMITER = '\n'
	NULL_IF = ('NULL', '', ' ')
)
encryption = (TYPE = 'AWS_SSE_S3' ) 
FORCE = TRUE
ON_ERROR = abort_statement;