import json
import subprocess

def lambda_handler(event, context):

    Command1 = ['rm', '-fr', '/tmp/git-2.18.5']
    Command2 = ['mkdir', '/tmp/git-2.18.5']
    Command3 = ['cd', '/tmp/git-2.18.5']
    Command4 = ['curl', '-s', '-O', 'http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.18.5-2.73.amzn1.x86_64.rpm']
    Command5 = ['rpm', '-K', 'git-2.18.5-2.73.amzn1.x86_64.rpm']
    Command6 = ['rpm2cpio', 'git-2.18.5-2.73.amzn1.x86_64.rpm' '|', 'cpio -id']
    
    c1 = subprocess.run(Command1)
    print(c1)
    
    c2 = subprocess.run(Command2)
    print(c2)
    
    c3 = subprocess.run(Command3)
    print(c3)
    
    c4 = subprocess.run(Command4)
    print(c4)
    
    c5 = subprocess.run(Command5)
    print(c5)
    
    c6 = subprocess.run(Command6)
    print(c6)
    
    return {'statusCode': 200,'body': json.dumps('Hello from Lambda!')}