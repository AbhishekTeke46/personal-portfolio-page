b = "SELECT {} FROM '@HE_GAMES_DB.GAMES_ODS.GAMES_S3_STAGE/data_migration/data/source/{}') FILE_FORMAT = {}.{}.FF_CSV_PIPE encryption = (TYPE = 'AWS_SSE_KMS' ) ON_ERROR = abort_statement ;".format(trg_col,trg_tbl.upper()+".txt","HE_GAMES_DB","GAMES_ODS")


b ="""SELECT {} FROM '@HE_GAMES_DB.GAMES_ODS.GAMES_S3_STAGE/data_migration/data/source/{}') FILE_FORMAT = (TYPE=CSV COMPRESSION=AUTO RECORD_DELIMITER = '\n' FIELD_DELIMITER = '|' SKIP_HEADER = 1 NULL_IF = (NULL) FIELD_OPTIONALLY_ENCLOSED_BY = '"' ESCAPE_UNENCLOSED_FIELD = '\\') encryption = (TYPE = 'AWS_SSE_KMS' ) ON_ERROR = abort_statement ;".format(trg_col,trg_tbl.upper()+".txt","HE_GAMES_DB","GAMES_ODS") ;""".format(trg_col,trg_tbl.upper()+".txt","HE_GAMES_DB","GAMES_ODS")


FILE_FORMAT = """(
        TYPE=CSV 
        COMPRESSION=AUTO 
        RECORD_DELIMITER = '\n' 
        FIELD_DELIMITER = '|' 
        SKIP_HEADER = 1 
        NULL_IF = (NULL)
        FIELD_OPTIONALLY_ENCLOSED_BY = '"' 
        ESCAPE_UNENCLOSED_FIELD = '\\') 
        encryption = (TYPE = 'AWS_SSE_KMS' ) 
        ON_ERROR = abort_statement"""


	FILE_FORMAT = 
		(   
					TYPE= CSV
                    SKIP_HEADER=1 
                    FIELD_DELIMITER=',' 
                    VALIDATE_UTF8 = FALSE  
                    TRIM_SPACE = TRUE 
                    RECORD_DELIMITER = '\n'
			        compression = GZIP
                    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
					NULL_IF = ('NULL', '', ' ')
		)
	encryption = (TYPE = 'AWS_SSE_S3' );
    
    
    
 b ="""SELECT {} FROM '@HE_GAMES_DB.GAMES_ODS.GAMES_S3_STAGE/data_migration/data/source/{}') FILE_FORMAT = (TYPE=CSV COMPRESSION=AUTO RECORD_DELIMITER = '\n' FIELD_DELIMITER = '|' SKIP_HEADER = 1 NULL_IF = (NULL) FIELD_OPTIONALLY_ENCLOSED_BY = '"' ESCAPE_UNENCLOSED_FIELD = '\\') encryption = (TYPE = 'AWS_SSE_KMS' ) ON_ERROR = abort_statement ;".format(trg_col,trg_tbl.upper()+".txt","HE_GAMES_DB","GAMES_ODS") ;""".format(trg_col,trg_tbl.upper()+".txt","HE_GAMES_DB","GAMES_ODS")