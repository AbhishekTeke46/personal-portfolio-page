INSERT INTO CP_DW_DB.CP_MAIN_SCHEMA.GS1_PRODUCT_MASTER
(
	  GTINSTATUS 
	, GTIN8 
	, COMPANYNAME 
	, COMPANYURI 
	, PREFIX 
	, GTIN 
	, GTIN13 
	, GTIN12 
	, PACKAGINGLEVEL  
	, INDUSTRY 
	, ENTITYGLN 
	, PRODUCTDESCRIPTION 
	, PRODUCTDESCRIPTIONLANGUAGE1 
	, PRODUCTDESCRIPTION2 
	, PRODUCTDESCRIPTIONLANGUAGE2 
	, SKU 
	, BRANDNAME 
	, BRANDNAMELANGUAGE1 
	, BRANDNAME2 
	, BRANDNAMELANGUAGE2 
	, STATUS 
	, ISVARIABLE 
	, ISPURCHASABLE 
	, DIMENSIONS_HEIGHT 
	, DIMENSIONS_WIDTH 
	, DIMENSIONS_DEPTH 
	, DIMENSIONS_DIMENSIONMEASURE 
	, WEIGHT_GROSSWEIGHT 
	, WEIGHT_NETWEIGHT 
	, WEIGHT_WEIGHTMEASURE 
	, COMMENTS 
	, TARGETMARKET 
	, CHILDGTINS 
	, QUANTITY 
	, SUBBRANDNAME 
	, PRODUCTDESCRIPTIONSHORT 
	, LABELDESCRIPTION  
	, NETPACKAGECONTENT_NETCONTENT1COUNT 
	, NETPACKAGECONTENT_NETCONTENT1UNITOFMEASURE 
	, NETPACKAGECONTENT_NETCONTENT2COUNT 
	, NETPACKAGECONTENT_NETCONTENT2UNITOFMEASURE 
	, NETPACKAGECONTENT_NETCONTENT3COUNT 
	, NETPACKAGECONTENT_NETCONTENT3UNITOFMEASURE 
	, GLOBALPRODUCTCLASSIFICATION 
	, IMAGEURL 
	, ANCESTORS 
	, DESCENDANTS 
	, ISENHANCED 
	, MODIFIEDDATE 
	, CHILDREN 
)
SELECT DISTINCT
	 p.value:GTINStatus::varchar AS GTINSTATUS 
	, p.value:GTIN8::varchar AS GTIN8 
	, p.value:CompanyName::varchar AS COMPANYNAME 
	, p.value:CompanyURI::varchar AS COMPANYURI 
	, p.value:Prefix::varchar AS PREFIX 
	, p.value:GTIN::varchar AS GTIN 
	, p.value:GTIN13::varchar AS GTIN13 
	, p.value:GTIN12::varchar AS GTIN12 
	, p.value:PackagingLevel::varchar AS PACKAGINGLEVEL  
	, p.value:Industry::varchar AS INDUSTRY 
	, p.value:EntityGLN::varchar AS ENTITYGLN 
	, p.value:ProductDescription::varchar AS PRODUCTDESCRIPTION 
	, p.value:ProductDescriptionLanguage1::varchar AS PRODUCTDESCRIPTIONLANGUAGE1 
	, p.value:ProductDescription2::varchar AS PRODUCTDESCRIPTION2 
	, p.value:ProductDescriptionLanguage2::varchar AS PRODUCTDESCRIPTIONLANGUAGE2 
	, p.value:SKU::varchar AS SKU 
	, p.value:BrandName::varchar AS BRANDNAME 
	, p.value:BrandNameLanguage1::varchar AS BRANDNAMELANGUAGE1 
	, p.value:BrandName2::varchar AS BRANDNAME2 
	, p.value:BrandNameLanguage2::varchar AS BRANDNAMELANGUAGE2 
	, p.value:Status::varchar AS STATUS 
	, p.value:IsVariable::varchar AS ISVARIABLE 
	, p.value:IsPurchasable::varchar AS ISPURCHASABLE 
	, d.value:Height::varchar AS DIMENSIONS_HEIGHT 
	, d.value:Width::varchar AS DIMENSIONS_WIDTH 
	, d.value:Depth::varchar AS DIMENSIONS_DEPTH 
	, d.value:DimensionMeasure::varchar AS DIMENSIONS_DIMENSIONMEASURE 
	, w.value:GrossWeight::varchar AS WEIGHT_GROSSWEIGHT 
	, w.value:NetWeight::varchar AS WEIGHT_NETWEIGHT 
	, w.value:WeightMeasure::varchar AS WEIGHT_WEIGHTMEASURE 
	, p.value:Comments::varchar AS COMMENTS 
	, p.value:TargetMarket::varchar AS TARGETMARKET 
	, p.value:ChildGTINs::varchar AS CHILDGTINS 
	, p.value:Quantity::varchar AS QUANTITY 
	, p.value:SubBrandName::varchar AS SUBBRANDNAME 
	, p.value:ProductDescriptionShort::varchar AS PRODUCTDESCRIPTIONSHORT 
	, p.value:LabelDescription::varchar AS LABELDESCRIPTION  
	, np.value:NetContent1Count::varchar AS NETPACKAGECONTENT_NETCONTENT1COUNT 
	, np.value:NetContent1UnitOfMeasure::varchar AS NETPACKAGECONTENT_NETCONTENT1UNITOFMEASURE 
	, np.value:NetContent2Count::varchar AS NETPACKAGECONTENT_NETCONTENT2COUNT 
	, np.value:NetContent2UnitOfMeasure::varchar AS NETPACKAGECONTENT_NETCONTENT2UNITOFMEASURE 
	, np.value:NetContent3Count::varchar AS NETPACKAGECONTENT_NETCONTENT3COUNT 
	, np.value:NetContent3UnitOfMeasure::varchar AS NETPACKAGECONTENT_NETCONTENT3UNITOFMEASURE 
	, p.value:GlobalProductClassification::varchar AS GLOBALPRODUCTCLASSIFICATION 
	, p.value:ImageURL::varchar AS IMAGEURL 
	, p.value:Ancestors::varchar AS ANCESTORS 
	, p.value:Descendants::varchar AS DESCENDANTS 
	, p.value:IsEnhanced::varchar AS ISENHANCED 
	, p.value:ModifiedDate::varchar AS MODIFIEDDATE 
	, p.value:Children::varchar AS CHILDREN 
FROM CP_DW_DB.CP_STAGING_INT_SCHEMA.GS1_JSON_VARIANT_TABLE_PROC_GTIN a
	, lateral flatten(input=> a.JSON_VARIANT_COL:products)p
	, lateral flatten(input=> p.value:Dimensions,OUTER => TRUE)d
	, lateral flatten(input=> p.value:Weight,OUTER => TRUE)w
	, lateral flatten(input=> p.value:NetPackageContent,OUTER => TRUE)np;