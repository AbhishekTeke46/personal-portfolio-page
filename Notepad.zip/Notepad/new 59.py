import subprocess
import os
def curl_request(url):
    
    # Define the command to execute using curl
    command = ['curl', '-s', '-o', '-', url]

    # Execute the curl command and capture the output
    result = subprocess.run(command, capture_output=True, text=True)
    
    # Return the stdout of the curl command
    return result.stdout
git_rpm_download_url = "http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm"
# Make a curl request to https://www.google.com/
response = curl_request('git_rpm_download_url)

def lambda_handler(event, context):
	# Make a curl request to https://www.google.com/
	print(response)
	lst = os.listdir("/tmp/")
	print('Tmp file List: ',lst)
    
    
    
import subprocess
import os
def lambda_handler(event, context):
    command ='curl -s -O http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm'
    result = subprocess.run(command, capture_output=True, shell=True)
    lst = os.listdir("/tmp/")
	print('Tmp file List: ',lst)
    return result