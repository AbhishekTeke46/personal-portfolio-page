# All AWS S3 Buckets List using Lambda Function with Python
import json
import ast
import boto3
from boto3 import client
import datetime
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta
from datetime import date
from datetime import datetime
import os

s3 = boto3.resource('s3')
def lambda_handler(event, context):
    s3_skip_dict = os.environ['s3_skip_dict']
    s3_skip_dict = ast.literal_eval(s3_skip_dict)  #json.loads(s3_skip_dict)
    print ("S3_skip_dict: ",s3_skip_dict)

    bucketlist = []
    for bucket in s3.buckets.all():
        bucketlist.append(bucket.name)
    print('bucketlist: ',bucketlist)
    
    conn = client('s3')

    # Listing object from each bucket
    s3_list = {}
    bucket_key_dict = {}
    key_LastModified_dict = {}
    for bucket_name in bucketlist:
        if 'Contents' in conn.list_objects_v2(Bucket=bucket_name):
            for key in conn.list_objects_v2(Bucket=bucket_name)['Contents']:
                s3_object_path = bucket_name+'/'+key['Key']
                Last_Modified_date = str(key['LastModified']).split()[0]
                #bucket_key_dict.update({bucket_name:s3_object_path})
                key_LastModified_dict.update({s3_object_path:Last_Modified_date})
    print ('bucket_key_dict: ',bucket_key_dict)
    print ('key_LastModified_dict: ',key_LastModified_dict)
    current_date = date.today() 
    #yesterday_date = current_date - timedelta(days=1)
    threshold_date= current_date - relativedelta(months=12)
    threshold_datetime =datetime(year=threshold_date.year, month=threshold_date.month,day=threshold_date.day)
    print('threshold_datetime: ',threshold_datetime) 
    new_aws_items_list = key_LastModified_dict
    for skip_bucket in s3_skip_dict:
        print ('skip_bucket: ',skip_bucket)
        for skip_path in s3_skip_dict[skip_bucket]:
            s3_skip_path = skip_bucket+'/'+skip_path
            print('s3_skip_path: ',s3_skip_path)
            for s3_object_path in key_LastModified_dict.copy():
                if s3_skip_path in s3_object_path:
                    del new_aws_items_list[s3_object_path]
    for s3_object_path in new_aws_items_list:
        if datetime.strptime(new_aws_items_list[s3_object_path],'%Y-%m-%d' ).date() < threshold_datetime.date():
            s3_list.update({s3_object_path:new_aws_items_list[s3_object_path]})
    print ('Final List: ',s3_list)
    
    path = '/tmp'# assigining temporary location path in lamda
    target_bucket_name = "cp-sf-int-dev"
    today = date.today()
    current_date = today.strftime("%Y%m%d")  # Current Date in YYYYMMDD format
    print("current_date =", current_date)
    
    aws_target_path = "GENERIC/"+current_date # aws path where aws cleanup csv needs to be uploaded
    file_name =  "AWS_Cleanup_"+current_date+".csv" # File Name of aws cleanup csv 
    
    with open('%s/%s' % (path,file_name), "w") as writing_file:
        contents =''
        for ln in s3_list:
            contents = contents+str(ln)+ "," + s3_list[ln] + "\n"
        contents = contents.rstrip(''',\n''')
        #print('contents: ', contents)
        writing_file.write(contents)
    writing_file.close()

    s3_client = boto3.client('s3')
    s3_client.upload_file("%s/%s" % (path,file_name), target_bucket_name, "%s/%s" % (aws_target_path,file_name), ExtraArgs={"ServerSideEncryption": "AES256"}) #upload_fileobj

    
    return {
    "statusCode": 200
    }