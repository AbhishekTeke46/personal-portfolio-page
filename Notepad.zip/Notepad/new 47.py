import sys
import os
from os import path
import boto3
import json
import urllib
import subprocess
import time
parentddir = os.path.abspath('/opt/utils/')
sys.path.append(parentddir)
import secret_manager
from activity_logger import logger
import urllib.request

def lambda_handler(event, context):
# DEFINING THE VARIABLES
    lambda_function_name = 'CP_CICD_GIT_TO_DEV_ENV_DEPLOY'
    #Assigning Parameters passed from Git Workflow
    source_clone_branch_name = event['source_branch']
    deploy_target_branch = event['deploy_target_branch']
    cp_tracker_name = event['tracker_name']
    deploy_branch_flag = event['deploy_branch_flag']
    reset_tracker_flag = event['reset_tracker_flag']
    workflow = event['workflow_name']
    
    parameters = '''{"source_branch":"%s",
    "deploy_target_branch":"%s",
    "tracker_name":"%s",
    "workflow_name":"%s",
    "deploy_branch_flag":"%s",
    "reset_tracker_flag": "%s"}''' % (source_clone_branch_name,deploy_target_branch,cp_tracker_name,workflow, deploy_branch_flag,reset_tracker_flag)
    
    if source_clone_branch_name == 'DEV':
        cp_glue_bucket = 'cp-glue-dev'
        cp_airflow_bucket = 'airflow-wbdi-cp-1'
        cp_int_bucket = 'cp-sf-int-dev'
        tracker_env_list = ['dev','dev-qa','dev-qa-prod']
        deploy_branch_env_list = ['dev-qa','dev-qa-prod']
        utils_suffix = '_dev'
        aws_env_matching_expression = 'dev'
        git_env_matching_expression = 'dev-qa'
        aws_env_allowed_items_extension_list = ['sql','ini','txt','py','json','csv']
        
    if source_clone_branch_name == 'QA':
        cp_glue_bucket = 'cp-glue-qa'
        cp_airflow_bucket = 'airflow-wbdi-cp-1'
        cp_int_bucket = 'cp-sf-int-qa'
        tracker_env_list = ['dev-qa','dev-qa-prod']
        deploy_branch_env_list = ['dev-qa-prod']
        utils_suffix = '_qa'
        aws_env_matching_expression = 'dev-qa'
        git_env_matching_expression = 'dev-qa-prod'
        aws_env_allowed_items_extension_list = ['sql','ini','txt','py','json','csv']
    
    if source_clone_branch_name == 'PROD':
        cp_glue_bucket = 'cp-glue-prod'
        cp_airflow_bucket = 'airflow-wbdi-cp'
        cp_int_bucket = 'cp-sf-int-prod'
        tracker_env_list = ['dev-qa-prod']
        utils_suffix = ''
        aws_env_matching_expression = 'dev-qa-prod'
        git_env_matching_expression = ''
        aws_env_allowed_items_extension_list = ['sql','ini','py','json','csv']
    
    tracker_upload_action = 'upload'
    tracker_delete_action = 'delete'
    tracker_env_action_list = [tracker_upload_action,tracker_delete_action]

    git_url = 'https://github.com/dataintelligencegroup/cp_elt_pipeline_dev.git'
    user_access = "dataintelligencegroup:"+ secret_manager.get_secret_pass('CP_DEVGITHUB_TOKEN')
    url = git_url.split('//')
    push_url = "https://"+ user_access + "@" + url[-1]
    git_repo_clone_command_source_branch = 'clone --branch ' + source_clone_branch_name + ' --single-branch'
    git_repo_clone_command_target_branch = 'clone --branch ' + deploy_target_branch + ' --single-branch'
    s3 = boto3.client('s3')

    git_repo_clone_source_dir = 'intrim_branch_clone'
    git_repo_clone_target_dir = 'destination_branch_clone'
    
    #GIT PACKAGE DOWNLOAD URL DEFINATION 
    git_rpm_region = os.environ['AWS_REGION']
    git_rpm_download_url = '/'.join([
        'http://packages.%s.amazonaws.com' % git_rpm_region,
        '2018.03/updates/efaea6f6ba01/x86_64/Packages',
        'git-2.14.6-1.62.amzn1.x86_64.rpm'])

    git_rpm_download_dir = git_rpm_download_url.split('/')[-1]  # git-2.14.6-1.62.amzn1.x86_64.rpm
    git_rpm_install_tmp_dir = '/tmp/%s' % '-'.join(git_rpm_download_dir.split('-')[0:2])  # /tmp/git-2.14.6
    
    source_repo_path = '/%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_source_dir)
    target_repo_path = '/%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)
    
    tracker_contents = ''
    LOG_TYPE = 'SUCCESS'
    
    cur_env_item_list = [] #list of all the items to be deployed in current AWS env
    glue_cur_env_item_list = [] #list of all the Glue items to be deployed in current AWS env
    airflow_cur_env_item_list = [] #list of all the Airflow items to be deployed in current AWS env
    notification_cur_env_item_list = [] #list of all the Notification items to be deployed in current AWS env
    unique_folder_structure_list = [] #list of all the Distinct Folder structures to be created in the target repo clone directory
    tracker_higher_env_item_list = [] #list of all the items to be deployed in the higher GIT Branch
    env_specific_file_name_list = [] #list of all the filenames to be deployed in current AWS env (action,env and other columns are not in this list)
    aws_env_uploaded_item_list = [] #list of all the items uploaded in current AWS env
    aws_env_deleted_item_list = [] #list of all the items deleted in current AWS env
    aws_env_deployed_list = [] #list of all the items uploaded or deleted in/from current AWS env
    tracker_wrong_env_items_list = [] #list of all items with wrong env in tracker
    tracker_wrong_action_items_list = [] #list of all items with wrong action in tracker
    
    env_specific_files_text = '' #Variable to pass to the logger for printing items to be deployed in aws current env
    tracker_wrong_env_items_list_text = '' #Variable to pass to the logger for printing items with wrong env in tracker
    tracker_wrong_action_items_list_text = '' #Variable to pass to the logger for printing items with wrong action in tracker
    names_of_successfull_deployed_object = '' #Variable to pass to the logger for printing items deployed in aws current env or in higher git branch
    comparison_list = [] #List of itmes for reconciliation validation
    reconciliation_objects_text = '' #Variable to pass to the logger for printing items mentioned in tracker but not deployed
    git_last_modified_file_name = '' #Variable used to track the last pushed item in the remote git branch
    log_details_list = [] # List of all the log details dictionaries

    try:
        #DOWNLOAD, VERIFY AND UNPACK THE GIT RPM PACKAGE ON THE LAMBDA LOCAL DIRECTORY
        TASK = 'DOWNLOAD AND INSTALLATION OF GIT PACKAGE'
        print('1')

        install_git = subprocess.check_output(
            ' && '.join([
                'rm -fr %s' % git_rpm_install_tmp_dir, #remove the directory if it exists previously 
                'mkdir %s' % git_rpm_install_tmp_dir, #Creation of the directory
                #'cd %s' % git_rpm_install_tmp_dir, #changing path to the directory
                #'curl -s -O -%s' % git_rpm_download_url, #download git rpm package
                #'rpm -K %s' % git_rpm_download_dir,  # Check the GnuPG signature
                #'rpm2cpio %s | cpio -id' % git_rpm_download_dir, #Extracting Git package
                #'rm %s' % git_rpm_download_dir #After installation removing the download directory with downloaded package
            ]),
            stderr=subprocess.STDOUT,
            shell=True)
        print(install_git)            
        
        print('2')
        lst = os.listdir("/tmp/")
        print('Tmp file List: ',lst)
        
        file_path_for_git = git_rpm_install_tmp_dir + '/' + git_rpm_download_dir
        print('file_path_for_git:', file_path_for_git)
        
        git_rpm_package_download = urllib.request.urlretrieve(git_rpm_download_url, git_rpm_download_dir)
        time.sleep(5)
        print(git_rpm_package_download)
        
        print('3')
        lst = os.listdir(git_rpm_install_tmp_dir)
        print('Tmp file List: ',lst)
        
        install_git = subprocess.check_output(
            ' && '.join([
                #'rm -fr %s' % git_rpm_install_tmp_dir, #remove the directory if it exists previously 
                #'mkdir %s' % git_rpm_install_tmp_dir, #Creation of the directory
                'cd %s' % git_rpm_install_tmp_dir, #changing path to the directory
                #'curl -s -O -%s' % git_rpm_download_url, #download git rpm package
                'rpm -K %s' % git_rpm_download_dir,  # Check the GnuPG signature
                'rpm2cpio %s | cpio -id' % git_rpm_download_dir, #Extracting Git package
                'rm %s' % git_rpm_download_dir #After installation removing the download directory with downloaded package
            ]),
            stderr=subprocess.STDOUT,
            shell=True)    
        print(install_git)

        LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY" #For logging
        log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
        log_details_list.append(log_details)
    
        #CLONE THE REMOTE GIT REPOSITORY FROM SOURCE BRANCH
        TASK = 'CLONE SOURCE BRANCH-- ' + source_clone_branch_name
        clone_source_branch = subprocess.check_output(
            ' && '.join([
                'cd %s' % git_rpm_install_tmp_dir,
                ' '.join([
                    'HOME=/var/task',
                    'GIT_TEMPLATE_DIR=%s/usr/share/git-core/templates' % git_rpm_install_tmp_dir,
                    'GIT_EXEC_PATH=%s/usr/libexec/git-core' % git_rpm_install_tmp_dir,
                    '%s/usr/bin/git %s %s %s' % (git_rpm_install_tmp_dir, git_repo_clone_command_source_branch, push_url, git_repo_clone_source_dir)
                ]),
                'ls %s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_source_dir),
            ]),
            stderr=subprocess.STDOUT,
            shell=True)
        print(clone_source_branch)

        LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
        log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
        log_details_list.append(log_details)

        #CLONE THE REMOTE GIT REPOSITORY FROM TARGET BRANCH
        if deploy_branch_flag == 'Y':
            TASK = 'CLONE TARGET BRANCH-- ' + deploy_target_branch
            print(subprocess.check_output(
                ' && '.join([
                    'cd %s' % git_rpm_install_tmp_dir,
                    ' '.join([
                        'HOME=/var/task',
                        'GIT_TEMPLATE_DIR=%s/usr/share/git-core/templates' % git_rpm_install_tmp_dir,
                        'GIT_EXEC_PATH=%s/usr/libexec/git-core' % git_rpm_install_tmp_dir,
                        '%s/usr/bin/git %s %s %s' % (git_rpm_install_tmp_dir, git_repo_clone_command_target_branch, push_url, git_repo_clone_target_dir)
                    ]),
                    'ls %s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir),
                ]),
                stderr=subprocess.STDOUT,
                shell=True))

            LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            log_details_list.append(log_details)
        
        #READING TRACKER CONTENTS
        TASK = 'READING TRACKER FILE CONTENTS'
        with open('%s%s' % (source_repo_path,cp_tracker_name),'r') as file_copy:
            tracker_contents = file_copy.read()
        tracker_lines =  tracker_contents.splitlines()

        TASK = 'CREATING ENV SPECIFIC ITEMS LIST FROM TRACKER'
        cur_env_item_list = list(filter(lambda env_specific_filter_items: aws_env_matching_expression in env_specific_filter_items, tracker_lines))
        print(cur_env_item_list)
        
        TASK = 'CREATING ENV SPECIFIC GLUE ITEMS LIST FROM TRACKER'
        glue_cur_env_item_list = list(filter(lambda glue_env_specific_filter_items: 'Glue/' in glue_env_specific_filter_items, cur_env_item_list))
        print(glue_cur_env_item_list)
        
        TASK = 'CREATING ENV SPECIFIC AIRFLOW ITEMS LIST FROM TRACKER'
        airflow_cur_env_item_list = list(filter(lambda airflow_env_specific_filter_items: 'Airflow/' in airflow_env_specific_filter_items, cur_env_item_list))   
        print(airflow_cur_env_item_list)
        
        TASK = 'CREATING ENV SPECIFIC NOTIFICATION ITEMS LIST FROM TRACKER'
        notification_cur_env_item_list = list(filter(lambda notification_env_specific_filter_items: 'Notification/' in notification_env_specific_filter_items, cur_env_item_list))   
        print(airflow_cur_env_item_list)
        
        TASK = 'CREATING GIT BRANCH ENV SPECIFIC FOLDER STRUCTURE LIST FROM TRACKER'
        tracker_higher_env_item_list = list(filter(lambda tracker_higher_env_item_filter_items: git_env_matching_expression in tracker_higher_env_item_filter_items, tracker_lines))
        print(tracker_higher_env_item_list)
        
        #Creation of unique folder structure list
        for tracker_higher_env_items in tracker_higher_env_item_list:
            tracker_higher_env_file_path_list = tracker_higher_env_items.split(',')
            tracker_higher_env_file_path = tracker_higher_env_file_path_list[0]
            tracker_higher_env_folder_structure = tracker_higher_env_file_path.rsplit('/',1)[0]
            if tracker_higher_env_folder_structure not in unique_folder_structure_list:
                unique_folder_structure_list.append(tracker_higher_env_folder_structure)
        print(unique_folder_structure_list)
                
        TASK= 'CREATING LIST OF ITEMS WHERE ENV OR ACTION IS WRONG'
        wrong_env_recon_list = []
        for tracker_each_line in tracker_lines[1:]:
            tracker_item_cols = tracker_each_line.split(',')
            if tracker_item_cols[2] not in ['dev','dev-qa','dev-qa-prod']:
                tracker_wrong_env_items_list.append(tracker_each_line)
                wrong_env_recon_list.append(tracker_item_cols[0])
            if tracker_item_cols[1].lower() not in ['upload','delete']:
                tracker_wrong_action_items_list.append(tracker_each_line)
        print(tracker_wrong_env_items_list)
        tracker_wrong_env_items_list_text = '/n'.join(tracker_wrong_env_items_list)
        print(tracker_wrong_action_items_list)
        tracker_wrong_action_items_list_text = '/n'.join(tracker_wrong_action_items_list)
        
        if len(tracker_wrong_env_items_list) != 0 or len(tracker_wrong_action_items_list) != 0:
            TASK = 'TRACKER CONTENTS PRECHECK VALIDATION'
            LOG_TYPE = 'ERROR'
            LOG_MSG = TASK + ' FAILED DUE TO WRONG TRACKER CONTENTS'
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            log_details_list.append(log_details)                
                        
        if deploy_branch_flag == 'Y':
            #FOLDER STRUCTURE CREATION IN TARGET BRANCH DIRECTORY
            TASK = 'FOLDER STRUCTURE CREATION IN TARGET BRANCH DIRECTORY'
            for folder_struct in unique_folder_structure_list:
                folder_structure_in_tracker = folder_struct.split('/')
                folder_structure = folder_structure_in_tracker[0]
                
                print(os.system("cd /tmp/git-2.14.6/%s/ && mkdir %s" % (git_repo_clone_target_dir,folder_structure)))
                        
                for folder_name in folder_structure_in_tracker[1:]:
                    print(os.system("cd /tmp/git-2.14.6/%s/%s && mkdir %s" % (git_repo_clone_target_dir,folder_structure,folder_name)))
                    folder_structure = folder_structure + "/" + folder_name
                    print(folder_structure)
    
        #DEPLOY FILES TO AWS ENVIRONMENT
        TASK = 'DEPLOY GLUE FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
        for glue_cur_env_items in glue_cur_env_item_list:
            print(glue_cur_env_items)
            glue_list_cols = glue_cur_env_items.split(",")
            tracker_col_env = glue_list_cols[2].lower() #env of file mentioned in tracker
            tracker_col_action = glue_list_cols[1].lower() #action mentioned in the tracker
            tracker_col_file_name = glue_list_cols[0] #full path of the files mentioned in the tracker
                
            tracker_file = tracker_col_file_name.split('/')
            tracker_modified_file_name = tracker_col_file_name.replace(tracker_file[0] + "/" , "") #Removing 'Glue/' from the file path
            tracker_col_file_extension = tracker_col_file_name.split('.')[1] #Extension of the file
            
            if tracker_col_file_extension in aws_env_allowed_items_extension_list: #Matching to the particular extension list allowed to move to current aws env
                if tracker_col_action == tracker_upload_action: # If 'Upload' action is mentioned in the tracker
                    TASK = 'UPLOAD GLUE FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                    print('The file to upload is: %s' % tracker_col_file_name)
                    s3.upload_file("%s/%s" % (source_repo_path,tracker_col_file_name), cp_glue_bucket, "%s" % tracker_modified_file_name) #Uploading file to aws env
                    aws_env_uploaded_item_list.append(tracker_col_file_name) # Appending the file name to the upload list
                    print('---------------------------------------------------------------------------------------------')
                
                elif tracker_col_action == tracker_delete_action: # If 'Delete' action is mentioned in the tracker
                    TASK = 'DELETE GLUE FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                    print('The file to Delete is: %s' % tracker_col_file_name)
                    s3.delete_object(Bucket = cp_glue_bucket , Key = "%s" % tracker_modified_file_name)# deleting file from aws env
                    aws_env_deleted_item_list.append(tracker_col_file_name) #Appending the file to the delete list
                    print('---------------------------------------------------------------------------------------------')
                
                else:
                    print('Upload or Delete option is not mentioned in the tracker...The operation mentioned %s cannot be performed!!' % tracker_col_action)
                    print('---------------------------------------------------------------------------------------------')
                
           
        TASK = 'DEPLOY AIRFLOW FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
        for airflow_cur_env_items in airflow_cur_env_item_list:
            print(airflow_cur_env_items)
            airflow_list_cols = airflow_cur_env_items.split(",")
            tracker_col_env = airflow_list_cols[2].lower()
            tracker_col_action = airflow_list_cols[1].lower()
            tracker_col_file_name = airflow_list_cols[0]
                
            tracker_file = tracker_col_file_name.split('/')
            tracker_modified_file_name = tracker_col_file_name.replace(tracker_file[0] + "/" , "") #Removing 'Airflow/' from the file path
            tracker_col_file_extension = tracker_col_file_name.split('.')[1]
            #tracker_modified_file_name = tracker_modified_file_name.replace('DAGs','DAGsV2')
            
            tracker_file_struct = tracker_modified_file_name.split('/')
            tracker_modified_airflow_file_name = tracker_file_struct[0]
            airflow_file_name = tracker_file_struct[-1]
            
            if tracker_col_file_extension in aws_env_allowed_items_extension_list:
                if tracker_file_struct[-2].lower() == 'utils': # If the file is in utils folder under DAGs folder
                    for i in tracker_file_struct[1:-1]:
                        tracker_modified_airflow_file_name = tracker_modified_airflow_file_name + '/' + i
                        print(tracker_modified_airflow_file_name)
                
                    tracker_modified_airflow_file_name = tracker_modified_airflow_file_name + utils_suffix + '/' + airflow_file_name #Adding env specific suffix to the utils folder 
                
                    if tracker_col_action == tracker_upload_action:
                        TASK = 'UPLOAD AIRFLOW UTILS FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                        print('The file to upload is: %s' % tracker_col_file_name)
                        s3.upload_file("%s/%s" % (source_repo_path,tracker_col_file_name), cp_airflow_bucket, "%s" % tracker_modified_airflow_file_name)
                        aws_env_uploaded_item_list.append(tracker_col_file_name)
                        print('---------------------------------------------------------------------------------------------')
                
                    elif tracker_col_action == tracker_delete_action:
                        TASK = 'DELETE AIRFLOW UTILS FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                        print('The file to Delete is: %s' % tracker_col_file_name)
                        s3.delete_object(Bucket = cp_airflow_bucket , Key = "%s" % tracker_modified_airflow_file_name)
                        aws_env_deleted_item_list.append(tracker_col_file_name)
                        print('---------------------------------------------------------------------------------------------')
                
                    else:
                        print('Upload or Delete option is not mentioned in the tracker...The operation mentioned %s cannot be performed!!' % tracker_col_action)
                        print('---------------------------------------------------------------------------------------------')
                else: # If the file is not in utils folder
                    if tracker_col_action == tracker_upload_action:
                        TASK = 'UPLOAD AIRFLOW DAG & OTHER FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                        print('The file to upload is: %s' % tracker_col_file_name)
                        s3.upload_file("%s/%s" % (source_repo_path,tracker_col_file_name), cp_airflow_bucket, "%s" % tracker_modified_file_name)
                        aws_env_uploaded_item_list.append(tracker_col_file_name)
                        print('---------------------------------------------------------------------------------------------')
                
                    elif tracker_col_action == tracker_delete_action:
                        TASK = 'DELETE AIRFLOW DAG & OTHER FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                        print('The file to Delete is: %s' % tracker_col_file_name)
                        s3.delete_object(Bucket = cp_airflow_bucket , Key = "%s" % tracker_modified_file_name)
                        aws_env_deleted_item_list.append(tracker_col_file_name)
                        print('---------------------------------------------------------------------------------------------')
                
                    else:
                        print('Upload or Delete option is not mentioned in the tracker...The operation mentioned %s cannot be performed!!' % tracker_col_action)
                        print('---------------------------------------------------------------------------------------------')

        #DEPLOY FILES TO AWS ENVIRONMENT
        TASK = 'DEPLOY NOTIFICATION FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
        for notification_cur_env_items in notification_cur_env_item_list:
            print(notification_cur_env_items)
            notification_list_cols = notification_cur_env_items.split(",")
            tracker_col_env = notification_list_cols[2].lower() #env of file mentioned in tracker
            tracker_col_action = notification_list_cols[1].lower() #action mentioned in the tracker
            tracker_col_file_name = notification_list_cols[0] #full path of the files mentioned in the tracker
                
            tracker_file = tracker_col_file_name.split('/')
            tracker_modified_file_name = tracker_col_file_name.replace(tracker_file[0] + "/" , "") #Removing 'Notification/' from the file path
            tracker_col_file_extension = tracker_col_file_name.split('.')[1] #Extension of the file
            
            if tracker_col_file_extension in aws_env_allowed_items_extension_list: #Matching to the particular extension list allowed to move to current aws env
                if tracker_col_action == tracker_upload_action: # If 'Upload' action is mentioned in the tracker
                    TASK = 'UPLOAD NOTIFICATION FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                    print('The file to upload is: %s' % tracker_col_file_name)
                    s3.upload_file("%s/%s" % (source_repo_path,tracker_col_file_name), cp_int_bucket, "%s" % tracker_modified_file_name) #Uploading file to aws env
                    aws_env_uploaded_item_list.append(tracker_col_file_name) # Appending the file name to the upload list
                    print('---------------------------------------------------------------------------------------------')
                
                elif tracker_col_action == tracker_delete_action: # If 'Delete' action is mentioned in the tracker
                    TASK = 'DELETE GLUE FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                    print('The file to Delete is: %s' % tracker_col_file_name)
                    s3.delete_object(Bucket = cp_int_bucket , Key = "%s" % tracker_modified_file_name)# deleting file from aws env
                    aws_env_deleted_item_list.append(tracker_col_file_name) #Appending the file to the delete list
                    print('---------------------------------------------------------------------------------------------')
                
                else:
                    print('Upload or Delete option is not mentioned in the tracker...The operation mentioned %s cannot be performed!!' % tracker_col_action)
                    print('---------------------------------------------------------------------------------------------')
                            
        
        aws_env_deployed_list.extend(aws_env_uploaded_item_list + aws_env_deleted_item_list) #Appending the uploaded and deleted files in the list
        
        for cur_env_items in cur_env_item_list:
            env_specific_files = cur_env_items.split(',')
            env_specific_file_name_list.append(env_specific_files[0])
            env_specific_files_text = env_specific_files_text + env_specific_files[0] + '\n' # For logger creating the string of filenames to be deployed in to current aws env
        
        comparison_list = list(set(env_specific_file_name_list) - set(aws_env_deployed_list)) # Creating the comparison list for checking
        
        for comparison_list_objects in comparison_list:
            reconciliation_objects_text = reconciliation_objects_text + comparison_list_objects + '\n' # For logger creating the text of filename which are not deployed instead of being in the 
                
        aws_deployed_items = 'The files deployed to AWS Environment are: \n\n'    # Creating a string of items and actions for putting it into the logger
        for aws_env_uploaded_items in aws_env_uploaded_item_list:
            aws_deployed_items = aws_deployed_items + aws_env_uploaded_items + '----------Upload' + '\n'
        for aws_env_deleted_items in aws_env_deleted_item_list:
            aws_deployed_items = aws_deployed_items + aws_env_deleted_items + '----------Delete' + '\n'
            
        names_of_successfull_deployed_object = aws_deployed_items
        if len(comparison_list) == 0: # If the comparison list is empty, all the files are properly deployed into aws env; so SUCCESS
            TASK = 'DEPLOY FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'    
            LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            log_details_list.append(log_details)
            
        else: # Otherwise the operation will throw an error
            TASK = 'DEPLOY FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
            LOG_TYPE = 'ERROR'
            LOG_MSG = TASK + ' FAILED DUE TO (RECONCILIATION VALIDATION ERROR) :' + reconciliation_objects_text + 'is/are not deployed to AWS ' + source_clone_branch_name + 'environment'
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            log_details_list.append(log_details)
        
        #Clearing out the values for the logger common set of variables
        names_of_successfull_deployed_object = '' 
        comparison_list.clear()
        reconciliation_objects_text = ''
        
        TASK = 'DEFINING GIT OPERATIONS'
        git_branch = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'branch','-a'] #Command to find the current git branch
        git_status = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'status'] #Command to show git status
        config_email = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'config', '--global', 'user.email', "Ritesh.Dedhia@warnerbros.com"] #Git command to configure user email
        config_name = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'config', '--global', 'user.name' , "Ritesh Dedhia"] #Git command to configure user name
        git_log = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'log', '--name-only', '--oneline', '--since=2021-11-29', 'origin2/%s' % deploy_target_branch] #Git command to show pushed files from 29-11-2021
        git_log_source_branch = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'log', '--name-only', '--oneline', '-1', 'origin/%s' % source_clone_branch_name] #Git command to log files on latest push to the Source Branch
        
        TASK = 'DEFINING ADD COMMIT PUSH FUNCTION'
        def git_add_commit_push(git_directory_of_the_file, git_file_to_add, git_branch):
            git_add = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'add', '%s/%s/%s' % (git_rpm_install_tmp_dir,git_directory_of_the_file,git_file_to_add)] #Git command to add file to stage area
            git_commit = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'commit', '-m', "files are modified"] #Git command to commit staged file
            git_push = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'push', 'origin2',git_branch] #Git command to push commited file
            
            print(subprocess.Popen(git_add , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file))) #Running the git command using subprocess
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(git_commit , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.call(git_push , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file)))
            print('---------------------------------------------------------------------------------------------')
        
        TASK = 'DEFINING REMOVE COMMIT PUSH FUNCTION'    
        def git_remove_commit_push(git_directory_of_the_file, git_file_to_remove, git_branch):
            git_remove = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'rm', '%s' % git_file_to_remove] #Git command to remove file
            git_commit = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'commit', '-m', "files are modified"] #Git command to commit removed file
            git_push = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'push', 'origin2', git_branch] #Git command to push commited file
            
            print(subprocess.Popen(git_remove , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file))) #Running the git command using subprocess
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(git_commit , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.call(git_push , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file)))
            print('---------------------------------------------------------------------------------------------')
    
    
        if deploy_branch_flag == "Y" and deploy_target_branch != "NA" and git_env_matching_expression != '': #Condition for deployment to the next higher branch in Git
            
            TASK = 'PERFORMING BASIC GIT OPERATIONS'
            print(subprocess.Popen(git_branch , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(git_status , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(config_email , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(config_name , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(['%s/usr/bin/git' % git_rpm_install_tmp_dir,'remote','add','origin2',push_url], cwd='%s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir))) # Adding new remote server origin2 to the repo
            print('---------------------------------------------------------------------------------------------')
            
            TASK = 'GIT DEPLOYMENT OF TRACKER'
            print(os.system("'cp' -r %s/%s %s/%s" % (source_repo_path,cp_tracker_name,target_repo_path,cp_tracker_name))) #Copy the tracker into the target branch
            git_add_commit_push(git_repo_clone_target_dir, cp_tracker_name, deploy_target_branch) #Push the tracker into the target branch
            
            for tracker_higher_env_objects in tracker_higher_env_item_list: # Looping for the files to deploy in the higher git branch
                tracker_higher_env_object_lines = tracker_higher_env_objects.split(',')
                TASK = 'GIT DEPLOYMENT OF THE FILE - ' + tracker_higher_env_object_lines[0]
                
                if tracker_higher_env_object_lines[1] == tracker_upload_action:
                    print(os.system("'cp' -r %s/%s %s/%s" % (source_repo_path,tracker_higher_env_object_lines[0],target_repo_path,tracker_higher_env_object_lines[0]))) # Copy the file from the source branch dir to target branch dir
                    print("The file to add to the next higher branch is: " + tracker_higher_env_object_lines[0])
                    git_add_commit_push(git_repo_clone_target_dir, tracker_higher_env_object_lines[0], deploy_target_branch) #Push the file into the target branch
                
                if tracker_higher_env_object_lines[1] == tracker_delete_action:
                    print("The file to remove from the next higher branch is: " + tracker_higher_env_object_lines[0])
                    git_remove_commit_push(git_repo_clone_target_dir, tracker_higher_env_object_lines[0], deploy_target_branch) #Remove the file from the target branch
            
            #Snowflake DDL deployment to Higher Branch
            
                
            TASK = 'LISTING OUT RECENTLY PUSHED ITEMS'
            git_last_modified_file=subprocess.check_output(git_log , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)) #Assigning the last pushed filenames into a variable
            list_of_files = git_last_modified_file.decode('utf-8').splitlines()
            
            git_last_modified_file_in_source_branch=subprocess.check_output(git_log_source_branch , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_source_dir)) #Assigning the last pushed filenames into a variable
            list_of_files_source_branch = git_last_modified_file_in_source_branch.decode('utf-8').splitlines()
            
            source_push_items_for_higher_env_list = []
            source_push_item_for_higher_env_count = 0
            
            for files_commited_from_source in list_of_files_source_branch[1:]:
                if files_commited_from_source in tracker_higher_env_item_list:
                    source_push_items_for_higher_env_list.append(files_commited_from_source)
                    source_push_item_for_higher_env_count += 1
            
            final_list_of_deployed_items = 'Final list of deployed items: \n\n'
            for lines_of_content in list_of_files:
                if lines_of_content.find('Airflow')==0 or lines_of_content.find('tracker')==0 or lines_of_content.find('Glue')==0:
                    final_list_of_deployed_items = final_list_of_deployed_items + lines_of_content + '\n'
            
            names_of_successfull_deployed_object = names_of_successfull_deployed_object + final_list_of_deployed_items + '\n' #For logging
            
            TASK = 'GENERATING THE COMPARISON LIST'
            deployed_items_list = names_of_successfull_deployed_object.splitlines()
            push_list = [] #List of last pushed files
            for push_list_items in deployed_items_list[1:]:
                push_list.append(push_list_items)
                
            for higher_env_objects_in_git in tracker_higher_env_item_list:
                higher_env_objects = higher_env_objects_in_git.split(',')
                if higher_env_objects[0] not in push_list:
                    comparison_list.append(higher_env_objects[0]) #Appending filenames which are mentioned in the tracker but not in the pushed items list
                    
            for source_push_items_for_higher_env in source_push_items_for_higher_env_list:
                if source_push_items_for_higher_env not in comparison_list[0:source_push_item_for_higher_env_count]:
                    comparison_list = [source_push_items_for_higher_env] + comparison_list #Appending the files which are not deployed recently but available on the push list previously
            
            comparison_list += wrong_env_recon_list
            comparison_list_files_name= ''    
                
            for comparison_list_objects in comparison_list:
                reconciliation_objects_text = reconciliation_objects_text + comparison_list_objects + '\n'

            if len(comparison_list) == 0: #If the comparison list is empty the SUCCESS
                TASK = 'DEPLOY FILES TO THE BRANCH - ' + deploy_target_branch
                LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
                log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
                log_details_list.append(log_details)

            else: #If the comparison list is not null then ERROR
                TASK = 'DEPLOY FILES TO THE BRANCH - ' + deploy_target_branch
                LOG_TYPE = 'ERROR'
                LOG_MSG = TASK + ' FAILED DUE TO (RECONCILIATION VALIDATION ERROR) :' + reconciliation_objects_text + 'is/are not deployed to ' + deploy_target_branch
                log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
                log_details_list.append(log_details)
    
        LOG_TYPE = 'SUCCESS'
        
        if reset_tracker_flag == "Y":
            #Clearing out the values for the logger common set of variables
            names_of_successfull_deployed_object = '' 
            comparison_list.clear()
            reconciliation_objects_text = ''
            
            tracker_reset_branch_name = 'DEV'
            git_repo_clone_command_tracker_reset_branch = 'clone --branch ' + tracker_reset_branch_name + ' --single-branch'
            git_repo_clone_tracker_reset_dir = 'tracker_reset_DEV_branch_clone'
             
            #CLONE THE REMOTE GIT REPOSITORY FROM RESET TRACKER BRANCH
            TASK = 'CLONE THE REMOTE GIT REPOSITORY FROM RESET TRACKER BRANCH'
            print(subprocess.check_output(
                ' && '.join([
                    'cd %s' % git_rpm_install_tmp_dir,
                    ' '.join([
                        'HOME=/var/task',
                        'GIT_TEMPLATE_DIR=%s/usr/share/git-core/templates' % git_rpm_install_tmp_dir,
                        'GIT_EXEC_PATH=%s/usr/libexec/git-core' % git_rpm_install_tmp_dir,
                        '%s/usr/bin/git %s %s %s' % (git_rpm_install_tmp_dir, git_repo_clone_command_tracker_reset_branch, push_url, git_repo_clone_tracker_reset_dir)
                    ]),
                    'ls %s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir),
                ]),
                stderr=subprocess.STDOUT,
                shell=True))
                
            tracker_reset_repo_path = '/%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)
            with open('%s%s' % (tracker_reset_repo_path,cp_tracker_name),'r') as file_copy: # Reading source tracker for resetting
                tracker_contents = file_copy.read()
            
            tracker_lines =  tracker_contents.splitlines()
            
            lines = []
            
            #Removing the tracker rows which are having 'dev-qa-prod' as environment
            TASK = 'RESET TRACKER CONTENTS'
            for i in range(len(tracker_lines)):
                each_line_from_tracker=tracker_lines[i]
                print(each_line_from_tracker);
                print("     ")
                cols = each_line_from_tracker.split(",")
                tracker_col_env = cols[2].lower()
                if tracker_col_env != "dev-qa-prod":
                    lines.append(tracker_lines[i])
            
            print(lines)
            
            with open('%s%s' % (tracker_reset_repo_path,cp_tracker_name), "w") as writing_file: # Writting the modified contents to the tracker
                for ln in lines:
                    writing_file.write(ln + "\n")
                writing_file.close()
            

            
            TASK = 'EXECUTING BASIC GIT OPERATIONS'
            print(subprocess.Popen(git_branch , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(git_status , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(config_email , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(config_name , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(['%s/usr/bin/git' % git_rpm_install_tmp_dir,'remote','add','origin3',push_url], cwd='%s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir))) # Adding new remote server origin2 to the repo
            print('---------------------------------------------------------------------------------------------')
            
            TASK = 'PUSH THE MODIFIED TRACKER TO THE ' + tracker_reset_branch_name + ' BRANCH'
            git_commit_tracker = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'commit', '-a', '-m', "Tracker is reset"] #Git command to commit staged file
            git_push_tracker = ['%s/usr/bin/git' % git_rpm_install_tmp_dir, 'push', '--force', 'origin3','%s:%s' % (tracker_reset_branch_name,tracker_reset_branch_name)] #Git command to push commited file
            
            print(subprocess.Popen(git_commit_tracker , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            time.sleep(5)
            print(subprocess.call(git_push_tracker , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            
            TASK = 'CHECKING FOR THE TRACKER RESET OPERATION'
            git_log_tracker_reset = ['''%s/usr/bin/git''' % git_rpm_install_tmp_dir, '''log''', '''--name-only''', '''--oneline''', '''--since="10 seconds ago"''', '''origin3/%s''' % tracker_reset_branch_name] #Git command to show pushed files since last 5 seconds
            git_last_modified_files_log = subprocess.check_output(git_log_tracker_reset , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir))
            
            if git_last_modified_files_log.decode('utf-8') == '':
                git_last_modified_file_name = ''
            else:
                git_last_modified_file = git_last_modified_files_log.decode('utf-8').splitlines()[1].strip()
            
            TASK = 'RESET TRACKER IN DEV BRANCH'
            
            if git_last_modified_file_name == 'tracker.csv':
                names_of_successfull_deployed_object = 'Deployed item: \n\n tracker.csv'
                LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
                log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
                log_details_list.append(log_details)
                
            else:
                reconciliation_objects_text = 'tracker.csv'
                LOG_TYPE = 'ERROR'
                LOG_MSG = TASK + " FAILED DUE TO (RECONCILIATION VALIDATION ERROR) : Tracker is not updated in the DEV branch"
                log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
                log_details_list.append(log_details)    

    except Exception as err: # Exception block
        print(TASK + " FAILED DUE TO: " + str(err))
        LOG_TYPE = 'ERROR'
        LOG_MSG = TASK + " FAILED DUE TO: " + str(err)
        log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
        log_details_list.append(log_details)
    
    logger(lambda_function_name, parameters, log_details_list, tracker_contents, tracker_wrong_env_items_list_text, tracker_wrong_action_items_list_text) #Calling the logger function
            
    