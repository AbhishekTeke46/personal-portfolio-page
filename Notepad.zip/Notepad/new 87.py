import os
import json
import subprocess

def lambda_handler(event, context):

    Command1 = ['rm', '-fr', '/tmp/git-2.32.0']
    Command2 = ['mkdir', '/tmp/git-2.32.0']
    Command3 = ['cd', '/tmp/git-2.32.0']
    Command4 = ['curl', '-s', '-O', 'https://cdn.amazonlinux.com/2/core/2.0/x86_64/6b0225ccc542f3834c95733dcf321ab9f1e77e6ca6817469771a8af7c49efe6c/../../../../../blobstore/7373d27ddebf2b67e82dc077389f49627d590d0dc81ded5d029d92aba8194c8a/git-2.32.0-1.amzn2.0.1.x86_64.rpm']
    Command5 = ['rpm', '-K', 'git-2.32.0-1.amzn2.0.1.x86_64.rpm']
    Command6 = ['rpm2cpio', 'git-2.32.0-1.amzn2.0.1.x86_64.rpm', '|', 'cpio -id']
    
    c1 = subprocess.run(Command1, text=True)
    #print(c1.stdout)
    
    c2 = subprocess.run(Command2, text=True)
    #print(c2.stdout)
    
    #c3 = subprocess.run(Command3, text=True)
    #print(c3.stdout)
	
    c3= os.chdir('/tmp/git-2.32.0')  #git-2.32.0-1.amzn2.0.1.x86_64.rpm
    #print(c3)
    
    c4 = subprocess.run(Command4, text=True)
    #print(c4.stdout)
    
    lst = os.listdir('/tmp')
    print('tmp file List: ',lst)
    
    lst = os.listdir('/tmp/git-2.32.0')
    print('tmp file List: ',lst)
    
    
    #c5 = subprocess.run(Command5, text=True)
    #print('Command5:',c5.stdout)
    
    c6 = subprocess.run(Command6, text=True)
    print('Command6:',c6.stdout)
    
    return {'statusCode': 200,'body': json.dumps('Hello from Lambda!')}