import sys
import os
from os import path
import boto3
import json
import urllib
import subprocess
import time
parentddir = os.path.abspath('/opt/utils/')
sys.path.append(parentddir)
import secret_manager
from activity_logger import logger
import urllib.request
import wget

git_rpm_download_url = "http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm"

git_rpm_download_dir = git_rpm_download_url.split('/')[-1]  # git-2.14.6-1.62.amzn1.x86_64.rpm
git_rpm_install_tmp_dir = '/tmp/%s' % '-'.join(git_rpm_download_dir.split('-')[0:2])  # /tmp/git-2.14.6

install_git = subprocess.check_output(
    ' && '.join([
        'rm -fr %s' % git_rpm_install_tmp_dir, #remove the directory if it exists previously 
        'mkdir %s' % git_rpm_install_tmp_dir, #Creation of the directory
        #'cd %s' % git_rpm_install_tmp_dir, #changing path to the directory
        #'curl -s -O -%s' % git_rpm_download_url, #download git rpm package
        #'rpm -K %s' % git_rpm_download_dir,  # Check the GnuPG signature
        #'rpm2cpio %s | cpio -id' % git_rpm_download_dir, #Extracting Git package
        #'rm %s' % git_rpm_download_dir #After installation removing the download directory with downloaded package
    ]),
    stderr=subprocess.STDOUT,
    shell=True)
print(install_git)


url ="http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm"
print (url)
#Linux
download =urllib.request.urlretrieve(url, git_rpm_install_tmp_dir+'/git-2.14.6-1.62.amzn1.x86_64.rpm')

lst = os.listdir("/tmp")
print('Tmp file List: ',lst)
lst1 = os.listdir(git_rpm_install_tmp_dir)
print('Tmp file List: ',lst1)


def lambda_handler(event, context):
    return install_git
    
    

url = 'http://www.example.com/foo.zip'
path = 'path/to/destination'
