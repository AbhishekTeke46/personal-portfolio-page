import urllib.request
import urllib.parse
import requests
import json
from json import loads
import os
import sys
import ast
import boto3
from datetime import date
parentddir = os.path.abspath('/opt/utils/')
sys.path.append(parentddir)
import secret_manager
import snowflake.connector


def upc_file_read():#File access: to read the file in s3 bucket
    s3_client=boto3.client("s3")  #creating s3 client object
    bucket_name="cp-sf-int-dev"
    object_path="GENERIC/UPC_API/WB_Brand_List.txt"
    file_content=s3_client.get_object(Bucket=bucket_name,Key=object_path)["Body"].read().decode('utf-8') #reading the file, utf 8 to remove bytes translation!
    print (file_content)
    upc_list=file_content.splitlines()
    return upc_list
    
def upc_api_call(api_key,upc_list_extraction,cursor):
    #Function from Barcodelookup, print sample
    upc_list_extraction = urllib.parse.quote_plus(upc_list_extraction)
    print(upc_list_extraction)
    url= '''https://api.barcodelookup.com/v3/products?Brand="'''+upc_list_extraction+'''"&metadata=y&cursor='''+cursor+'''&formatted=y&key='''+ api_key
    print("URL: ",url)
    response = requests.get(url)
    response_status_code=response.status_code
    print('response_status_code:', response_status_code)
    if response_status_code != 404:
        json_res = ast.literal_eval(response.text)
        print(cursor)
        data_mod = json.dumps(json_res)
        cursor=json_res["metadata"]["next_cursor"]
        print ("Entire Response:")
        print(data_mod)
    else:
        data_mod =''
        cursor = ''
    return data_mod,cursor,response_status_code

def upc_looping_extract(api_key,upc_list_final):
    upc_json_extracted_list = []
    for manufracturer in upc_list_final:
        cursor = 'y'
        while True:
            json_responce,cursor,response_status_code=upc_api_call(api_key,manufracturer,cursor)
            print("Next Cursor: ", cursor)
            if response_status_code == 404:
                break
            upc_json_extracted_list.append(json_responce)
    print('upc_json_extracted_list: ',upc_json_extracted_list)
    return upc_json_extracted_list

def lambda_handler(event, context):
    cursor = 'y'
    upc_list_final=upc_file_read()
    print('upc_list_final : ',upc_list_final)
    api_key = event['api_key']  #"wim4fmaat44bdvwibeuj4ba7ssq4di" , w4o2f3zaf7fcmni48t2d093xzura11, pvnikclycaar1r7vn6ipz8kvyg1c9h
    
    upc_json_response_list=upc_looping_extract(api_key,upc_list_final)
    print ('upc_json_response_list', upc_json_response_list)
    path = '/tmp'# assigining temporary location path in lamda
    target_bucket_name = "cp-sf-int-dev"
    
    today = date.today()
    current_date = today.strftime("%Y%m%d")  # Current Date in YYYYMMDD format
    print("current_date =", current_date)
    current_date_file = today.strftime("%Y-%m-%d")  # Current Date in YYYY-MM-DD format
    print('current_date_file : ',current_date_file)
    
    aws_target_path = "GENERIC/"+current_date # aws path where json needs to be uploaded
    file_name =  current_date_file+"_API_Brand_FILE.json" # File Name of json responce with extention
    
    with open('%s/%s' % (path,file_name), "w") as writing_file:
        contents =''
        for ln in upc_json_response_list:
            contents = contents+str(ln)+ ",\n"
        contents = contents.rstrip(''',\n''')
        print('contents: ', contents)
        writing_file.write(contents)
    writing_file.close()

    s3 = boto3.client('s3')
    s3.upload_file("%s/%s" % (path,file_name), target_bucket_name, "%s/%s" % (aws_target_path,file_name), ExtraArgs={"ServerSideEncryption": "AES256"}) #upload_fileobj

'''    
    ##===========Snowflake Connection Parameters======================##
    Environment = os.getenv('snow_env')
    Environment = Environment.lower()
    ##---------Getting Secret Name----------##
    snow_secret_id = {"dev": os.getenv('snow_secret_id_dev'), "qa": os.getenv('snow_secret_id_qa'), "prod": os.getenv('snow_secret_id_prod')}
    snow_password = secret_manager.get_secret_pass(snow_secret_id[Environment])
    ##-----Other Parameters-------------##
    snow_user_dict = {"dev": os.getenv('snow_user_dev'), "qa": os.getenv('snow_user_qa'), "prod": os.getenv('snow_user_prod')}
    snow_user = snow_user_dict[Environment]
    snow_account = os.getenv('snow_account') + Environment
    snow_database = os.getenv('snow_database')
    snow_schema = os.getenv('snow_schema')
    if Environment == 'dev':
        snow_role = os.getenv('snow_role_dev')
        snow_warehouse = os.getenv('snow_warehouse_dev')
    else:
        snow_role = os.getenv('snow_role')
        snow_warehouse = os.getenv('snow_warehouse')

    print("Your Account is:", snow_account)

    ##====================Connection SetUp===================================##
    conn = snowflake.connector.connect(
        user=snow_user,
        password=snow_password,
        account=snow_account,
        role=snow_role,
        warehouse=snow_warehouse,
        database=snow_database,
        schema=snow_schema
    )
    print("Successfully established Snowflake Connection:\n")

    snowflake_dml = """USE SCHEMA CP_STAGING_INT_SCHEMA; call create_tables_api_json ('STAGE_S3_TEST'/*stage_name*/,'API_UPC'/*file_name*/,'upc_api_METADATA_TABLE'/*table_name which json has to be loaded*/, 'match col case', 'match datatypes');"""
    print("Snowflake DML is: ",snowflake_dml)
    cur=conn.cursor()
    for query in snowflake_dml.split(';'):
        cur.execute(query)
        res=cur.fetchall()  
        print("Success:\n")
        print(res)
'''