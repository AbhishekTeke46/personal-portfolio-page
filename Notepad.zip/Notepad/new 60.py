'curl -s -O http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm'

import subprocess
import os

def lambda_handler(event, context):
    command ='[curl -s -O /tmp/ http://packages.us-west-2.amazonaws.com/2018.03/updates/efaea6f6ba01/x86_64/Packages/git-2.14.6-1.62.amzn1.x86_64.rpm]'
    result = subprocess.checkoutput(commandstderr=subprocess.STDOUT, shell=True)
    lst = os.listdir("/tmp/")
    print('Tmp file List: ',lst)
