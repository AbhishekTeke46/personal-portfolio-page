

url = "https://databank.worldbank.org/data/download/WDI_CSV.zip"
response = requests.get(url, stream=True)


with open("WDI_CSV.zip", mode="wb") as file:
	for chunk in response.iter_content(chunk_size=10 * 1024):
		file.write(chunk)
        
import urllib.request
myUrl = input("Enter url:")
#Linux
urllib.request.urlretrieve(myUrl, '/User/Downloads/xyz.jpg')