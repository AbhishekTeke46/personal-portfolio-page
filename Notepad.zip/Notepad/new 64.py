    shutil.rmtree(git_rpm_install_tmp_dir) #remove the directory if it exists previously 
    os.mkdir(git_rpm_install_tmp_dir) #Creation of the directory
    os.chdir(git_rpm_install_tmp_dir) #changing path to the directory

    install_git = subprocess.check_output(
        ' && '.join([
            'curl -s -O %s' % git_rpm_download_url, #download git rpm package
            'rpm -K %s' % git_rpm_download_dir,  # Check the GnuPG signature
            'rpm2cpio %s | cpio -id' % git_rpm_download_dir, #Extracting Git package
        ]),
        stderr=subprocess.STDOUT,
        shell=True)
    print(install_git)   
    
    os.remove(git_rpm_download_dir) #After installation removing the download directory with downloaded package
	
shutil.rmtree(git_rpm_install_tmp_dir) #remove the directory if it exists previously 
os.mkdir(git_rpm_install_tmp_dir) #Creation of the directory
os.chdir(git_rpm_install_tmp_dir) #changing path to the directory
os.remove(git_rpm_download_dir) #After installation removing the download directory with downloaded package

'curl -s -O %s' % git_rpm_download_url, #download git rpm package
#'rpm -K %s' % git_rpm_download_dir,  # Check the GnuPG signature
#'rpm2cpio %s | cpio -id' % git_rpm_download_dir, #Extracting Git package
#'rm %s' % git_rpm_download_dir #After installation removing the download directory with downloaded package