ALTER SESSION SET ERROR_ON_NONDETERMINISTIC_UPDATE=TRUE; 
--Needed to fail multijoined row updates. This is session specific feature so need to add in the begining of scripts having update statements