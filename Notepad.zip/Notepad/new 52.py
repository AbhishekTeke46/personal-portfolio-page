import sys
import os
from os import path
import boto3
import json
import urllib
import subprocess
import time
parentddir = os.path.abspath('/opt/utils/')
sys.path.append(parentddir)
import secret_manager
from activity_logger import logger
import urllib.request

def lambda_handler(event, context):
    
    source_clone_branch_name = 'DEV'
    git_url = 'https://github.com/dataintelligencegroup/cp_elt_pipeline_dev.git'
    user_access = "dataintelligencegroup:"+ secret_manager.get_secret_pass('CP_DEVGITHUB_TOKEN')
    url = git_url.split('//')
    push_url = "https://"+ user_access + "@" + url[-1]
    git_repo_clone_command_source_branch = 'clone --branch ' + source_clone_branch_name + ' --single-branch'
    #git_repo_clone_command_target_branch = 'clone --branch ' + deploy_target_branch + ' --single-branch'
    s3 = boto3.client('s3')

    git_repo_clone_source_dir = 'intrim_branch_clone'
    git_repo_clone_target_dir = 'destination_branch_clone'
    
    #GIT PACKAGE DOWNLOAD URL DEFINATION 
    git_rpm_region = os.environ['AWS_REGION']
    git_rpm_download_url = '/'.join([
        'http://packages.%s.amazonaws.com' % git_rpm_region,
        '2018.03/updates/efaea6f6ba01/x86_64/Packages',
        'git-2.14.6-1.62.amzn1.x86_64.rpm'])

    git_rpm_download_dir = git_rpm_download_url.split('/')[-1]  # git-2.14.6-1.62.amzn1.x86_64.rpm
    git_rpm_install_tmp_dir = '/tmp/%s' % '-'.join(git_rpm_download_dir.split('-')[0:2])  # /tmp/git-2.14.6
    
    source_repo_path = '/%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_source_dir)
    target_repo_path = '/%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)
    
    tracker_contents = ''
    LOG_TYPE = 'SUCCESS'

    try:
        #DOWNLOAD, VERIFY AND UNPACK THE GIT RPM PACKAGE ON THE LAMBDA LOCAL DIRECTORY
        TASK = 'DOWNLOAD AND INSTALLATION OF GIT PACKAGE'
        print('1')

        install_git = subprocess.check_output(
            ' && '.join([
                'rm -fr %s' % git_rpm_install_tmp_dir, #remove the directory if it exists previously 
                'mkdir %s' % git_rpm_install_tmp_dir, #Creation of the directory
                'cd %s' % git_rpm_install_tmp_dir, #changing path to the directory
                'curl -s -O -%s' % git_rpm_download_url, #download git rpm package
                'rpm -K %s' % git_rpm_download_dir,  # Check the GnuPG signature
                'rpm2cpio %s | cpio -id' % git_rpm_download_dir, #Extracting Git package
                'rm %s' % git_rpm_download_dir #After installation removing the download directory with downloaded package
            ]),
            stderr=subprocess.STDOUT,
            shell=True)
        print(install_git)            

        LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY" #For logging
        print(LOG_MSG)
    
        #CLONE THE REMOTE GIT REPOSITORY FROM SOURCE BRANCH
        TASK = 'CLONE SOURCE BRANCH-- ' + source_clone_branch_name
        clone_source_branch = subprocess.check_output(
            ' && '.join([
                'cd %s' % git_rpm_install_tmp_dir,
                ' '.join([
                    'HOME=/var/task',
                    'GIT_TEMPLATE_DIR=%s/usr/share/git-core/templates' % git_rpm_install_tmp_dir,
                    'GIT_EXEC_PATH=%s/usr/libexec/git-core' % git_rpm_install_tmp_dir,
                    '%s/usr/bin/git %s %s %s' % (git_rpm_install_tmp_dir, git_repo_clone_command_source_branch, push_url, git_repo_clone_source_dir)
                ]),
                'ls %s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_source_dir),
            ]),
            stderr=subprocess.STDOUT,
            shell=True)
        print(clone_source_branch)

        LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
        print(LOG_MSG)
        
    except Exception as err: # Exception block
        print(TASK + " FAILED DUE TO: " + str(err))