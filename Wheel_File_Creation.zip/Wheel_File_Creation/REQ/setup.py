from setuptools import setup   

setup(
    name = 'utils_int_whl',
    version = 2.00,
    packages = ['utils_int_whl'])