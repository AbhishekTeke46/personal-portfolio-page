from setuptools import setup   

setup(
    name = 'utils_int_whl',
    version = 1.15,
    packages = ['utils_int_whl'])