"""JobRun wrapper script which takes retailer name and activity to be performed for a particular retailer as input arguments and
reads common ini file and retailer specific ini files to get the parameters.




Modification Log:
-------------------------------------------------------------------------------
Date                Author              Description
-------------------------------------------------------------------------------
2/25/2021        Ankita Agarwal         Initial Release

3/05/2021        Ankita Agarwal         Updated code for target Api file download and code to get parameter_df and job_status

3/18/2021        Navya Nelluri          Bucket Transfer, Purge.
                                        
3/22/2021        Vasu Chennuri          Updated Gzip Conversion, Gzip files transfer to integration bucket 
                                        and XLSX/XLS to TXT conversion  
                                        
3/23/2021        V. Nagadeekshitha      Updated sftp_to_s3            

6/22/2021        V. Nagadeekshitha      Updated athena_to_s3 
6/23/2021        Navya Nelluri          Updated purge parameters        
7/12/2021        Ankita Agarwal         Updated code to execute selenium framework scripts
12/14/2021       Gautam Added           S3_t0_sftp functionality
01/12/2022       V. Nagadeekshitha      Removed s3_to_sftp block
02/16/2022       Kalyani Tarwatkar      Added ind_cpimft_to_int,int_cpimft_to_arc,bucketpurge_int_cpimft
05/02/2022       Surjay Boral           Added api_outbound module
05/10/2022       Surjay Boral           Added pdf_conversion module
----------------------------------------------------------------------------------------------
Args:
subjectarea-Retailer for which we need to execute the script
exec_param-Activity needs to be triggered for a specifc retailer for eg.filedownload,bucket transfer etc


 Processing:
1. Reads common ini file to get the common configuration parameters for a particular retailer.
2. Reads retailer specific common ini file to get configuration parameters specific to a particular retailer
3. Reads second argument and perform specific activity being called
4. If .ini is given as exec_param it will execute the complete batch for that retailer
  else
  it will execute the specific activity being called
5.Establish connection with snowflake and after executing sql it writes the result into log activity table

 Returns:
- Executes the specific end to end batch for a retailer
- Executes specific activity for a particular retailer
"""

from awsglue.utils import getResolvedOptions
import configparser
import boto3
from botocore.exceptions import ClientError
import json
import base64
import sys
from datetime import datetime
from snowflake.connector import DictCursor
from snowflake.connector import connect
from utils_int_whl import secret_manager
from utils_int_whl import config
from utils_int_whl import Snowflake
from utils_int_whl import get_glue_job_status
from sqlparse import tokens
import sqlparse
import time
import ast
import collections
import pandas as pd
import atexit
import os
import inspect
import pytz
from botocore.config import Config

def main(args):
    # -------------- Job Arguments ---------------------------------------
    # ------------  Reads input parameters retailer name and activity to be performed -----------

    subjectarea = args['subjectarea'].upper()
    exec_param = args['exec_param']
    app = args['app']
    
    job_id = args['parent_batch_id']
    
    print("----------subjectarea-----------", subjectarea)
    print("----------exec_param------------", exec_param)
    
    #--------------- Including logic to update parent_batch_id to currentdate when parent_batch_id is null---------
    if job_id in 'null':
       todays_date =  datetime.now(tz=pytz.utc)
       # Converting a to string in the desired format (YYYYMMDD) using strftime and then to int.
       job_id = int(time.mktime(todays_date.timetuple()))
      
    
    parent_batch_id = int(job_id)
   
    #-------------calling wheel file to read ini parameters and return all parameters in a dataframe-----------
    parameter_df=config.config_param(app,subjectarea)
    print("parameter_df",parameter_df)
    Job_list = ast.literal_eval(parameter_df['glue_job_name'])
    # ----------- Snowflake query for etl_batch_id --------------------------------------
    # --------- Establish connection with snowflake and get ELT_BATCH_ID for executing the current batch ------
    try:
        cs = Snowflake.connect_to_snowflake(parameter_df)
        batch_query = "select {db}.{landing_schema}.elt_batch_seq.nextval as ELT_BATCH_ID;".format(**parameter_df)
        elt_batch_id = cs.execute(batch_query).fetchall()[0]
        print('Batch Id----->', elt_batch_id)
    except Exception as e:
        print("Error getting elt_batch_id",str(e))
        sys.exit("CRITICAL ERROR -> Error getting elt_batch_id ")

    Exec_startTime = Snowflake.get_time()
    module_check=False
    
    try:
        # ------------- Executing .sql file ----------------------------------
        
        if ".sql" in exec_param:
            
            module_check=True
            print("sql",module_check)
            #connecting to snowflake for SQL execution
            sf_exec = Snowflake.connect_to_snowflake(parameter_df)
            Snowflake.sf_execution(sf_exec,subjectarea, exec_param,elt_batch_id, parent_batch_id,parameter_df)
        #Converting exec_param to lower case because except .sql part every conditional parameter is in lower case
        exec_param = exec_param.lower()
        
        
        # ------------- Executing api call to download files for target -------------
        
        if "apicall" == exec_param or "api_outbound" == exec_param:
            module_check=True
            
            print("----------Target kiteworks Download-------------------------")
            glue_job_name = Job_list['apicall']
            
            ini_keys = parameter_df.keys()
            
            #  Check to validate that all api parameters are existing in ini
            api_section = {'API_REPORT','HEADERS','API_METHOD','HOSTNAME','FOLDER_ID','OUTBOUND_FOLDER_ID','OUTBOUND_API_METHOD','CHUNKSIZE'}
            for elem in api_section:
                if elem not in ini_keys:
                    raise Exception(f"{elem} is not present in ini_keys")
            result =  all(elem in ini_keys for elem in api_section)
            print("ini_keys:0:0:0",ini_keys)
            print("api_section:0:0:0",api_section)
            # Validating that ini is having all parameters required for API call If not raise exception
            if result:
                print("----------------- Initiating file download from Kiteworks ------------------------")    
                response = start_glue_job(glue_job_name,subjectarea,parameter_df,exec_param)
                process_job_status(glue_job_name, response,elt_batch_id, subjectarea, parameter_df, glue_job_name,
                                  parent_batch_id,exec_param, Exec_startTime)
                                 
                
            else:
                raise Exception("API section not present in INI file")
                
        # ------------- Executing bucket transfer ----------------------------------
        
        if ( "ind_to_int" == exec_param or "int_to_arc" == exec_param or "gzip_itemshare_to_int" == exec_param or "ext_to_int" == exec_param or "gzip_to_int" == exec_param or "int_to_out_arc" == exec_param or "ind_cpimft_to_int" == exec_param or "int_cpimft_to_arc" == exec_param) :
            module_check=True
            
            glue_job_name = Job_list['BucketTransfer']
            print("---------- files Transferring -------------------: ",exec_param)
            response = start_glue_job(glue_job_name,subjectarea,parameter_df,exec_param)
            process_job_status(glue_job_name, response,elt_batch_id, subjectarea, parameter_df, glue_job_name,
                                  parent_batch_id,exec_param, Exec_startTime)
            
        # ------------- Executing gzip conversion ----------------------------------
        
        if "gzip_conversion" == exec_param:
            module_check=True
            
            print("---------- gzip_conversion -------------------")
            glue_job_name = Job_list['gzip_conversion']
            response = start_glue_job(glue_job_name,subjectarea,parameter_df,exec_param)
            process_job_status(glue_job_name, response,elt_batch_id, subjectarea, parameter_df, glue_job_name,
                                  parent_batch_id,exec_param, Exec_startTime)
           
        # ------------- Executing xls to txt conversion ------------------------------   
        
        if  "xlstotxt" == exec_param:
            module_check=True
            
            print("---------- Initiating XLS(X) to TXT  Conversion-------------------")
            glue_job_name = Job_list['xlstotxt']
            response = start_glue_job(glue_job_name,subjectarea,parameter_df,exec_param)
            process_job_status(glue_job_name, response,elt_batch_id, subjectarea, parameter_df, glue_job_name,
                                  parent_batch_id,exec_param, Exec_startTime)
                 
           
        # ------------- Executing purge ----------------------------------------------    
        
        if ("bucketpurge_ind" == exec_param or "bucketpurge_int" == exec_param or "bucketpurge_arc" == exec_param or "bucketpurge_glue" == exec_param or "bucketpurge_out_int" == exec_param or "bucketpurge_int_cpimft" == exec_param) :
            module_check=True
            
            glue_job_name = Job_list['purge']
            print("-------- Purging Files -------------------: ",exec_param)
            response = start_glue_job(glue_job_name,subjectarea,parameter_df,exec_param)
            process_job_status(glue_job_name, response,elt_batch_id, subjectarea, parameter_df, glue_job_name,
                                  parent_batch_id,exec_param, Exec_startTime)
          
        # ------------- Executing sftp to s3 transfer ----------------------------------  
        
        if("sftp_to_s3" == exec_param or "sftp_purge"==exec_param or "s3_to_sftp" == exec_param ):
            
            module_check=True
          
            glue_job_name = Job_list['sftp_to_s3']
            print("---------------------------------------Triggering sftp_to_s3-------------------------------------")
            response = start_glue_job(glue_job_name,subjectarea,parameter_df,exec_param)
            print("doooone")
            process_job_status(glue_job_name, response,elt_batch_id, subjectarea, parameter_df, glue_job_name,
                                  parent_batch_id,exec_param, Exec_startTime)
                                                               
                                  
                                  
        # ------------- Executing athena to s3 transfer ----------------------------------  
        
        if "athena_to_s3" == exec_param:
            
            module_check=True
          
            glue_job_name = Job_list['athena_to_s3']
            print("---------------------------------------Triggering athena_to_s3-------------------------------------")
            response = start_glue_job(glue_job_name,subjectarea,parameter_df,exec_param)
            print("doooone")
            process_job_status(glue_job_name, response,elt_batch_id, subjectarea, parameter_df, glue_job_name,
                                  parent_batch_id,exec_param, Exec_startTime)
                                  
         
        # ------------- Executing itemshare download ----------------------------------
        if "autodownload" in exec_param:
            Exec_startTime = Snowflake.get_time()
            #  Check to validate that all report parameters are existing in ini

            print("----------------- Initiating file download from Retaillink ------------------------")
            data = {'Subjectarea': subjectarea, 'ini_param_df': parameter_df, 'module': exec_param}
            lambda_client = boto3.client('lambda', config=Config(read_timeout=9000, retries={'max_attempts': 0}))
            job_name = "cp_autodownload_reports"
            response = lambda_client.invoke(
                FunctionName='cp_autodownload_reports',
                InvocationType='RequestResponse',
                Payload=json.dumps(data))

            return process_lambda_status(job_name, response, elt_batch_id, subjectarea, parameter_df, job_name,
                                         parent_batch_id, exec_param, Exec_startTime)
        # ------------- Executing file pre check ----------------------------------
        if ("file_pre_check" == exec_param or "file_pre_check_test" == exec_param):
            module_check = True
            glue_job_name = Job_list['file_pre_check']
            print(glue_job_name)
            print("---------------------------------------Triggering file_pre_check-------------------------------------")
            response = start_glue_job(glue_job_name, subjectarea, parameter_df, exec_param)
            print("doooone")
            process_job_status(glue_job_name, response, elt_batch_id, subjectarea, parameter_df, glue_job_name,
                               parent_batch_id, exec_param, Exec_startTime) 
                               
        #----------Snowcommerce execution-------------------------
        if("snow_commerce"==exec_param):
            module_check = True
            glue_job_name = Job_list['snow_commerce']
            print(glue_job_name)
            print("---------------------------------------Triggering snow_commerce-------------------------------------")
            response = start_glue_job(glue_job_name, subjectarea, parameter_df, exec_param)
            print("doooone")
            process_job_status(glue_job_name, response, elt_batch_id, subjectarea, parameter_df, glue_job_name,
                               parent_batch_id, exec_param, Exec_startTime)
        
        #-------------------PDF conversion execution-------------------------
        if("attachment_pdf_conversion"==exec_param):
            module_check = True
            glue_job_name = Job_list['pdf_conversion']
            print(glue_job_name)
            print("---------------------------------------Triggering pdf_conversion-------------------------------------")
            response = start_glue_job(glue_job_name, subjectarea, parameter_df, exec_param)
            print("done")
            process_job_status(glue_job_name, response, elt_batch_id, subjectarea, parameter_df, glue_job_name,
                               parent_batch_id, exec_param, Exec_startTime)

        if (module_check==False):
            raise Exception(f"{exec_param} is not a valid parameter")
            
        
            
    except Exception as e:
        print("Error in executing module: ",exec_param,str(e))
        raise Exception("Failed to execute glue job module: ",exec_param,str(e))
 
#This function is called to call sub-glue-job by passing glue_job_name to be executed                   
def start_glue_job(glue_job_name,subjectarea,parameter_df,exec_param):
    glue_client = boto3.client('glue', region_name='us-west-2')
    response = glue_client.start_job_run(
                   JobName=glue_job_name,
                   Arguments={
                   '--subjectarea': subjectarea,
                   '--ini_param_df': str(parameter_df),
                   '--module': exec_param
                   }
                 ) 
    return response  
         
#-----This function gets the job_status from sub glue job and throws an exception if the sub-glue job returns failure state.Also this function
#----- makes an entry to cp_activity_log table
def process_job_status(Job_Name, response,elt_batch_id, subjectarea, parameter_df,glue_job_name,
                     parent_batch_id, exec_param, Exec_startTime):
    
    print("process_job_status")
    #Getting status from sub-glue job
    ScriptName = glue_job_name
    job_status = get_glue_job_status.glue_status(Job_Name, response,elt_batch_id, subjectarea, parameter_df, ScriptName,
                     parent_batch_id,exec_param, Exec_startTime)
    job_state = job_status['state']
    message = job_status['script_message']
    
    #Raising exception in case of sub-glue job failure
    if job_state not in ['SUCCEEDED']:
       print("Failed to execute  glue job",message)
       raise Exception("Failed to execute  glue job ")
    else:
        print("success")

def process_lambda_status(Job_Name, response, elt_batch_id, subjectarea, parameter_df, job_name,
                          parent_batch_id, exec_param, Exec_startTime):
    print("process_lambda_status")
    ScriptName = Job_Name
    job_status = get_glue_job_status.lambda_status(Job_Name, response, elt_batch_id, subjectarea, parameter_df,
                                                   ScriptName, parent_batch_id, exec_param, Exec_startTime)
    job_state = job_status['state']
    message = job_status['script_message']
    if job_state == 'success':
        print("lambda success")
    else:
        raise Exception("Failed to execute  Lambda job", message)
    return job_state

if __name__ == "__main__":
    args = getResolvedOptions(sys.argv, ['parent_batch_id', 'subjectarea', 'exec_param', 'app'])

    main(args)