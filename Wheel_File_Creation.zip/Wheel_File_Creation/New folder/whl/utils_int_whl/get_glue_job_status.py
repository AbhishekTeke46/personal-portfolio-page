"""
This python module calls the glue jobrun and returns the status of glue job execution to the parent dag execution code
Author: Ankita Agarwal, Capgemini

Modification Log:
-------------------------------------------------------------------------------
Date                Author             Description
-------------------------------------------------------------------------------
2/25/2021         Ankita Agarwal         Initial Release
5/12/2021         Ankita Agarwal         Updated get_lambda_status to read response
                                         from lambda function
-------------------------------------------------------------------------------
Args:
Job_Name-Glue job for which status needs to be retreived
response-This value contains response from job execution in jobrun module
elt_batch_id-unique batch id for each retailer job
parent_batch_id-unique batch id for complete retailer batch
parameter_df-dataframe returned from config having all ini parameters
sqlScriptName-script name to be executed for particular retailer
glue_bucket_name-Bucket name where all scripts are stored
exec-param-Job to be executed for particular retailer
snowsqlstartTime-time at which glue job was trigerred
subjectarea-Retailer Name

Processing:
- Retrieves status from glue job and makes entry into cp_Activity_log table
- Retrieves status from Lambda function and makes entry into cp_Activity_log table

Returns:
- State of glue job after execution
- State of lambda  function after execution
"""
import boto3
import time
import datetime as datetime
from pytz import timezone
import pytz
import json
from utils_int_whl import Snowflake
from snowflake.connector import DictCursor
from snowflake.connector import connect

glue_client = boto3.client('glue', region_name='us-west-2')

row_insert = 0
row_update = 0
row_delete = 0

#This method returns the status from respective glue jobs by reading response 
def glue_status(Job_Name,response,elt_batch_id,subjectarea,parameter_df,ScriptName,parent_batch_id,exec_param,Exec_startTime):

    print(Exec_startTime)
    logSQLfile = parameter_df['logsql']
    identifiers = {**parameter_df}
    glue_bucket_name = parameter_df['cp_glu_bucket']
    snowsql_endTime = Snowflake.get_time()
    sqlScriptName = ScriptName
    snowsql_startTime = Exec_startTime
    print("start time",snowsql_startTime)
    print("end time",snowsql_endTime)
    errno = None
    sqlstate = None
    emsg = None
    status = glue_client.get_job_run(JobName=Job_Name, RunId=response['JobRunId'])
    print("status", status)
    if status:
        state = status['JobRun']['JobRunState']
        while state in ['RUNNING','SUCCEEDED','STOPPED', 'FAILED', 'TIMEOUT']:
             time.sleep(30)
             status = glue_client.get_job_run(JobName=Job_Name, RunId=response['JobRunId'])
             state = status['JobRun']['JobRunState']
             print("actual_state",state)
             if state in ['STOPPED', 'FAILED', 'TIMEOUT']:
                print("In failed")
                emsg = status['JobRun']['ErrorMessage']
                script_message = "Job Failed"
                print("script_message",script_message)
                log_type = "ERROR"
                cs = Snowflake.connect_to_snowflake(parameter_df)
                
                log_CP_Client = Snowflake.insertActivity(cs,logSQLfile, identifiers, log_type, elt_batch_id,
                                                         subjectarea, sqlScriptName,
                                                         row_insert, row_update, row_delete, script_message,
                                                         snowsql_startTime,snowsql_endTime
                                                         , errno, emsg, sqlstate, parent_batch_id,
                                                         glue_bucket_name)
                job_status = {'state': state, 'script_message': emsg}
                return job_status
             elif state in ['SUCCEEDED']:
                  print("In Success")
                  script_message = 'Job Successful'
                  print("script_message")
                  log_type = "LOG"
                  cs = Snowflake.connect_to_snowflake(parameter_df)
                  
                  log_CP_Client = Snowflake.insertActivity(cs,logSQLfile, identifiers, log_type, elt_batch_id,
                                                         subjectarea, sqlScriptName,
                                                         row_insert, row_update, row_delete, script_message,
                                                         snowsql_startTime,
                                                         snowsql_endTime, errno, emsg, sqlstate, parent_batch_id,
                                                         glue_bucket_name)
                  job_status = {'state': state, 'script_message': script_message}
                  print("done")
                  return job_status

#This method returns the status from respective lambda jobs by reading response 
def lambda_status(Job_Name,response,elt_batch_id,subjectarea,parameter_df,ScriptName,parent_batch_id,exec_param,Exec_startTime):
    logSQLfile = parameter_df['logsql']
    print("logSQLfile",logSQLfile)
    identifiers = {**parameter_df}
    glue_bucket_name = parameter_df['cp_glu_bucket']
    snowsql_endTime = Snowflake.get_time()
    sqlScriptName = ScriptName
    snowsql_startTime = Exec_startTime
    errno = None
    sqlstate = None
    emsg = None
    response_payload = json.loads(response['Payload'].read().decode("utf-8"))
    print("response_payload: {}".format(response_payload))
    if not response_payload:
        print("In Success")
        script_message = 'Job Successful'
        print("script_message")
        log_type = "LOG"
        cs = Snowflake.connect_to_snowflake(parameter_df)
        log_CP_Client = Snowflake.insertActivity(cs,logSQLfile, identifiers, log_type, elt_batch_id,
                                                 subjectarea, sqlScriptName,
                                                 row_insert, row_update, row_delete, script_message,
                                                 snowsql_startTime,
                                                 snowsql_endTime, errno, emsg, sqlstate, parent_batch_id,
                                                glue_bucket_name)
        job_status = {'state': 'success', 'script_message': script_message}
    else:
        print("In failed")
        script_message = "Job Failed"
        emsg= response_payload['errorMessage']
        print("script_message", emsg)
        log_type = "ERROR"
        cs = Snowflake.connect_to_snowflake(parameter_df)
        log_CP_Client = Snowflake.insertActivity(cs,logSQLfile, identifiers, log_type, elt_batch_id,
                                                 subjectarea, sqlScriptName,
                                                 row_insert, row_update, row_delete, script_message,
                                                 snowsql_startTime, snowsql_endTime
                                                 , errno, emsg, sqlstate, parent_batch_id,
                                                 glue_bucket_name)
        job_status = {'state': 'Failed', 'script_message': emsg}

    return job_status
