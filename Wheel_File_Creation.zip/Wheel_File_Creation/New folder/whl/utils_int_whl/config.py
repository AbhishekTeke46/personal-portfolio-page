import configparser
import boto3
import io
from botocore.exceptions import ClientError
import json
import base64
import sys
import ast
import collections
import os
from datetime import datetime,timedelta, date
from pytz import timezone
import pytz
import inspect
import ast

date_utc = datetime.now(tz=pytz.utc)
date_pst = date_utc.astimezone(timezone('US/Pacific'))

# ------- This function reads ini file and returns dictionary values based on the input parameters  -----------------   
def get_config_from_s3(glue_bucket_name,inifile, section,name):

    s3 = boto3.resource('s3')
    bucket= s3.Bucket(glue_bucket_name)

    cfg = (bucket.Object(inifile)).get()
    # open the file object and read it into the variable filedata.
    config = configparser.ConfigParser()
    config.read_file(io.TextIOWrapper(io.BytesIO(cfg['Body'].read())))

    if name is None and section is not None:
        return dict(config.items(section))
    else:
        if  section is None and name is None:
            config_section=config.sections()
            parameter_df={}
            for section in config_section:
                common_ini_param_df_elements=get_config_from_s3(glue_bucket_name,inifile,section,name)
                parameter_df=dict(parameter_df,**common_ini_param_df_elements)
            if inifile.find('common') != -1:
                return parameter_df
            else:
               section_dict = config._sections
               section_dict = json.loads(json.dumps(section_dict))
               parameter_df = readLiterals(parameter_df)
               parameter_df.update(section_dict)
               return parameter_df
        else:
            return config.get(section, name)

def readLiterals(parameter_df):
    if parameter_df['yyyy'] == '' or parameter_df['mm'] == '' or parameter_df['dd'] == '':

        # Converting the date back into YYYYMMDD format
        parameter_df['yyyy'] = date_pst.strftime('%Y')
        parameter_df['mm'] = date_pst.strftime('%m')
        parameter_df['dd'] = date_pst.strftime('%d')

    parameter_df = {k.upper(): v for k, v in parameter_df.items()}
    parameter_df['YYYYMMDD'] = parameter_df['YYYY'] + parameter_df['MM'] + parameter_df['DD']

    return parameter_df

def config_param(subjectarea):
    try:
        glue_bucket_name = 'cp-glue-dev'
        Main_Folder = 'cp_etl_apps/cp_elt_pipeline/automation_framework/main/python/'
        section = None
        Name = None
        common_inifile = Main_Folder + 'Config/' + 'common.ini'
        retailer_inifile = Main_Folder + 'Config/' + subjectarea.upper() + '/' + subjectarea.upper() + "_dml.ini"
        retailer_ini_df = get_config_from_s3(glue_bucket_name, retailer_inifile, section, Name)
        common_ini_df = get_config_from_s3(glue_bucket_name, common_inifile, section, Name)
        env_var = {'glue_bucket_name':'cp-glue-dev','Main_Folder':'cp_etl_apps/cp_elt_pipeline/automation_framework/main/python/'}
        parameter_df = dict(retailer_ini_df, **common_ini_df,**env_var)
        return parameter_df
    except Exception as e:
        print("Error in reading ini : ",str(e))
        raise Exception("Unable to read ini file")

