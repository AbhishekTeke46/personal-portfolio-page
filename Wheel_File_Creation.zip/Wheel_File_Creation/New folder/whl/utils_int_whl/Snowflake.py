"""
This python module performs connect to snowflake and process sqls statements by parsing them one by one and finally
executing the cursor to perform insert/update/delete in snowflake tables.

Also it logs an entry into cp_activity_log table on success/failure of sql execution
Author: Ankita Agarwal, Capgemini

Modification Log:
-------------------------------------------------------------------------------
Date                Author             Description
-------------------------------------------------------------------------------
3/18/2020         Ankita Agarwal        Initial Release
3/20/2021n        Navya Nelluri         Modified insert activity section
11/02/2021		Kalyani Tarwatkar	    Modified results_handler and sf_execution section to handle copy command defect
-------------------------------------------------------------------------------
"""

import configparser
import boto3
import io
import logging
from botocore.exceptions import ClientError
import json
import base64
import sys
import snowflake.connector
from snowflake.connector import DictCursor
from snowflake.connector import connect
from snowflake.connector import *
import sqlparse
import time
from sqlparse import tokens
import datetime as datetime
from utils_int_whl import Snowflake
from utils_int_whl import secret_manager
from pytz import timezone
import pytz


# ----- This function performs connection to snowflake database after receiving connection details as input ------
def connect_to_snowflake(parameter_df):
    # Args - Snowflake and aws_details from common ini file
    # Returns - snowflake connection object

    ctx = snowflake.connector.connect(
        user=parameter_df['snow_user'],
        password=secret_manager.get_secret_pass(parameter_df['snow_pass_key']),
        account=parameter_df['account'],
        warehouse=parameter_df['warehouse'],
        database=parameter_df['db'],
        role=parameter_df['role'],
        schema=parameter_df['landing_schema']
    )

    conn = ctx.cursor(DictCursor)

    return conn


# ------- This function calculates the no of rows inserted/updated/deleted and returns a dictionary with key value pairs
def results_handler(res_dict):
    # Args - sql query execution result
    # Returns - Dictionary containing values for rows inserted/updated/deleted
    rows_ins_key = 'number of rows inserted'
    rows_upd_key = 'number of rows updated'
    rows_del_key = 'number of rows deleted'

    results = []

    for row in res_dict:
        rows_inserted = 0
        rows_updated = 0
        rows_deleted = 0

        row_result = {}

        row_result['message'] = row

        if 'status' in row and row['status'] == 'LOADED':
            rows_inserted = row['rows_loaded']

        elif rows_ins_key in row.keys() and rows_upd_key in row.keys():
            rows_inserted = row[rows_ins_key]
            rows_updated = row[rows_upd_key]

        elif rows_ins_key in row.keys():
            rows_inserted = row[rows_ins_key]

        elif rows_upd_key in row.keys():
            rows_updated = row[rows_upd_key]

        elif rows_del_key in row.keys():
            rows_deleted = row[rows_del_key]

        row_result['rows_inserted'] = rows_inserted
        row_result['rows_updated'] = rows_updated
        row_result['rows_deleted'] = rows_deleted

        results.append(row_result)

    return results


# -------- This function Reads a SQL script and removes comments and token from SQL. ------------
def read_sql(script_path, glue_bucket_name):
    # Args - SQL script file path
    # Returns - Executable SQL without comments

    sqls = []
    final_sqls = []

    # Create a file object using the bucket and object key.
    s3client = boto3.client(
        's3',
        region_name='us-west-2'
    )

    fileobj = s3client.get_object(
        Bucket=glue_bucket_name,
        Key=script_path
    )

    # Reads the data from file
    contents = fileobj['Body'].read().decode('utf-8')

    for statement in sqlparse.parse(contents):
        new_tokens = [stm for stm in statement.tokens if not isinstance(stm, sqlparse.sql.Comment)]
        new_statement = sqlparse.sql.TokenList(new_tokens)
        if str(new_statement) != '\n':
            sqls.append(str(new_statement))

    return sqls


# -------- Executes SQL in snowflake with parameters and identifiers. And logs the result in Log table ------
def sf_execution(sf_exec, subjectarea, exec_param, elt_batch_id, parent_batch_id, parameter_df):
    # Args -
    #   sf_exec : snowflake cursor
    #   subjectarea: Retailer  Name
    #   script_path: SQL script path
    #   database, schema: identifier values
    #   logSQLfile: SQL path for insert statement in Log table
    #   literals: Literals for SQL defined in the ini file
    #   elt_batch_id :Batch id for current batch
    #   Returns - Executes the SQL statement in snowflake  and Logs result in Log table
    try:
        snowsql_startTime = get_time()
        activity_path = parameter_df['logsql']
        logSQLfile = activity_path
        identifiers = {**parameter_df}
        arg_folder_path = exec_param.split("/")[0].upper()
        sql_name = exec_param.split("/")[1]
        script_path = parameter_df['sqldir'] + subjectarea + "/" + arg_folder_path + "/" + sql_name
        print("script_path--", script_path)
        sqlScriptName = str(script_path[script_path.rindex("/") + 1:])
        glue_bucket_name = parameter_df['glue_bucket_name']
        sqlFile = read_sql(script_path, glue_bucket_name)
        for commands in sqlFile:
            snowsql_startTime = get_time()
            query = commands.format(**parameter_df)
            print("query---->", query)
            literals = {**parameter_df, **elt_batch_id}
            print("literals", literals)
            sf_exec.execute(query % literals)

            sf_query_output = sf_exec.fetchall()
            print("query after output-->", sf_query_output)
            results = results_handler(sf_query_output)
            print('Results from result handler---->',results)
            snowsql_endTime = get_time()

            for row_output in results:

                row_insert = str(row_output['rows_inserted'])
                row_update = str(row_output['rows_updated'])
                row_delete = str(row_output['rows_deleted'])
                message = str(row_output['message'])
                print(message)
                print("row_insert-->", row_insert)
                print("row_update-->", row_update)
                print("row_delete-->", row_delete)

                print("start time", snowsql_startTime)
                print("end time", snowsql_endTime)

                # ----------------- Log ---------------------------------------------------------------------------
                # log the results in CP_ACTIVITY_DETAIL_LOG

                log_type = "LOG"
                log_CP_Client = insertActivity(sf_exec, logSQLfile, identifiers, log_type, elt_batch_id,
                                               subjectarea, sqlScriptName, row_insert, row_update, row_delete,
                                               message, snowsql_startTime, snowsql_endTime, None, None, None,
                                               parent_batch_id, glue_bucket_name)

    except snowflake.connector.errors.ProgrammingError as e:
        # Log Error details in the CP_ACTIVITY_DETAIL_LOG table.
        snowsql_endTime = get_time()
        log_type = "ERROR"
        print('error->', e)
        log_CP_Client = insertActivity(sf_exec, logSQLfile, identifiers, log_type, elt_batch_id, subjectarea,
                                       sqlScriptName, 0, 0, 0, None, snowsql_startTime,
                                       snowsql_endTime, e.errno, e.msg, e.sqlstate, parent_batch_id, glue_bucket_name)

        print("CRITICAL ERROR WHILE EXECUTING THE SQL -> ", e)
        raise Exception(e)


# This function inserts the log activity details into cp_Activity_log table ------------------------
def insertActivity(cs, logSQLfile, identifiers, log_type, etl_batch_id, subjectarea, sqlScriptName,
                   row_insert, row_update, row_delete, message, snowsql_startTime, snowsql_endTime, errno, emsg,
                   sqlstate, parent_batch_id, glue_bucket_name):
    '''
        Args -
            cs : snowflake cursor
            subjectarea: Retailer  Name
            script_path: SQL script path
            log_type : error/log
            logSQLfile :path of log file where log needs to be written
            message : description about activity
            snowsql_startTime/snowsql_endTime : time when snowsql was started/ended
            sqlscriptname :path where sql script is stored
            row_insert,row_update,row_delete-Number of rows inserted/deleted/updated as part of sql query
            database, schema: identifier values
            logSQLfile: SQL path for insert statement in Log table
            literals: Literals for SQL defined in the ini file
            errno,emsg,sqlstate : error message parameters
            elt_batch_id :Batch id for current batch
        Returns -  Logs result in Log table
    '''

    script_path = logSQLfile
    logQueryfile = read_sql(script_path, glue_bucket_name)
    logQuery = logQueryfile[0].format(**identifiers)
    print("logQuery", logQuery)
    log_literals = {'LOG_TYPE': log_type,
                    'BATCH_ID': etl_batch_id['ELT_BATCH_ID'],
                    'JOB_INPUT_ARGUMENT': str(subjectarea),
                    'SQL_SCRIPT_NAME': sqlScriptName,
                    'ERROR_CODE': str(errno),
                    'ERROR_MESSAGE': str(emsg),
                    'ERROR_STATE': str(sqlstate),
                    'ERROR_STACK_TRACE': None,
                    'ROWS_INSERTED': int(row_insert),
                    'ROWS_UPDATED': int(row_update),
                    'ROWS_DELETED': int(row_delete),
                    'SCRIPT_OUTPUT_MSG': message,
                    'EXEC_START_TIME': snowsql_startTime,
                    'EXEC_END_TIME': snowsql_endTime,
                    'PARENT_BATCH_ID': str(parent_batch_id)}
    print("log_literals", log_literals)
    cs.execute(logQuery, log_literals)
    print("query executed")


# updated by Navya Nelluri dt:05/03/2021
# This function gets current date as per pst timing
def get_time():
    date_utc = datetime.datetime.now(tz=pytz.utc)
    date_pst = str(date_utc.astimezone(timezone('US/Pacific'))).split('.')[0]
    return date_pst
