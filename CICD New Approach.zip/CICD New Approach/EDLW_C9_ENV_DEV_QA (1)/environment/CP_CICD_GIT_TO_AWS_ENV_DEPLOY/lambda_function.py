import sys
import os
from os import path
import boto3
import json
import urllib
import subprocess
import time
from datetime import datetime
from dateutil.relativedelta import relativedelta
import dateutil
import secret_manager
from Activity_logger import logger
from snowflake_logger import lambda_invoke

def checksum_gen(repo_path, item, dict_item_checksum):
    ''' 
    Generate the dictionary with file_name: hash_value created for content of file
    
    Inputs: 
    1. repo_path: tmp path of repository 
    2. item: file name
    3. dict_item_checksum: dictiionary name in which we are storing key:value pairs of file_name: hash_value
    
    Processing:
    1. read file present at repo path
    2. generate hash value form content of file
    3. storing it into dict_item_checksum dictionary.
    
    Output: 
    On Sucess:
    1. dict_item_checksm
    On Failure: 
    1. Error Message
    '''
    with open('%s%s' % (repo_path,item),'r') as file_copy:
        item_content = file_copy.read()
    checksum = hash(item_content)
    dict_item_checksum.update({item:checksum})
    return dict_item_checksum
    
def comparison_list_gen(push_url,deploy_target_branch,source_checksum_dict,target_checksum_dict,tracker_higher_env_item_list,git_rpm_install_tmp_dir,comparison_list,Deployed_items,git_checksum_repo_clone_target_dir):

    ''' 
    Compare the hash value generated for each file from git repo present in temp location before git deployment 
    and hash value generated for the same file from cloned git repo after git deployement and return Deployed_items and comparison_list.
    where comparison_list is list of files whose hash values are not mathching and Deployed_items are those files whose hash values mathces
    
    Inputs:
    1. push_url: Git url for cloaning the branch
    2. deploy_target_branch: target barnch name which will be used for checksum comparison
    3. source_checksum_dict: Dictionary to store file_name:hash_value from target branch before deployement
    4. target_checksum_dict: Dictionary to store file_name:hash_value from target branch after deployement
    5. tracker_higher_env_item_list: list of items which needs to be deployed into target branch(Next Higer Branch)
    6. git_rpm_install_tmp_dir: temp directory path where git package installed
    7. comparison_list: list of items which are failed to deploy into target branch
    8. Deployed_items: list of sucessfully deployed items
    9. git_checksum_repo_clone_target_dir: directory name in which we need to clone the target directory after deployment.
    
    Processing:
    1. Creating path where we need to clone target branch after deployment.
    2. Cloaning the target branch after deployement
    3. Creating target_checksum_dict
    4. Crating Deployed_items, comparison_list
    
    Output:     
    On Sucess:
    1. Deployed_items 
    2. comparison_list
    On Failure: 
    1. Error Message
    '''
    
    target_checksum_repo_path = '%s/%s/' % (git_rpm_install_tmp_dir,git_checksum_repo_clone_target_dir)
    
    
    target_checksum_repo_clone_command = ['git', 'clone', '--branch', deploy_target_branch, push_url, git_checksum_repo_clone_target_dir]
    #print("target_checksum_repo_clone_command: ", target_checksum_repo_clone_command)
    
    #print(subprocess.check_output(target_checksum_repo_clone_command, cwd = git_rpm_install_tmp_dir, stderr=subprocess.STDOUT, shell=False))
    print(os.system("mkdir %s" %git_rpm_install_tmp_dir))
    #print(os.system('cd %s' %git_rpm_install_tmp_dir))
    os.chdir(git_rpm_install_tmp_dir)
    print('Current Dir:', os.system('pwd'))
    print(os.system('ls %s' %git_rpm_install_tmp_dir))
    print(os.system('ls'))
    print(os.system('git clone --branch %s %s %s' %(deploy_target_branch,push_url, git_checksum_repo_clone_target_dir)))
    
    
    print(os.system('ls %s' %target_checksum_repo_path))

    #Generating Dictionary of file_name:hash_value from target branch
    for files in tracker_higher_env_item_list:
        files = files.split(',')[0]
        target_checksum_dict = checksum_gen(target_checksum_repo_path, files, target_checksum_dict)
        #Comparing hash value of each file from source branch with respective hash value of target branch
        if source_checksum_dict[files] == target_checksum_dict[files]:
            Deployed_items= Deployed_items + '\n' + files
        else:
            comparison_list.append(files)  

    print(source_checksum_dict)
    print('---------------------------------------------------------')
    print(target_checksum_dict)    
    
    return Deployed_items, comparison_list
    
def lambda_handler(event, context):

    # DEFINING THE VARIABLES
    lambda_function_name = 'CP_CICD_GIT_TO_AWS_ENV_DEPLOY_CONTAINER'
    #Assigning Parameters passed from Git Workflow
    source_clone_branch_name = event['source_branch']     #"DEV"
    deploy_target_branch = event['deploy_target_branch']  #"DEV_QA_Intrim"
    cp_tracker_name =  event['tracker_name']              #"tracker.csv"
    deploy_branch_flag = event['deploy_branch_flag']      #"Y"
    reset_tracker_flag = event['reset_tracker_flag']      #"N"
    workflow = event['workflow_name']                     #"GIT_TO_DEV_ENV_LAMBDA_TRIGGER.yml"

    parameters = '''{"source_branch":"%s",
    "deploy_target_branch":"%s",
    "tracker_name":"%s",
    "workflow_name":"%s",
    "deploy_branch_flag":"%s",
    "reset_tracker_flag": "%s"}''' % (source_clone_branch_name,deploy_target_branch,cp_tracker_name,workflow, deploy_branch_flag,reset_tracker_flag)

    print('Parameters: \n', parameters)

    #Generationg Batch ID
    IST = dateutil.tz.gettz('Asia/Kolkata')
    current_time = datetime.now(tz=IST).strftime("%H:%M:%S:%f")
    current_date = datetime.now(tz=IST).strftime("%Y%m%d")
    BATCH_ID = abs(hash(current_date+current_time))
    print(BATCH_ID)

    if source_clone_branch_name == 'DEV':
        cp_glue_bucket = 'cp-glue-dev'
        cp_airflow_bucket = 'airflow-wbdi-cp-1'
        cp_int_bucket = 'cp-sf-int-dev'
        tracker_env_list = ['dev','dev-qa','dev-qa-prod']
        deploy_branch_env_list = ['dev-qa','dev-qa-prod']
        utils_suffix = '_dev'
        aws_env_matching_expression = 'dev'
        git_env_matching_expression = 'dev-qa'
        aws_env_allowed_items_extension_list = ['sql','ini','txt','py','json','csv']
        
    if source_clone_branch_name == 'QA':
        cp_glue_bucket = 'cp-glue-qa'
        cp_airflow_bucket = 'airflow-wbdi-cp-1'
        cp_int_bucket = 'cp-sf-int-qa'
        tracker_env_list = ['dev-qa','dev-qa-prod']
        deploy_branch_env_list = ['dev-qa-prod']
        utils_suffix = '_qa'
        aws_env_matching_expression = 'dev-qa'
        git_env_matching_expression = 'dev-qa-prod'
        aws_env_allowed_items_extension_list = ['sql','ini','txt','py','json','csv']

    if source_clone_branch_name == 'PROD':
        cp_glue_bucket = 'cp-glue-prod'
        cp_airflow_bucket = 'airflow-wbdi-cp'
        cp_int_bucket = 'cp-sf-int-prod'
        tracker_env_list = ['dev-qa-prod']
        utils_suffix = ''
        aws_env_matching_expression = 'dev-qa-prod'
        git_env_matching_expression = ''
        aws_env_allowed_items_extension_list = ['sql','ini','py','json','csv']

    tracker_upload_action = 'upload'
    tracker_delete_action = 'delete'
    tracker_env_action_list = [tracker_upload_action,tracker_delete_action]

    git_url = os.getenv('git_url')
    git_user_name = os.getenv('git_user_name')

    user_access = git_user_name + ':' + secret_manager.get_secret_pass(os.getenv('github_token'))
    url = git_url.split('//')
    push_url = "https://"+ user_access + "@" + url[-1]
    #print('push_url:', push_url)
    
    s3 = boto3.client('s3')

    git_repo_clone_source_dir = 'intrim_branch_clone'
    git_repo_clone_target_dir = 'destination_branch_clone'

    git_rpm_install_tmp_dir = '/tmp/GIT_CLONES'

    print(os.system("rm -rf %s" %git_rpm_install_tmp_dir))
    print(os.system("mkdir %s" %git_rpm_install_tmp_dir))

    source_repo_path = '%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_source_dir)
    target_repo_path = '%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)

    tracker_contents = ''
    LOG_TYPE = 'SUCCESS'


    cur_env_item_list = [] #list of all the items to be deployed in current AWS env
    glue_cur_env_item_list = [] #list of all the Glue items to be deployed in current AWS env
    airflow_cur_env_item_list = [] #list of all the Airflow items to be deployed in current AWS env
    notification_cur_env_item_list = [] #list of all the Notification items to be deployed in current AWS env
    lambda_cur_env_tracker_ln_list = [] #list of all the lambda items which we are not deploying in current AWS env
    lambda_cur_env_item_list = [] #list of all the lambda items which we are not deploying in current AWS env
    unique_folder_structure_list = [] #list of all the Distinct Folder structures to be created in the target repo clone directory
    tracker_higher_env_item_list = [] #list of all the items to be deployed in the higher GIT Branch
    env_specific_file_name_list = [] #list of all the filenames to be deployed in current AWS env (action,env and other columns are not in this list)
    aws_env_uploaded_item_list = [] #list of all the items uploaded in current AWS env
    aws_env_deleted_item_list = [] #list of all the items deleted in current AWS env
    aws_env_deployed_list = [] #list of all the items uploaded or deleted in/from current AWS env
    tracker_wrong_env_items_list = [] #list of all items with wrong env in tracker
    tracker_wrong_action_items_list = [] #list of all items with wrong action in tracker

    env_specific_files_text = '' #Variable to pass to the logger for printing items to be deployed in aws current env
    tracker_wrong_env_items_list_text = '' #Variable to pass to the logger for printing items with wrong env in tracker
    tracker_wrong_action_items_list_text = '' #Variable to pass to the logger for printing items with wrong action in tracker
    names_of_successfull_deployed_object = '' #Variable to pass to the logger for printing items deployed in aws current env or in higher git branch
    comparison_list = [] #List of itmes for reconciliation validation
    reconciliation_objects_text = '' #Variable to pass to the logger for printing items mentioned in tracker but not deployed
    git_last_modified_file_name = '' #Variable used to track the last pushed item in the remote git branch
    log_details_list = [] # List of all the log details dictionaries

    try:
        EXEC_START_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
        TASK = 'CLONE SOURCE BRANCH-- ' + source_clone_branch_name
        
        source_branch_clone_command = ['git', 'clone', '--branch', source_clone_branch_name, push_url, git_repo_clone_source_dir]
        #print("source_branch_clone_command: ", source_branch_clone_command)
        
        print(subprocess.check_output(source_branch_clone_command, cwd = git_rpm_install_tmp_dir, stderr=subprocess.STDOUT, shell=False))
        
        print(os.system('ls %s' %source_repo_path))
        
        LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
        log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
        #log_details_list.append(log_details)
        
        #CLONE THE REMOTE GIT REPOSITORY FROM TARGET BRANCH
        if deploy_branch_flag == 'Y':
            TASK = 'CLONE TARGET BRANCH-- ' + deploy_target_branch
            
            deploy_target_branch_clone_command = ['git', 'clone', '--branch', deploy_target_branch, push_url, git_repo_clone_target_dir]
            
            print("deploy_target_branch_clone_command: ", deploy_target_branch_clone_command)
        
            print(subprocess.check_output(deploy_target_branch_clone_command, cwd = git_rpm_install_tmp_dir, stderr=subprocess.STDOUT, shell=False))
            
            print(os.system('ls %s' %target_repo_path))

            LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            log_details_list.append(log_details)    

        TASK = 'READING TRACKER FILE CONTENTS'
        with open('%s%s' % (source_repo_path,cp_tracker_name),'r') as file_copy:
            tracker_contents = file_copy.read()
        tracker_lines = tracker_contents.splitlines()
        
        TASK = 'CREATING ENV SPECIFIC ITEMS LIST FROM TRACKER'
        cur_env_item_list = list(filter(lambda env_specific_filter_items: aws_env_matching_expression in env_specific_filter_items, tracker_lines))  #env_specific_filter_items is function we are using this function to apply the filter
        print(cur_env_item_list)
        
        TASK = 'CREATING ENV SPECIFIC GLUE ITEMS LIST FROM TRACKER'
        glue_cur_env_item_list = list(filter(lambda glue_env_specific_filter_items: 'Glue/' in glue_env_specific_filter_items, cur_env_item_list))
        print(glue_cur_env_item_list)
        
        TASK = 'CREATING ENV SPECIFIC AIRFLOW ITEMS LIST FROM TRACKER'
        airflow_cur_env_item_list = list(filter(lambda airflow_env_specific_filter_items: 'Airflow/' in airflow_env_specific_filter_items, cur_env_item_list))   
        print(airflow_cur_env_item_list)
        
        TASK = 'CREATING ENV SPECIFIC NOTIFICATION ITEMS LIST FROM TRACKER'
        notification_cur_env_item_list = list(filter(lambda notification_env_specific_filter_items: 'Notification/' in notification_env_specific_filter_items, cur_env_item_list))   
        print(notification_cur_env_item_list)
        
        TASK = 'CREATING ENV SPECIFIC LAMBDA ITEMS LIST FROM TRACKER'
        lambda_cur_env_tracker_ln_list = list(filter(lambda lambda_env_specific_filter_items: 'lambda/' in lambda_env_specific_filter_items, cur_env_item_list))   
        print(lambda_cur_env_tracker_ln_list)
        for lambda_cur_env_item in lambda_cur_env_tracker_ln_list:
            lambda_cur_env_item_list.append(lambda_cur_env_item.split(',')[0])
        print(lambda_cur_env_item_list)
        
        
        TASK = 'CREATING GIT HIGHER ENV ITEMS LIST FROM TRACKER'
        tracker_higher_env_item_list = list(filter(lambda tracker_higher_env_item_filter_items: git_env_matching_expression in tracker_higher_env_item_filter_items, tracker_lines))

        print('tracker_higher_env_item_list:',tracker_higher_env_item_list)
        
        #Creation of unique folder structure list
        TASK = 'CREATING GIT BRANCH ENV SPECIFIC FOLDER STRUCTURE LIST FROM TRACKER'
        for tracker_higher_env_items in tracker_higher_env_item_list:
            tracker_higher_env_file_path_list = tracker_higher_env_items.split(',')
            tracker_higher_env_file_path = tracker_higher_env_file_path_list[0]
            tracker_higher_env_folder_structure = tracker_higher_env_file_path.rsplit('/',1)[0]
            if tracker_higher_env_folder_structure not in unique_folder_structure_list:
                unique_folder_structure_list.append(tracker_higher_env_folder_structure)
        print(unique_folder_structure_list)
        
        TASK= 'CREATING LIST OF ITEMS WHERE ENV OR ACTION IS WRONG'
        wrong_env_recon_list = []
        for tracker_each_line in tracker_lines[1:]:
            tracker_item_cols = tracker_each_line.split(',')
            if tracker_item_cols[2] not in ['dev','dev-qa','dev-qa-prod']:
                tracker_wrong_env_items_list.append(tracker_each_line)
                wrong_env_recon_list.append(tracker_item_cols[0])
            if tracker_item_cols[1].lower() not in ['upload','delete']:
                tracker_wrong_action_items_list.append(tracker_each_line)
        print(tracker_wrong_env_items_list)
        tracker_wrong_env_items_list_text = '/n'.join(tracker_wrong_env_items_list)
        print(tracker_wrong_action_items_list)
        tracker_wrong_action_items_list_text = '/n'.join(tracker_wrong_action_items_list)
        
        if len(tracker_wrong_env_items_list) != 0 or len(tracker_wrong_action_items_list) != 0:
            TASK = 'TRACKER CONTENTS PRECHECK VALIDATION'
            LOG_TYPE = 'ERROR'
            LOG_MSG = TASK + ' FAILED DUE TO WRONG TRACKER CONTENTS'
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            log_details_list.append(log_details)
            
        if deploy_branch_flag == 'Y':
            #FOLDER STRUCTURE CREATION IN TARGET BRANCH DIRECTORY
            EXEC_START_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
            TASK = 'FOLDER STRUCTURE CREATION IN TARGET BRANCH DIRECTORY'
            for folder_struct in unique_folder_structure_list:
                folder_structure_in_tracker = folder_struct.split('/')
                folder_structure = folder_structure_in_tracker[0]
                
                print(os.system("cd %s && mkdir %s" % (target_repo_path,folder_structure)))
                        
                for folder_name in folder_structure_in_tracker[1:]:
                    print(os.system("cd %s%s && mkdir %s" % (target_repo_path,folder_structure,folder_name)))
                    folder_structure = folder_structure + "/" + folder_name
                    print(folder_structure)

    #DEPLOY FILES TO AWS ENVIRONMENT
        
        TASK = 'DEPLOY GLUE FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
        for glue_cur_env_items in glue_cur_env_item_list:
            print(glue_cur_env_items)
            glue_list_cols = glue_cur_env_items.split(",")
            tracker_col_env = glue_list_cols[2].lower() #env of file mentioned in tracker
            tracker_col_action = glue_list_cols[1].lower() #action mentioned in the tracker
            tracker_col_file_name = glue_list_cols[0] #full path of the files mentioned in the tracker
                
            tracker_file = tracker_col_file_name.split('/')
            tracker_modified_file_name = tracker_col_file_name.replace(tracker_file[0] + "/" , "") #Removing 'Glue/' from the file path
            tracker_col_file_extension = tracker_col_file_name.split('.')[1] #Extension of the file
            
            if tracker_col_file_extension in aws_env_allowed_items_extension_list: #Matching to the particular extension list allowed to move to current aws env
                if tracker_col_action == tracker_upload_action: # If 'Upload' action is mentioned in the tracker
                    TASK = 'UPLOAD GLUE FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                    print('The file to upload is: %s' % tracker_col_file_name)
                    s3.upload_file("%s%s" % (source_repo_path,tracker_col_file_name), cp_glue_bucket, "%s" % tracker_modified_file_name) #Uploading file to aws env
                    aws_env_uploaded_item_list.append(tracker_col_file_name) # Appending the file name to the upload list
                    print('---------------------------------------------------------------------------------------------')
                
                elif tracker_col_action == tracker_delete_action: # If 'Delete' action is mentioned in the tracker
                    TASK = 'DELETE GLUE FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                    print('The file to Delete is: %s' % tracker_col_file_name)
                    s3.delete_object(Bucket = cp_glue_bucket , Key = "%s" % tracker_modified_file_name)# deleting file from aws env
                    aws_env_deleted_item_list.append(tracker_col_file_name) #Appending the file to the delete list
                    print('---------------------------------------------------------------------------------------------')
                
                else:
                    print('Upload or Delete option is not mentioned in the tracker...The operation mentioned %s cannot be performed!!' % tracker_col_action)
                    print('---------------------------------------------------------------------------------------------')
                
           
        TASK = 'DEPLOY AIRFLOW FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
        for airflow_cur_env_items in airflow_cur_env_item_list:
            print(airflow_cur_env_items)
            airflow_list_cols = airflow_cur_env_items.split(",")
            tracker_col_env = airflow_list_cols[2].lower()
            tracker_col_action = airflow_list_cols[1].lower()
            tracker_col_file_name = airflow_list_cols[0]
                
            tracker_file = tracker_col_file_name.split('/')
            tracker_modified_file_name = tracker_col_file_name.replace(tracker_file[0] + "/" , "") #Removing 'Airflow/' from the file path
            tracker_col_file_extension = tracker_col_file_name.split('.')[1]
            tracker_modified_file_name = tracker_modified_file_name.replace('DAGs','DAGsV2.6')
            
            tracker_file_struct = tracker_modified_file_name.split('/')
            tracker_modified_airflow_file_name = tracker_file_struct[0]
            airflow_file_name = tracker_file_struct[-1]
            
            if tracker_col_file_extension in aws_env_allowed_items_extension_list:
                if tracker_file_struct[-2].lower() == 'utils': # If the file is in utils folder under DAGs folder
                    for i in tracker_file_struct[1:-1]:
                        tracker_modified_airflow_file_name = tracker_modified_airflow_file_name + '/' + i
                        print(tracker_modified_airflow_file_name)
                
                    tracker_modified_airflow_file_name = tracker_modified_airflow_file_name + utils_suffix + '/' + airflow_file_name #Adding env specific suffix to the utils folder 
                
                    if tracker_col_action == tracker_upload_action:
                        TASK = 'UPLOAD AIRFLOW UTILS FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                        print('The file to upload is: %s' % tracker_col_file_name)
                        s3.upload_file("%s%s" % (source_repo_path,tracker_col_file_name), cp_airflow_bucket, "%s" % tracker_modified_airflow_file_name)
                        aws_env_uploaded_item_list.append(tracker_col_file_name)
                        print('---------------------------------------------------------------------------------------------')
                
                    elif tracker_col_action == tracker_delete_action:
                        TASK = 'DELETE AIRFLOW UTILS FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                        print('The file to Delete is: %s' % tracker_col_file_name)
                        s3.delete_object(Bucket = cp_airflow_bucket , Key = "%s" % tracker_modified_airflow_file_name)
                        aws_env_deleted_item_list.append(tracker_col_file_name)
                        print('---------------------------------------------------------------------------------------------')
                
                    else:
                        print('Upload or Delete option is not mentioned in the tracker...The operation mentioned %s cannot be performed!!' % tracker_col_action)
                        print('---------------------------------------------------------------------------------------------')
                else: # If the file is not in utils folder
                    if tracker_col_action == tracker_upload_action:
                        TASK = 'UPLOAD AIRFLOW DAG & OTHER FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                        print('The file to upload is: %s' % tracker_col_file_name)
                        s3.upload_file("%s%s" % (source_repo_path,tracker_col_file_name), cp_airflow_bucket, "%s" % tracker_modified_file_name)
                        aws_env_uploaded_item_list.append(tracker_col_file_name)
                        print('---------------------------------------------------------------------------------------------')
                
                    elif tracker_col_action == tracker_delete_action:
                        TASK = 'DELETE AIRFLOW DAG & OTHER FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                        print('The file to Delete is: %s' % tracker_col_file_name)
                        s3.delete_object(Bucket = cp_airflow_bucket , Key = "%s" % tracker_modified_file_name)
                        aws_env_deleted_item_list.append(tracker_col_file_name)
                        print('---------------------------------------------------------------------------------------------')
                
                    else:
                        print('Upload or Delete option is not mentioned in the tracker...The operation mentioned %s cannot be performed!!' % tracker_col_action)
                        print('---------------------------------------------------------------------------------------------')
            
        #DEPLOY FILES TO AWS ENVIRONMENT
        TASK = 'DEPLOY NOTIFICATION FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
        for notification_cur_env_items in notification_cur_env_item_list:
            print(notification_cur_env_items)
            notification_list_cols = notification_cur_env_items.split(",")
            tracker_col_env = notification_list_cols[2].lower() #env of file mentioned in tracker
            tracker_col_action = notification_list_cols[1].lower() #action mentioned in the tracker
            tracker_col_file_name = notification_list_cols[0] #full path of the files mentioned in the tracker
                
            tracker_file = tracker_col_file_name.split('/')
            tracker_modified_file_name = tracker_col_file_name.replace(tracker_file[0] + "/" , "") #Removing 'Notification/' from the file path
            tracker_col_file_extension = tracker_col_file_name.split('.')[1] #Extension of the file
            
            if tracker_col_file_extension in aws_env_allowed_items_extension_list: #Matching to the particular extension list allowed to move to current aws env
                if tracker_col_action == tracker_upload_action: # If 'Upload' action is mentioned in the tracker
                    TASK = 'UPLOAD NOTIFICATION FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                    print('The file to upload is: %s' % tracker_col_file_name)
                    s3.upload_file("%s%s" % (source_repo_path,tracker_col_file_name), cp_glue_bucket, "%s" % tracker_modified_file_name) #Uploading file to aws env
                    aws_env_uploaded_item_list.append(tracker_col_file_name) # Appending the file name to the upload list
                    print('---------------------------------------------------------------------------------------------')
                
                elif tracker_col_action == tracker_delete_action: # If 'Delete' action is mentioned in the tracker
                    TASK = 'DELETE GLUE FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
                    print('The file to Delete is: %s' % tracker_col_file_name)
                    s3.delete_object(Bucket = cp_glue_bucket , Key = "%s" % tracker_modified_file_name)# deleting file from aws env
                    aws_env_deleted_item_list.append(tracker_col_file_name) #Appending the file to the delete list
                    print('---------------------------------------------------------------------------------------------')
                
                else:
                    print('Upload or Delete option is not mentioned in the tracker...The operation mentioned %s cannot be performed!!' % tracker_col_action)
                    print('---------------------------------------------------------------------------------------------')
                                    
        aws_env_deployed_list.extend(aws_env_uploaded_item_list + aws_env_deleted_item_list) #Appending the uploaded and deleted files in the list
        
        # Appending new line character to list for logging and creating the string of filenames to be deployed in to current aws env
        for cur_env_items in cur_env_item_list:
            env_specific_files = cur_env_items.split(',')
            env_specific_file_name_list.append(env_specific_files[0])
            env_specific_files_text = env_specific_files_text + env_specific_files[0] + '\n' 
        
        comparison_list = list(set(env_specific_file_name_list) - set(aws_env_deployed_list) - set(lambda_cur_env_item_list)) # Creating the comparison list for checking
        
        for comparison_list_objects in comparison_list:
            reconciliation_objects_text = reconciliation_objects_text + comparison_list_objects + '\n' # For logger creating the text of filename which are not deployed instead of being in the 
                
        aws_deployed_items = 'The files deployed to AWS Environment are: \n\n'    # Creating a string of items and actions for putting it into the logger
        for aws_env_uploaded_items in aws_env_uploaded_item_list:
            aws_deployed_items = aws_deployed_items + aws_env_uploaded_items + '----------Upload' + '\n'
        for aws_env_deleted_items in aws_env_deleted_item_list:
            aws_deployed_items = aws_deployed_items + aws_env_deleted_items + '----------Delete' + '\n'
            
        names_of_successfull_deployed_object = aws_deployed_items
        if len(comparison_list) == 0: # If the comparison list is empty, all the files are properly deployed into aws env; so SUCCESS
            TASK = 'DEPLOY FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'    
            LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            log_details_list.append(log_details)
            EXEC_END_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
            lambda_invoke('LOG',BATCH_ID, lambda_function_name, source_clone_branch_name, deploy_target_branch, parameters, 'AWS Deployment Completed Sucessfully', names_of_successfull_deployed_object, reconciliation_objects_text, EXEC_START_TIME, EXEC_END_TIME)
            
            
        else: # Otherwise the operation will throw an error
            TASK = 'DEPLOY FILES TO AWS ' + source_clone_branch_name + ' ENVIRONMENT'
            LOG_TYPE = 'ERROR'
            LOG_MSG = TASK + ' FAILED DUE TO (RECONCILIATION VALIDATION ERROR) :' + reconciliation_objects_text + 'is/are not deployed to AWS ' + source_clone_branch_name + 'environment'
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            log_details_list.append(log_details)
            EXEC_END_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
            lambda_invoke('RECON_ERROR',BATCH_ID, lambda_function_name, source_clone_branch_name, deploy_target_branch, parameters, 'AWS Deployment Failed', names_of_successfull_deployed_object, reconciliation_objects_text, EXEC_START_TIME, EXEC_END_TIME)

        #Clearing out the values for the logger common set of variables
        names_of_successfull_deployed_object = '' 
        comparison_list.clear()
        reconciliation_objects_text = ''
        last_commit_id = ''
        
        IST = dateutil.tz.gettz('Asia/Kolkata')
        current_date = datetime.now(tz=IST)
        time_period_in_days = int(os.getenv('time_period_in_days_to_get_log_from_target_branch'))
        date_before_mentioned_time_period = current_date - relativedelta(days= time_period_in_days)
        date_before_mentioned_time_period_str = date_before_mentioned_time_period.strftime("%Y-%m-%d")
        print("Date before %s days from today: " % time_period_in_days + date_before_mentioned_time_period_str)
        
        TASK = 'DEFINING GIT OPERATIONS'
        git_branch = ['git', 'branch','-a'] #Command to find the current git branch
        git_status = ['git', 'status'] #Command to show git status
        config_email = ['git', 'config', '--global', 'user.email', "Ritesh.Dedhia@warnerbros.com"] #Git command to configure user email
        config_name = ['git', 'config', '--global', 'user.name' , "Ritesh Dedhia"] #Git command to configure user name
        #git_log_last_commit_id = ['''%s/usr/bin/git''' % git_rpm_install_tmp_dir, '''log''', '''-1''', '''--pretty=format:"%h"'''] #Git command to fetch the last commit id
        
        TASK = 'DEFINING ADD COMMIT PUSH FUNCTION'
        git_add_commit_delay = int(os.getenv('git_add_commit_delay'))
        def git_add_commit(git_directory_of_the_file):
            git_add = ['git', 'add', '--all'] #Git command to add file to stage area
            git_commit = ['git', 'commit', '-m', "files are modified"] #Git command to commit staged file
            git_unstage = ['git', 'rm', '-r', '--cached', '.']
            
            print(subprocess.Popen(git_unstage , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file)))
            print('---------------------------------------------------------------------------------------------')
            time.sleep(5)            
            print(subprocess.Popen(git_add , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file))) #Running the git command using subprocess
            print('---------------------------------------------------------------------------------------------')
            time.sleep(git_add_commit_delay)
            print(subprocess.Popen(git_commit , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file)))
            print('---------------------------------------------------------------------------------------------')

        if deploy_branch_flag == "Y" and deploy_target_branch != "NA" and git_env_matching_expression != '': #Condition for deployment to the next higher branch in Git
            
            EXEC_START_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+datetime.now(tz=IST).strftime(" %H:%M:%S")
            TASK = 'PERFORMING BASIC GIT OPERATIONS'
            print(subprocess.Popen(git_branch , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
            print('---------------------------------------------------------------------------------------------')
            #time.sleep(2)
            print(subprocess.Popen(git_status , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
            print('---------------------------------------------------------------------------------------------')
            #time.sleep(2)
            print(subprocess.Popen(config_email , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
            print('---------------------------------------------------------------------------------------------')
            #time.sleep(2)
            print(subprocess.Popen(config_name , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
            print('---------------------------------------------------------------------------------------------')
            #time.sleep(2)
            print(subprocess.Popen(['git','remote','add','origin2',push_url], cwd='%s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir))) # Adding new remote server origin2 to the repo
            print('---------------------------------------------------------------------------------------------')
            #time.sleep(2)
            
            #git_last_commit_id =subprocess.check_output(git_log_last_commit_id , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)) #Assigning the last pushed filenames into a variable
            #last_commit_id = git_last_commit_id.decode('utf-8')
            #print("Last commit id after last lambda execution & deployment: %s " % last_commit_id)
            
            TASK = 'GIT DEPLOYMENT OF TRACKER'
            print(os.system("'cp' -r %s%s %s%s" % (source_repo_path,cp_tracker_name,target_repo_path,cp_tracker_name))) #Copy the tracker into the target branch
            git_add_commit(git_repo_clone_target_dir) #Push the tracker into the target branch
            time.sleep(5)
            
            TASK = 'GENERATING THE COMPARISON LIST'
            comparison_list = []
            source_checksum_dict = {}
            target_checksum_dict = {}
            Deployed_items = ''
            
            tracker_higher_env_item_list_upload = list(filter(lambda tracker_higher_env_item_filter_items: tracker_upload_action in tracker_higher_env_item_filter_items , tracker_higher_env_item_list))
            print('tracker_higher_env_item_list with upload action:',tracker_higher_env_item_list_upload)
            
            for tracker_higher_env_objects in tracker_higher_env_item_list: # Looping for the files to deploy in the higher git branch
                tracker_higher_env_object_lines = tracker_higher_env_objects.split(',')
                TASK = 'GIT DEPLOYMENT OF THE FILE - ' + tracker_higher_env_object_lines[0]
                
                if tracker_higher_env_object_lines[1] == tracker_upload_action:
                    print(os.system("'cp' -r %s%s %s%s" % (source_repo_path,tracker_higher_env_object_lines[0],target_repo_path,tracker_higher_env_object_lines[0]))) # Copy the file from the source branch dir to target branch dir
                    print("The file to add to the next higher branch is: " + tracker_higher_env_object_lines[0])
                    files = tracker_higher_env_object_lines[0]
                    source_checksum_dict = checksum_gen(source_repo_path, files, source_checksum_dict) 
                
                if tracker_higher_env_object_lines[1] == tracker_delete_action:
                    print(os.system('rm %s%s' % (target_repo_path,tracker_higher_env_object_lines[0])))
                    print("The file to remove from the next higher branch is: " + tracker_higher_env_object_lines[0])
            
            git_add_commit(git_repo_clone_target_dir) #Push files into the target branch
            time.sleep(5)
            git_push = ['git', 'push', 'origin2', deploy_target_branch] #Git command to push commited file
            print(subprocess.call(git_push , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
            print('---------------------------------------------------------------------------------------------')
            time.sleep(30)
            
            TASK = 'GENERATING COMPARISON LIST and DEPLOYED ITEMS LIST '
            #CLONE THE REMOTE GIT REPOSITORY FROM TARGET BRANCH FOR RECONCILIATION
            git_checksum_repo_clone_target_dir = 'target_checksum_clone'
            Deployed_items,comparison_list = comparison_list_gen(push_url,deploy_target_branch,source_checksum_dict,target_checksum_dict,tracker_higher_env_item_list_upload,git_rpm_install_tmp_dir,comparison_list,Deployed_items,git_checksum_repo_clone_target_dir)
                    
            print("Final Comparison list: \n")
            print(comparison_list)
           
            TASK = 'RETRY TO PUSH THOSE FILES WHICH WERE FAILED TO DEPLOY FOR THE FIRST TIME'
            for failed_items in comparison_list:
                print("The file to add to the next higher branch for another try is: " + failed_items)
            
            if len(comparison_list) != 0:
                git_add_commit(git_repo_clone_target_dir)
                time.sleep(5)
                git_push = ['git', 'push', 'origin2',deploy_target_branch] #Git command to push commited file
                print(subprocess.call(git_push , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
                print('---------------------------------------------------------------------------------------------')
                time.sleep(5)
            
                comparison_list = []
                target_checksum_dict = {}
                Deployed_items = ''
                    
                
                TASK = 'GENERATING COMPARISON LIST and DEPLOYED ITEMS LIST FOR REDEPLOYMENT '
                #CLONE THE REMOTE GIT REPOSITORY FROM TARGET BRANCH FOR REDEPLOY RECONCILIATION
                git_checksum_repo_clone_target_dir = 'target_redeploy_checksum_clone'
                Deployed_items,comparison_list = comparison_list_gen(push_url,deploy_target_branch,source_checksum_dict,target_checksum_dict,tracker_higher_env_item_list_upload,git_rpm_install_tmp_dir,comparison_list,Deployed_items,git_checksum_repo_clone_target_dir)
                
                print("Final Comparison list: \n")
                print(comparison_list)
            
            TASK = 'FINAL COMPARISON LIST GENERATION'
            
            reconciliation_objects_text_head = '\n\n\nFiles present in tracker but not deployed to the higher branch are: \n\n'
            reconciliation_objects_text_tail = ''
            
            names_of_successfull_deployed_object = 'Final list of deployed items: \n' + '\n' + Deployed_items + '\n' #For logging            
            comparison_list += wrong_env_recon_list
            for comparison_list_objects in comparison_list:
                reconciliation_objects_text_tail = reconciliation_objects_text_tail + comparison_list_objects + '\n'
                
            reconciliation_objects_text = reconciliation_objects_text + reconciliation_objects_text_head + reconciliation_objects_text_tail
            

            if len(comparison_list) == 0: #If the comparison list is empty the SUCCESS
                TASK = 'DEPLOY FILES TO THE BRANCH - ' + deploy_target_branch + ' & RECON ACTIVITY: FINAL COMPARISON BETWEEN DEPLOYED FILES LIST AND TRACKER FILES'
                LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
                log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
                EXEC_END_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+datetime.now(tz=IST).strftime(" %H:%M:%S")
                lambda_invoke('LOG',BATCH_ID, lambda_function_name, source_clone_branch_name, deploy_target_branch, parameters, 'Git Branch Deployment Completed Sucessfully', Deployed_items, reconciliation_objects_text_tail, EXEC_START_TIME, EXEC_END_TIME)
                log_details_list.append(log_details)

            else: #If the comparison list is not null then ERROR
                TASK = 'RECON ACTIVITY: FINAL COMPARISON BETWEEN DEPLOYED FILES LIST AND TRACKER FILES'
                LOG_TYPE = 'ERROR'
                LOG_MSG = TASK + ' FAILED DUE TO (RECONCILIATION VALIDATION ERROR) : ' + reconciliation_objects_text_tail + 'is/are not deployed to ' + deploy_target_branch
                log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
                EXEC_END_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+datetime.now(tz=IST).strftime(" %H:%M:%S")
                lambda_invoke('RECON_ERROR',BATCH_ID, lambda_function_name, source_clone_branch_name, deploy_target_branch, parameters, 'Git Branch Deployment Failed', Deployed_items, reconciliation_objects_text_tail, EXEC_START_TIME, EXEC_END_TIME)
                log_details_list.append(log_details)
    
        LOG_TYPE = 'SUCCESS'
        
        if reset_tracker_flag == "Y":
            EXEC_START_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
            #Clearing out the values for the logger common set of variables
            names_of_successfull_deployed_object = '' 
            comparison_list.clear()
            reconciliation_objects_text = ''
            
            tracker_reset_branch_name = 'DEV'
            git_repo_clone_tracker_reset_dir = 'tracker_reset_DEV_branch_clone'
            tracker_reset_branch_clone_command = ['git', 'clone', '--branch', tracker_reset_branch_name, push_url, git_repo_clone_tracker_reset_dir]
             
            #CLONE THE REMOTE GIT REPOSITORY FROM RESET TRACKER BRANCH
            TASK = 'CLONE THE REMOTE GIT REPOSITORY FROM RESET TRACKER BRANCH'
            
            print(subprocess.check_output(tracker_reset_branch_clone_command, cwd = git_rpm_install_tmp_dir, stderr=subprocess.STDOUT, shell=False))
            
            print(os.system('ls %s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))

            tracker_reset_repo_path = '%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)
            with open('%s%s' % (tracker_reset_repo_path,cp_tracker_name),'r') as file_copy: # Reading source tracker for resetting
                tracker_contents = file_copy.read()
            
            tracker_lines =  tracker_contents.splitlines()
            
            lines = []
            
            #Removing the tracker rows which are having 'dev-qa-prod' as environment
            TASK = 'RESET TRACKER CONTENTS'
            for i in range(len(tracker_lines)):
                each_line_from_tracker=tracker_lines[i]
                print(each_line_from_tracker);
                print("     ")
                cols = each_line_from_tracker.split(",")
                tracker_col_env = cols[2].lower()
                if tracker_col_env != "dev-qa-prod":
                    lines.append(tracker_lines[i])
            
            print(lines)
            
            with open('%s%s' % (tracker_reset_repo_path,cp_tracker_name), "w") as writing_file: # Writting the modified contents to the tracker
                for ln in lines:
                    writing_file.write(ln + "\n")
                writing_file.close()
            
            TASK = 'EXECUTING BASIC GIT OPERATIONS'
            print(subprocess.Popen(git_branch , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(git_status , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(config_email , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(config_name , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            print(subprocess.Popen(['git','remote','add','origin3',push_url], cwd='%s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir))) # Adding new remote server origin2 to the repo
            print('---------------------------------------------------------------------------------------------')
            
            TASK = 'PUSH THE MODIFIED TRACKER TO THE ' + tracker_reset_branch_name + ' BRANCH'
            
            git_add = ['git', 'add', '--all'] #Git command to add file to stage area
            git_commit = ['git', 'commit', '-m', "Tracker Reset"] #Git command to commit staged file
            git_unstage = ['git', 'rm', '-r', '--cached', '.']
            
            print(subprocess.Popen(git_unstage , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            time.sleep(3)            
            print(subprocess.Popen(git_add , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir))) #Running the git command using subprocess
            print('---------------------------------------------------------------------------------------------')
            time.sleep(5)
            print(subprocess.Popen(git_commit , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')  
            git_push_tracker = ['git', 'push', '--force', 'origin3','%s:%s' % (tracker_reset_branch_name,tracker_reset_branch_name)] #Git command to push commited file
            time.sleep(2)   
            print(subprocess.call(git_push_tracker , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir)))
            print('---------------------------------------------------------------------------------------------')
            
            TASK = 'CHECKING FOR THE TRACKER RESET OPERATION'
            git_log_tracker_reset = ['''git''', '''log''', '''--name-only''', '''--oneline''', '''--since="10 seconds ago"''', '''origin3/%s''' % tracker_reset_branch_name] #Git command to show pushed files since last 5 seconds
            git_last_modified_files_log = subprocess.check_output(git_log_tracker_reset , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_tracker_reset_dir))
            
            if git_last_modified_files_log.decode('utf-8') == '':
                git_last_modified_file_name = ''
            else:
                git_last_modified_file_name = git_last_modified_files_log.decode('utf-8').splitlines()[1].strip()
            
            TASK = 'RESET TRACKER IN DEV BRANCH'
            
            if git_last_modified_file_name == 'tracker.csv':
                names_of_successfull_deployed_object = 'Deployed item: \n\n tracker.csv'
                LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
                log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
                EXEC_END_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
                lambda_invoke('LOG',BATCH_ID, lambda_function_name, source_clone_branch_name, deploy_target_branch, parameters, LOG_MSG, names_of_successfull_deployed_object, reconciliation_objects_text, EXEC_START_TIME, EXEC_END_TIME)
                log_details_list.append(log_details)
                
            else:
                reconciliation_objects_text = 'tracker.csv'
                LOG_TYPE = 'ERROR'
                LOG_MSG = TASK + " FAILED DUE TO (RECONCILIATION VALIDATION ERROR) : Tracker is not updated in the DEV branch"
                log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
                EXEC_END_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
                lambda_invoke('RECON_ERROR',BATCH_ID, lambda_function_name, source_clone_branch_name, deploy_target_branch, parameters, LOG_MSG, names_of_successfull_deployed_object, 'tracker.csv', EXEC_START_TIME, EXEC_END_TIME)
                log_details_list.append(log_details)    

    except Exception as err: # Exception block
        print(TASK + " FAILED DUE TO: " + str(err))
        LOG_TYPE = 'ERROR'
        LOG_MSG = TASK + " FAILED DUE TO: " + str(err)
        log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
        EXEC_END_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
        lambda_invoke(LOG_TYPE,BATCH_ID, lambda_function_name, source_clone_branch_name, deploy_target_branch, parameters, LOG_MSG, names_of_successfull_deployed_object, comparison_list, EXEC_START_TIME, EXEC_END_TIME)
        log_details_list.append(log_details)
    
    logger(lambda_function_name, parameters, log_details_list, tracker_contents, tracker_wrong_env_items_list_text, tracker_wrong_action_items_list_text) #Calling the logger function
