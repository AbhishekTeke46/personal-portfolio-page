"""
This is DAG code for CICDTEST batch execution.
Author:
Modification Log:
-------------------------------------------------------------------------------
Date                Author             Description
-------------------------------------------------------------------------------
12/31/2021         Abhishek Teke       CICDTEST Retailer Dag
11/17/2023         Subhasmita Sahu     Common framework integration changes (ENV Variable, elif ENV=='PROD', dbdetails, App)
-------------------------------------------------------------------------------
"""
import logging
import airflow
import boto3
import time
from airflow.models import DAG, Variable
from datetime import datetime
from airflow.contrib.hooks.snowflake_hook import SnowflakeHook
from airflow.operators.python_operator import PythonOperator
from airflow.exceptions import AirflowException
import sys
v_schedule_interval= "00 20 * * 0"
#ENV=Variable.get("ENV")
ENV='QA'
if ENV=='DEV':
    dir_dag_utils=Variable.get("dir_dag_utils_dev")
    from utils_dev import snowflake_hook
    from utils_dev import glue_jobrun_operator
    v_schedule_interval=None
elif ENV=='QA':
    dir_dag_utils=Variable.get("dir_dag_utils_qa")
    from utils_qa import snowflake_hook
    from utils_qa import glue_jobrun_operator
    v_schedule_interval=None
elif ENV=='PROD':
    dir_dag_utils=Variable.get("dir_dag_utils_prod")
    from utils import snowflake_hook
    from utils import glue_jobrun_operator
sys.path.insert(0,dir_dag_utils)

#---Retailer id for JOBRUN-------------------------
subjectarea = 'CICDTEST'
app = 'cp' #change-1
dbdetails = Variable.get("cp_dbdetails_qa") #change-2

#-----------Arguments for executing DAG------------
default_args = {
    'owner': 'CPAnalyticsETLTeam@wbd.com',
    'start_date': datetime(2022, 2, 14),
    'email': ['CPAnalyticsETLTeam@wbd.com'],
    'depends_on_past': False,
    'wait_for_upstream': True,
    'email_on_failure': True,
    'retries': 0,
}


dag = DAG('CP_CICDTEST_DAG_QA', description='CICDTEST data load ',schedule_interval=v_schedule_interval,
          max_active_runs=1,default_args=default_args,catchup=False)

#-----------function to generate parent batch id------------------------------------------------
generate_parent_batch_id = PythonOperator(task_id="generate_parent_batch_id",
                                          python_callable=snowflake_hook.pass_batchid_to_next_task,
                                          provide_context=True,
                                          op_kwargs={'dbdetails': dbdetails}, #change-3
                                          dag=dag)

#-----------function to generate to tasks ---------------------------------------------------------
def gen_glue_jobrun_task(app,subjectarea,exec_parameter,task_name): #change-4
    return PythonOperator(task_id= task_name,
                               python_callable=glue_jobrun_operator.run_glue_job,
                               provide_context=True,
                               op_kwargs={'app': app,'subjectarea': subjectarea,'exec_param':  exec_parameter},  #change-5
                               dag=dag)

#-----------initilizing tasks------------------------------------------------------------------------------------------- #change-6 for adding app param in each task
CICDTEST_sftp_to_s3=gen_glue_jobrun_task(app,subjectarea,'sftp_to_s3','CICDTEST_sftp_to_s3')
CICDTEST_gzip_conversion=gen_glue_jobrun_task(app,subjectarea,'gzip_conversion','CICDTEST_gzip_conversion')
CICDTEST_files_upload=gen_glue_jobrun_task(app,subjectarea,'gzip_to_int','CICDTEST_files_upload')
CICDTEST_file_pre_Check=gen_glue_jobrun_task(app,subjectarea,'file_pre_check','CICDTEST_file_pre_Check')
CICDTEST_stg_int_location_load = gen_glue_jobrun_task(app,subjectarea, 'DML/STG_INT_CICDTEST_LOCATION_dml.sql','CICDTEST_stg_int_location_load')
CICDTEST_stg_int_pos_load = gen_glue_jobrun_task(app,subjectarea, 'DML/STG_INT_CICDTEST_POS_dml.sql','CICDTEST_stg_int_pos_load')
CICDTEST_stg_location_load = gen_glue_jobrun_task(app,subjectarea, 'DML/STG_CICDTEST_LOCATION_dml.sql', 'CICDTEST_stg_location_load')
CICDTEST_location_load = gen_glue_jobrun_task(app,subjectarea, 'DML/LOCATION_dml.sql', 'CICDTEST_location_load')
CICDTEST_stg_product_master_load = gen_glue_jobrun_task(app,subjectarea, 'DML/STG_CICDTEST_RETAILER_PRODUCT_MASTER_dml.sql', 'CICDTEST_stg_product_master_load')
CICDTEST_product_master_load = gen_glue_jobrun_task(app,subjectarea, 'DML/RETAILER_PRODUCT_MASTER_dml.sql','CICDTEST_product_master_load')
CICDTEST_stg_weekly_pos_load = gen_glue_jobrun_task(app,subjectarea, 'DML/STG_CICDTEST_RETAILER_WEEKLY_POS_dml.sql', 'CICDTEST_stg_weekly_pos_load')
CICDTEST_pos_aggrigation_load = gen_glue_jobrun_task(app,subjectarea, 'DML/RETAILER_POS_AGGREGATION_dml.sql', 'CICDTEST_pos_aggrigation_load')
CICDTEST_load_type_tracker_reset = gen_glue_jobrun_task(app,subjectarea, 'DML/LOAD_TYPE_TRACKER_RESET_dml.sql', 'CICDTEST_load_type_tracker_reset')
CICDTEST_archive = gen_glue_jobrun_task(app,subjectarea, 'int_to_arc', 'CICDTEST_archive')
CICDTEST_int_purge = gen_glue_jobrun_task(app,subjectarea, 'BUCKETPURGE_INT', 'CICDTEST_int_purge')
CICDTEST_glue_purge = gen_glue_jobrun_task(app,subjectarea, 'BUCKETPURGE_GLUE', 'CICDTEST_glue_purge')
CICDTEST_sftp_purge = gen_glue_jobrun_task(app,subjectarea, 'sftp_purge', 'CICDTEST_sftp_purge')

#--------- Defining Dependencies-------------
generate_parent_batch_id >> CICDTEST_sftp_to_s3
CICDTEST_sftp_to_s3 >> CICDTEST_gzip_conversion
CICDTEST_gzip_conversion >> CICDTEST_files_upload
CICDTEST_files_upload >> CICDTEST_file_pre_Check
CICDTEST_file_pre_Check >> CICDTEST_stg_int_location_load
CICDTEST_file_pre_Check >> CICDTEST_stg_int_pos_load
CICDTEST_stg_int_location_load >> CICDTEST_stg_location_load
CICDTEST_stg_location_load >> CICDTEST_location_load
CICDTEST_stg_int_pos_load >> CICDTEST_stg_product_master_load
CICDTEST_stg_product_master_load >> CICDTEST_product_master_load
CICDTEST_product_master_load >> CICDTEST_stg_weekly_pos_load
CICDTEST_location_load >> CICDTEST_stg_weekly_pos_load
CICDTEST_stg_weekly_pos_load >> CICDTEST_pos_aggrigation_load
CICDTEST_product_master_load >> CICDTEST_load_type_tracker_reset
CICDTEST_pos_aggrigation_load>> CICDTEST_load_type_tracker_reset
CICDTEST_load_type_tracker_reset >> CICDTEST_archive
CICDTEST_archive >> CICDTEST_int_purge
CICDTEST_int_purge >> CICDTEST_glue_purge
CICDTEST_glue_purge >> CICDTEST_sftp_purge
