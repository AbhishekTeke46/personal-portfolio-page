/****
  DML to create STG_INT_EXTRACT_TRUS_UPC 

  Sources: 
  Target: 
  Logic: 
  Table Type: 
  Parameters:  
  
  Modification Log:
  ---------------------------------------------------------------------------------------------------
  Date                      Author                  Description
  ---------------------------------------------------------------------------------------------------
  12/02/2021               V.Nagadeekshitha         Created DML
  12/13/2021               V.Nagadeekshitha         Added parameters for file name
  09/15/2023			   Abhishek Teke   			'Toys R Us' Outbound Job failed due to file size issue.  (CHG00167679)
  11/17/2023               Subhasmita Sahu          Architecture Database Change from 'CP_DW_DB' TO 'EDLW_INT_DB' AND 'EDLW_DB_DW'
  ----------------------------------------------------------------------------------------------------
  ----------------------------------------------------------------------------------------------------
  Jira Ticket Number:CPA2-796
 ***/
 
TRUNCATE TABLE  {bronze_db}.{landing_schema}.STG_INT_EXTRACT_TRUS_UPC;
 
 INSERT INTO {bronze_db}.{landing_schema}.STG_INT_EXTRACT_TRUS_UPC 
(GTIN,
ITEM_DESCRIPTION,
CONTRACT_LOB,
LICENSED_PROPERTY,
LICENSEE
)
(
select 
  case 
    when length(trim(slfc.GTIN)) < 13 then lpad(trim(slfc.GTIN), 13,'0') 
    when length(trim(slfc.GTIN)) = 13 then trim(slfc.GTIN)
    when length(trim(slfc.GTIN)) > 13 and length(trim(slfc.GTIN)) = 14 and substr(trim(slfc.GTIN), 1,1) = '0' then substr(trim(slfc.GTIN), 2)
    when length(trim(slfc.GTIN)) > 13 and length(trim(slfc.GTIN)) = 14 and substr(trim(slfc.GTIN), 1,1) <> '0' then trim(slfc.GTIN)
    else lpad(trim(slfc.GTIN), 13,'0')
  end as GTIN
  , max(InitCap(upper(trim(slfc.ITEM_DESCRPTION)))) Item_Description
  , max(trim(slfc.LOB)) Contract_LOB
  , max(InitCap(upper(trim(slfc.CP_LICENSED_PROPERTY)))) Licensed_Property
  , max(trim(slfc.LICENSEE)) Licensee
from  {silver_db}.{main_schema}.SLFC_SUBMISSION slfc
where GTIN is not null
group by 1
order by 1);

--copy to stage int folder

copy into @{db}.{landing_schema}.STAGE_S3_TRUS/out/TRUCAN_ItemMaster.txt
from
(
SELECT * FROM {bronze_db}.{landing_schema}.STG_INT_EXTRACT_TRUS_UPC
)
HEADER = TRUE
SINGLE = TRUE
OVERWRITE = TRUE
max_file_size =4900000000;