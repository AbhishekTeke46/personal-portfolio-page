/*Select 'Mentioned Job_ID(s) are missing in the latest Submission_Detail which were present in the previous Submission_Detail data feed' AS Message, 'Warning ' Error_Type, Count(*) as Number_of_Records, 'Please check the JOB_ID(s) which are missing in the latest Submission_Detail Starlabs Data File' Probable_Action_Needed from 
(
select JOB_ID from EDLW_DW_DB.CP_MAIN_SCHEMA.SLABS_SUBMISSION_DETAILS 
minus
select JOB_ID from EDLW_DW_DB.CP_STAGING_SCHEMA.STG_SLB_SUBMISSION_DETAILS
) SUBS having count(*)>0
UNION */
Select ERROR_MESSAGE AS Message, Error_Type, Count(*) as Number_of_Records, 'Please correct the PRODUCT_DETAIL_LMSI_ID entries in Starlabs Submission_Detail' Probable_Action_Needed from EDLW_DW_DB.CP_STAGING_SCHEMA.STG_SLB_SUBMISSION_DETAILS Where error_message like '%%PRODUCT_DETAIL_LMSI_ID received in SUBMISSION_DETAILS is not present in LMSI_PRODUCT Table%%'
Group By 1,2
UNION
Select ERROR_MESSAGE AS Message, Error_Type, Count(*) as Number_of_Records, 'Please correct the PROPERTY_LMSI_ID entries in Starlabs Submission_Detail' Probable_Action_Needed  from EDLW_DW_DB.CP_STAGING_SCHEMA.STG_SLB_SUBMISSION_DETAILS where error_message like '%%PROPERTY_LMSI_ID received in SUBMISSION_DETAILS is not present in LMSI_PROPERTY Table%%'
Group By 1,2
UNION
Select ERROR_MESSAGE AS Message, Error_Type, Count(*) as Number_of_Records, 'Please correct the Contract_Number entries in Starlabs Submission_Detail' Probable_Action_Needed  from EDLW_DW_DB.CP_STAGING_SCHEMA.STG_SLB_SUBMISSION_DETAILS where error_message like '%%Contract_Number received in SUBMISSION_DETAILS is not present in LMSI_CONTRACT Table%%'
Group By 1,2
UNION
Select ERROR_MESSAGE AS Message, Error_Type, Count(*) as Number_of_Records, 'Please check on the Duplicate JOB_ID entries in Starlabs Submission_Detail' Probable_Action_Needed  from EDLW_DW_DB.CP_STAGING_SCHEMA.STG_SLB_SUBMISSION_DETAILS where error_message like '%%Duplicates records exists for same JOB_ID, which is a Primary Key%%'
Group By 1,2
UNION
Select ERROR_MESSAGE AS Message, Error_Type, Count(*) as Number_of_Records, 'Please correct the records which are having JOB_ID as NULL values in Starlabs Submission_Detail' Probable_Action_Needed  from EDLW_DW_DB.CP_STAGING_SCHEMA.STG_SLB_SUBMISSION_DETAILS where error_message like '%%JOB_ID which is a Primary Key is having NULL values%%'
Group By 1,2
UNION
Select ERROR_MESSAGE AS Message, Error_Type, Count(*) as Number_of_Records, 'Please correct the PRODUCT_DETAIL_LMSI_ID entries which is coming as a comma seperated value in Starlabs Submission_Detail' Probable_Action_Needed  from EDLW_DW_DB.CP_STAGING_SCHEMA.STG_SLB_SUBMISSION_DETAILS where error_message like '%%PRODUCT_DETAIL_LMSi_ID is a comma separated value%%'
Group By 1,2
UNION
Select ERROR_MESSAGE AS Message, Error_Type, Count(*) as Number_of_Records, 'Please correct the PROPERTY_LMSi_ID entries which is coming as a comma seperated value in Starlabs Submission_Detail' Probable_Action_Needed  from EDLW_DW_DB.CP_STAGING_SCHEMA.STG_SLB_SUBMISSION_DETAILS where error_message like '%%PROPERTY_LMSi_ID is a comma separated value%%'
Group By 1,2
UNION
Select 'Mentioned Job_ID(s) which came as part of latest Submission_Report data file are missing in the Submission_Detail Starlabs Feed' AS Message, 'Warning ' Error_Type, Count(*) as Number_of_Records, 'Please provide the JOB_ID(s) which are missing in the Submission_Detail and present in Submission_Report data file' Probable_Action_Needed from 
(
select SUBMISSIONJOBID from EDLW_DW_DB.CP_STAGING_SCHEMA.STG_SLB_SUBMISSION_REPORT Where ERROR_FLG='N'
minus
Select JOB_ID from EDLW_DW_DB.CP_MAIN_SCHEMA.SLABS_SUBMISSION_DETAILS
) SUBQ having count(*)>0
UNION
Select ERROR_MESSAGE AS Message, Error_Type, Count(*) as Number_of_Records, 'Please correct the records which are having Invalid Date Attributes in Starlabs Submission_Detail' Probable_Action_Needed  from EDLW_DW_DB.CP_STAGING_SCHEMA.STG_SLB_SUBMISSION_DETAILS where error_message like '%%Invalid date format%%'
Group By 1,2

;