import boto3
from botocore.exceptions import ClientError
import json
import inspect
import os

def get_secret_pass(secret_name):
    region_name = "us-west-2"
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name, aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'), aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'))
    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        secret = get_secret_value_response['SecretString']
        #print("secret\n", secret)
        resp_dict = json.loads(secret)
        #print("resp_dict\n", resp_dict)
        SNOW_PASS = resp_dict[secret_name]
        print('Secret Retrived Sucessfully')
        return SNOW_PASS

    except ClientError as e:
        print(str(e))
