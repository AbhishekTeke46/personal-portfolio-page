import sys
import os
from os import path
import boto3
import json
import urllib
import subprocess
import time
import ast
from datetime import datetime
from dateutil.relativedelta import relativedelta
import dateutil
import secret_manager
from Activity_logger import logger
from snowflake_logger import lambda_invoke

def checksum_gen(repo_path, item, dict_item_checksum):
    ''' 
    Generate the dictionary with file_name: hash_value created for content of file
    
    Inputs: 
    1. repo_path: tmp path of repository 
    2. item: file name
    3. dict_item_checksum: dictiionary name in which we are storing key:value pairs of file_name: hash_value
    
    Processing:
    1. read file present at repo path
    2. generate hash value form content of file
    3. storing it into dict_item_checksum dictionary.
    
    Output: 
    On Sucess:
    1. dict_item_checksum
    On Failure: 
    1. Error Message
    '''
    with open('%s%s' % (repo_path,item),'r') as file_copy:
        item_content = file_copy.read()
    checksum = hash(item_content)
    dict_item_checksum.update({item:checksum})
    return dict_item_checksum
            
def comparison_list_gen(push_url,deploy_target_branch,source_checksum_dict,target_checksum_dict,tracker_higher_env_item_list,git_rpm_install_tmp_dir,comparison_list,Deployed_items,git_checksum_repo_clone_target_dir):

    ''' 
    Compare the hash value generated for each file from git repo present in temp location before git deployment 
    and hash value generated for the same file from cloned git repo after git deployement and return Deployed_items and comparison_list.
    where comparison_list is list of files whose hash values are not mathching and Deployed_items are those files whose hash values mathces
    
    Inputs:
    1. push_url: Git url for cloaning the branch
    2. deploy_target_branch: target barnch name which will be used for checksum comparison
    3. source_checksum_dict: Dictionary to store file_name:hash_value from target branch before deployement
    4. target_checksum_dict: Dictionary to store file_name:hash_value from target branch after deployement
    5. tracker_higher_env_item_list: list of items which needs to be deployed into target branch(Next Higer Branch)
    6. git_rpm_install_tmp_dir: temp directory path where git package installed
    7. comparison_list: list of items which are failed to deploy into target branch
    8. Deployed_items: list of sucessfully deployed items
    9. git_checksum_repo_clone_target_dir: directory name in which we need to clone the target directory after deployment.
    
    Processing:
    1. Creating path where we need to clone target branch after deployment.
    2. Cloaning the target branch after deployement
    3. Creating target_checksum_dict
    4. Crating Deployed_items, comparison_list
    
    Output:     
    On Sucess:
    1. Deployed_items 
    2. comparison_list
    On Failure: 
    1. Error Message
    '''
    
    target_checksum_repo_path = '%s/%s/' % (git_rpm_install_tmp_dir,git_checksum_repo_clone_target_dir)
    
    
    target_checksum_repo_clone_command = ['git', 'clone', '--branch', deploy_target_branch, push_url, git_checksum_repo_clone_target_dir]
    print("target_checksum_repo_clone_command: ", target_checksum_repo_clone_command)
    
    os.chdir(git_rpm_install_tmp_dir)
    
    print(subprocess.check_output(target_checksum_repo_clone_command, cwd = git_rpm_install_tmp_dir, stderr=subprocess.STDOUT, shell=False))

    
    #os.chdir(git_rpm_install_tmp_dir)
    #print(os.getcwd())
    #print('Current Dir:', os.system('pwd'))
    #print(os.system('ls %s' %git_rpm_install_tmp_dir))
    #print(os.system('ls'))
    #print(os.system('git clone --branch %s %s %s' %(deploy_target_branch,push_url, git_checksum_repo_clone_target_dir)))
    
    
    print(os.system('ls %s' %target_checksum_repo_path))

    #Generating Dictionary of file_name:hash_value from target branch
    for files in tracker_higher_env_item_list:
        files = files.split(',')[0]
        target_checksum_dict = checksum_gen(target_checksum_repo_path, files, target_checksum_dict)
        #Comparing hash value of each file from source branch with respective hash value of target branch
        if source_checksum_dict[files] == target_checksum_dict[files]:
            Deployed_items= Deployed_items + '\n' + files
        else:
            comparison_list.append(files)  

    print(source_checksum_dict)
    print('---------------------------------------------------------')
    print(target_checksum_dict)    
    
    return Deployed_items, comparison_list
    

def parameter_transform(full_file_path,**trans_mapping_dict):
    '''
    Updating the content of the file by replacing keys from trans_mapping_dict with values.
    
    Input:
    1. full_file_path: Path of file in tmp location
    2. trans_mapping_dict: dicationary of key:value pairs in which key is content which needs to be modified and value is to which value content needs to be modified.
    
    Processing:
    1. reading file 
    2. seperaing each line 
    3. replacing key with value form trans_mapping_dict dictionary
    4. Storing the transformed file content into new_file_content variable
    5. Update the file with new_file_content
    
    Output:
    On Sucess:
    1. Deployed_items 
    2. comparison_list
    On Failure: 
    1. Error Message
    '''
    for key, value in trans_mapping_dict.items():
        reading_file = open(full_file_path, "r")
        new_file_content = ""
        for line in reading_file:
            stripped_line = line.rstrip()
            new_line = stripped_line.replace(key, value)
            new_file_content += new_line +"\n"
        reading_file.close()
    
        writing_file = open(full_file_path, "w")
        writing_file.write(new_file_content)
        writing_file.close()

def lambda_handler(event):
    print(event)
    #DEFINING THE VARIABLES
    lambda_function_name = 'GIT_ENV_TRANSFORMATION_BRANCH_DEPLOY_CONTAINER'
    #Assigning Parameters passed from Git Workflow
    source_clone_branch_name = event['source_branch']
    deploy_target_branch = event['deploy_target_branch']
    cp_tracker_name = event['tracker_name']
    workflow = event['workflow_name']
    
    parameters = '''{"source_branch":"%s",
    "deploy_target_branch":"%s",
    "tracker_name":"%s",
    "workflow_name":"%s"}''' % (source_clone_branch_name,deploy_target_branch,cp_tracker_name,workflow)
    print('Parameters: \n', parameters)
    
    #Generationg Batch ID
    IST = dateutil.tz.gettz('Asia/Kolkata')
    current_time = datetime.now(tz=IST).strftime("%H:%M:%S:%f")
    current_date = datetime.now(tz=IST).strftime("%Y%m%d")
    BATCH_ID = abs(hash(current_date+current_time))
    print(BATCH_ID)
    
    if source_clone_branch_name == 'DEV_QA_Intrim_Approval' and deploy_target_branch == 'QA':
        ini_parameters_dict = {'wb_consumer_products_dev' : 'wb_consumer_products_qa', 'cp_etl_dev_snow_pass' : 'cp_etl_qa_snow_pass',
        'cp-sf-int-dev' : 'cp-sf-int-qa', 'cp-sf-int-qa-archive': 'cp-sf-int-qa-archive', 'cp-glue-dev':'cp-glue-qa',
        'cp-wbdi-npd-qa':'cp-wbdi-npd-qa', 'wbcp-stage-retail-analytics-pos-data':'wbcp-stage-retail-analytics-pos-data',
        'cp-wbdi-lmsi-qa' : 'cp-wbdi-lmsi-qa', 'cp-gps-apicall-dev' : 'cp-gps-apicall-qa', 'cp-gps-s3purge-dev' : 'cp-gps-s3purge-qa',
        'cp-gps-s3transfer-dev' : 'cp-gps-s3transfer-qa', 'cp-gps-gzip-dev' : 'cp-gps-gzip-qa', 'cp-gps-xlstotxt-dev' : 'cp-gps-xlstotxt-qa',
        'cp-gps-sftp-dev' : 'cp-gps-sftp-qa', 'cp-gps-AthenaS3-dev' : 'cp-gps-AthenaS3-qa', 'cp-gps-file-pre-check-dev' : 'cp-gps-file-pre-check-qa',
        'CP_DEVELOPER_RL' : 'CP_ETL_RL', 'CP_SMALL_WH' : 'CP_ETL_WH', 'cpextract_dev' : 'cpextract_qa', 'cp-wbdi-salesforce-qa':'cp-wbdi-salesforce-qa',
        'cp-cicd-audit-qa':'cp-cicd-audit-qa','cp-gps-s3-to-sftp-transfer-dev':'cp-gps-s3-to-sftp-transfer-qa','starlabs_role_arn':'starlabs_role_arn',
        'cp-wbdi-npd-published-qa' : 'cp-wbdi-npd-published-qa','cp-gcp-snow-commerce-dev':'cp-gcp-snow-commerce-qa',
        'cp-gps-pdf-conversion-dev':'cp-gps-pdf-conversion-qa','cp-wbdi-datashare-qa':'cp-wbdi-datashare-qa','cp-wbdi-seeker-qa':'cp-wbdi-seeker-qa','cp-wbdi-brcd-lkp-qa':'cp-wbdi-brcd-lkp-qa'
        ,'cp-wbdi-datashare-outbound-qa':'cp-wbdi-datashare-outbound-qa','edlw-gps-apicall-dev':'edlw-gps-apicall-qa','edlw-gps-s3purge-dev':'edlw-gps-s3purge-qa'
        ,'edlw-gps-s3transfer-dev':'edlw-gps-s3transfer-qa','edlw-gps-gzip-dev':'edlw-gps-gzip-qa','edlw-gps-xlstotxt-dev':'edlw-gps-xlstotxt-qa'
        ,'edlw-gps-sftp-dev':'edlw-gps-sftp-qa','edlw-gps-AthenaS3-dev':'edlw-gps-AthenaS3-qa','edlw-gps-file-pre-check-dev':'edlw-gps-file-pre-check-qa'
        ,'edlw-gcp-snow-commerce-dev':'edlw-gcp-snow-commerce-qa','edlw-gps-pdf-conversion-dev':'edlw-gps-pdf-conversion-qa','edlw-gps-emailtos3-dev':'edlw-gps-emailtos3-qa'
        ,'cp-wbdi-stratum-qa':'cp-wbdi-stratum-qa'}
        airflow_parameters_dict = {'cp_snowflake_dev' : 'cp_snowflake_qa', 'cp-gps-jobrun-dev' : 'cp-gps-jobrun-qa','cp-sf-int-dev' : 'cp-sf-int-qa',
        'cp_retail_link_download':'cp_retail_link_download_qa', 'CP_TABLEAU_DAG_DEV': 'CP_TABLEAU_DAG_QA',
        'CP_TABLEAU_FACT_DAG_DEV': 'CP_TABLEAU_FACT_DAG_QA','CP_TABLEAU_FACT_FILTERED_DAG_DEV': 'CP_TABLEAU_FACT_FILTERED_DAG_QA',
        'CP_CPIM_FT_DAG_DEV':'CP_CPIM_FT_DAG_QA', 'CP_GENERIC_DATA_AUDIT_DAG_DEV':'CP_GENERIC_DATA_AUDIT_DAG_QA',
        ''''email': ['wbcpanalyticsetlteam.in@capgemini.com']''': ''''email': ['CPAnalyticsETLTeam@warnerbros.com']''','cp_etl_dev_snow_pass':'cp_etl_qa_snow_pass'
        ,'CP_RECON_AUDIT_DAG_DEV':'CP_RECON_AUDIT_DAG_QA','CP_RCHL_DAG_DEV':'CP_RCHL_DAG_QA','CP_BRC_LKP_POST_BND_MFG_API_DAG_DEV':'CP_BRC_LKP_POST_BND_MFG_API_DAG_QA'
        ,'CP_BRC_LKP_POST_BRAND_API_DAG_DEV':'CP_BRC_LKP_POST_BRAND_API_DAG_QA','CP_BRC_LKP_POST_UPC_API_DAG_DEV':'CP_BRC_LKP_POST_UPC_API_DAG_QA','CP_BRC_LKP_WEEKLY_UPC_API_DAG_DEV':'CP_BRC_LKP_WEEKLY_UPC_API_DAG_QA'
        ,'CP_BRC_LKP_BND_MFG_API_DAG_DEV':'CP_BRC_LKP_BND_MFG_API_DAG_QA','CP_BRC_LKP_BRAND_API_DAG_DEV':'CP_BRC_LKP_BRAND_API_DAG_QA'
        ,'CP_BRC_LKP_PRE_API_DAG_DEV':'CP_BRC_LKP_PRE_API_DAG_QA','CP_BRC_LKP_UPC_API_DAG_DEV':'CP_BRC_LKP_UPC_API_DAG_QA','CP_BRC_LKP_SEARCH_API_DAG_DEV':'CP_BRC_LKP_SEARCH_API_DAG_QA','CP_BRC_LKP_POST_SEARCH_API_DAG_DEV':'CP_BRC_LKP_POST_SEARCH_API_DAG_QA'
        ,'CP_GPM_WB_CP_IND_PUBLISHING_DAG_DEV':'CP_GPM_WB_CP_IND_PUBLISHING_DAG_QA','CP_WMTU_RETAILER_CATEGORY_LOB_DAG_DEV':'CP_WMTU_RETAILER_CATEGORY_LOB_DAG_QA'
        ,'CP_CONSUMER_PRODUCT_IMAGES_DAG_DEV':'CP_CONSUMER_PRODUCT_IMAGES_DAG_QA','CP_CONSUMER_PRODUCT_MASTER_DAG_DEV':'CP_CONSUMER_PRODUCT_MASTER_DAG_QA','CP_CONSUMER_PRODUCT_RETAILER_DAG_DEV':'CP_CONSUMER_PRODUCT_RETAILER_DAG_QA'
        ,'CP_NNCA_DAG_DEV':'CP_NNCA_DAG_QA','CP_AMZ_MONTHLY_DATA_REPORT_DAG_DEV':'CP_AMZ_MONTHLY_DATA_REPORT_DAG_QA',"ENV='DEV'":"ENV='QA'","ENV= 'DEV'":"ENV='QA'","ENV = 'DEV'":"ENV='QA'"
        ,'CP_GS1_BRAND_API_DAG_DEV': 'CP_GS1_BRAND_API_DAG_QA','CP_GS1_COMPANY_NAME_API_DAG_DEV':'CP_GS1_COMPANY_NAME_API_DAG_QA','CP_GS1_GTIN_API_DAG_DEV':'CP_GS1_GTIN_API_DAG_QA'
        ,'CP_GS1_KEYWORD_API_DAG_DEV':'CP_GS1_KEYWORD_API_DAG_QA','CP_GS1_POST_BRAND_API_DAG_DEV':'CP_GS1_POST_BRAND_API_DAG_QA','CP_GS1_POST_COMPANY_NAME_API_DAG_DEV':'CP_GS1_POST_COMPANY_NAME_API_DAG_QA'
        ,'CP_GS1_POST_GTIN_API_DAG_DEV':'CP_GS1_POST_GTIN_API_DAG_QA','CP_GS1_POST_KEYWORD_API_DAG_DEV':'CP_GS1_POST_KEYWORD_API_DAG_QA','cp_dbdetails_dev':'cp_dbdetails_qa'
        ,'CP_SLFC_FT_DAG_DEV':'CP_SLFC_FT_DAG_QA','CP_GS1_COMPANY_API_LICENSES_SEARCH_DAG_DEV':'CP_GS1_COMPANY_API_LICENSES_SEARCH_DAG_QA'}
        
        airflow_file_suffix_transform_dict = {'_Dev':'_Qa'}
        gluejob_file_suffix_transform_dict = {'-Dev':'-Qa'}
        git_env_matching_expression = 'dev-qa'
        #remote_server_name = 'origin'
        
    if source_clone_branch_name == 'QA_PROD_Intrim_Approval' and deploy_target_branch == 'PROD':
        ini_parameters_dict = {'wb_consumer_products_qa' : 'wb_consumer_products_prod', 'cp_etl_qa_snow_pass' : 'cp_etl_prod_snow_pass',
        'cp-sf-int-qa' : 'cp-sf-int-prod', 'cp-sf-int-qa-archive': 'cp-sf-int-prod-archive', 'cp-glue-qa':'cp-glue-prod',
        'cp-wbdi-npd-qa':'cp-wbdi-npd', 'wbcp-stage-retail-analytics-pos-data':'wbcp-prod-retail-analytics-pos-data',
        'cp-wbdi-lmsi-qa' : 'cp-wbdi-lmsi-prod', 'cp-gps-apicall-qa' : 'cp-gps-apicall', 'cp-gps-s3purge-qa' : 'cp-gps-s3purge',
        'cp-gps-s3transfer-qa' : 'cp-gps-s3transfer', 'cp-gps-gzip-qa' : 'cp-gps-gzip', 'cp-gps-xlstotxt-qa' : 'cp-gps-xlstotxt',
        'cp-gps-sftp-qa' : 'cp-gps-sftp', 'cp-gps-AthenaS3-qa' : 'cp-gps-AthenaS3', 'cp-gps-file-pre-check-qa' : 'cp-gps-file-pre-check',
        'CP_ETL_RL' : 'CP_ETL_RL', 'CP_ETL_WH' : 'CP_ETL_WH', 'cpextract_qa' : 'cpextract_prod', 'cp-wbdi-salesforce-qa':'cp-wbdi-salesforce',
        'cp-cicd-audit-qa':'cp-cicd-audit-prod','cp-gps-s3-to-sftp-transfer-qa':'cp-gps-s3-to-sftp-transfer','starlabs_role_arn':'cp_starlabs_role_arn',
        'cp-wbdi-npd-published-qa' : 'cp-wbdi-npd-published','cp-gcp-snow-commerce-qa':'cp-gcp-snow-commerce',
        'cp-gps-pdf-conversion-qa':'cp-gps-pdf-conversion','cp-wbdi-datashare-qa':'cp-wbdi-datashare','cp-wbdi-seeker-qa':'cp-wbdi-seeker','cp-wbdi-brcd-lkp-qa':'cp-wbdi-brcd-lkp'
        ,'cp-wbdi-datashare-outbound-qa':'cp-wbdi-datashare-outbound','cp-wbdi-party-city-qa':'cp-wbdi-party-city-prod','edlw-gps-apicall-qa':'edlw-gps-apicall'
        ,'edlw-gps-s3purge-qa':'edlw-gps-s3purge','edlw-gps-s3transfer-qa':'edlw-gps-s3transfer','edlw-gps-gzip-qa':'edlw-gps-gzip','edlw-gps-xlstotxt-qa':'edlw-gps-xlstotxt'
        ,'edlw-gps-sftp-qa':'edlw-gps-sftp','edlw-gps-AthenaS3-qa':'edlw-gps-AthenaS3','edlw-gps-file-pre-check-qa':'edlw-gps-file-pre-check'
        ,'edlw-gcp-snow-commerce-qa':'edlw-gcp-snow-commerce','edlw-gps-pdf-conversion-qa':'edlw-gps-pdf-conversion','edlw-gps-emailtos3-qa':'edlw-gps-emailtos3'
        ,'cp-wbdi-stratum-qa':'cp-wbdi-stratum'}
        airflow_parameters_dict = {'cp_snowflake_qa' : 'cp_snowflake_prod', 'cp-gps-jobrun-qa' : 'cp-gps-jobrun','cp-sf-int-qa' : 'cp-sf-int-prod',
        'cp_retail_link_download_qa':'cp_retail_link_download', 'CP_TABLEAU_DAG_QA': 'CP_TABLEAU_DAG',
        'CP_TABLEAU_FACT_DAG_QA': 'CP_TABLEAU_FACT_DAG', 'CP_TABLEAU_FACT_FILTERED_DAG_QA': 'CP_TABLEAU_FACT_FILTERED_DAG',
        'CP_CPIM_FT_DAG_QA':'CP_CPIM_FT_DAG', 'CP_GENERIC_DATA_AUDIT_DAG_QA':'CP_GENERIC_DATA_AUDIT_DAG',
        ''''email': ['CPAnalyticsETLTeam@warnerbros.com']''': ''''email': ['CPAnalyticsETLTeam@warnerbros.com']''','cp_etl_qa_snow_pass':'cp_etl_prod_snow_pass'
        ,'CP_RECON_AUDIT_DAG_QA':'CP_RECON_AUDIT_DAG','CP_RCHL_DAG_QA':'CP_RCH_DAG','CP_BRC_LKP_POST_BND_MFG_API_DAG_QA':'CP_BRC_LKP_POST_BND_MFG_API_DAG'
        ,'CP_BRC_LKP_POST_BRAND_API_DAG_QA':'CP_BRC_LKP_POST_BRAND_API_DAG','CP_BRC_LKP_POST_UPC_API_DAG_QA':'CP_BRC_LKP_POST_UPC_API_DAG','CP_BRC_LKP_WEEKLY_UPC_API_DAG_QA':'CP_BRC_LKP_WEEKLY_UPC_API_DAG'
        ,'CP_BRC_LKP_BND_MFG_API_DAG_QA':'CP_BRC_LKP_BND_MFG_API_DAG','CP_BRC_LKP_BRAND_API_DAG_QA':'CP_BRC_LKP_BRAND_API_DAG','CP_BRC_LKP_SEARCH_API_DAG_QA':'CP_BRC_LKP_SEARCH_API_DAG','CP_BRC_LKP_POST_SEARCH_API_DAG_QA':'CP_BRC_LKP_POST_SEARCH_API_DAG'
        ,'CP_GPM_WB_CP_IND_PUBLISHING_DAG_QA':'CP_GPM_WB_CP_IND_PUBLISHING_DAG','CP_WMTU_RETAILER_CATEGORY_LOB_DAG_QA':'CP_WMTU_RETAILER_CATEGORY_LOB_DAG','CP_CONSUMER_PRODUCT_IMAGES_DAG_QA':'CP_CONSUMER_PRODUCT_IMAGES_DAG'
        ,'CP_CONSUMER_PRODUCT_MASTER_DAG_QA':'CP_CONSUMER_PRODUCT_MASTER_DAG','CP_CONSUMER_PRODUCT_RETAILER_DAG_QA':'CP_CONSUMER_PRODUCT_RETAILER_DAG','CP_NNCA_DAG_QA':'CP_NNCA_DAG','CP_AMZ_MONTHLY_DATA_REPORT_DAG_QA':'CP_AMZ_MONTHLY_DATA_REPORT_DAG'
        ,"ENV='QA'":"ENV='PROD'",'CP_GS1_BRAND_API_DAG_QA':'CP_GS1_BRAND_API_DAG','CP_GS1_COMPANY_NAME_API_DAG_QA':'CP_GS1_COMPANY_NAME_API_DAG','CP_GS1_GTIN_API_DAG_QA':'CP_GS1_GTIN_API_DAG','CP_GS1_KEYWORD_API_DAG_QA':'CP_GS1_KEYWORD_API_DAG'
        ,'CP_GS1_POST_BRAND_API_DAG_QA':'CP_GS1_POST_BRAND_API_DAG','CP_GS1_POST_COMPANY_NAME_API_DAG_QA':'CP_GS1_POST_COMPANY_NAME_API_DAG'
        ,'CP_GS1_POST_GTIN_API_DAG_QA':'CP_GS1_POST_GTIN_API_DAG','CP_GS1_POST_KEYWORD_API_DAG_QA':'CP_GS1_POST_KEYWORD_API_DAG','cp_dbdetails_qa':'cp_dbdetails_prod'
        ,'CP_SLFC_FT_DAG_QA':'CP_SLFC_FT_DAG','CP_GS1_COMPANY_API_LICENSES_SEARCH_DAG_QA':'CP_GS1_COMPANY_API_LICENSES_SEARCH_DAG'}
        
        airflow_file_suffix_transform_dict = {'_Qa':''}
        gluejob_file_suffix_transform_dict = {'-Qa':''}
        git_env_matching_expression = 'dev-qa-prod'
        remote_server_name = 'origin'
        
    tracker_upload_action = 'upload'
    tracker_delete_action = 'delete'
    tracker_env_action_list = [tracker_upload_action,tracker_delete_action]
    
    git_url = os.getenv('git_url')
    git_user_name = os.getenv('git_user_name')
    git_brach_access_token = git_user_name + ':' + secret_manager.get_secret_pass(os.getenv('github_token'))
    url = git_url.split('//')
    push_url = 'https://'+ git_brach_access_token + '@' + url[-1]
    
    #git_repo_clone_command_source_branch = 'clone --branch ' + source_clone_branch_name + ' --single-branch'
    #git_repo_clone_command_target_branch = 'clone --branch ' + deploy_target_branch + ' --single-branch'
    
    s3 = boto3.client('s3',aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
                      aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'))

    git_repo_clone_source_dir = 'intrim_branch_clone'
    git_repo_clone_target_dir = 'destination_branch_clone'
    
    git_rpm_install_tmp_dir = '/tmp/GIT_CLONES'
    
    print(os.system("rm -rf %s" %git_rpm_install_tmp_dir))
    print(os.system("mkdir %s" %git_rpm_install_tmp_dir))

    source_repo_path = '%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_source_dir)
    target_repo_path = '%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)
    
    transformation_item_list = [] #list of all the items to be deployed in the higher GIT Branch
    glue_transformation_item_list = [] #list of all the Glue items to be transformed & deployed in the next higher branch
    airflow_transformation_item_list = [] #list of all the Airflow items to be transformed & deployed in the next higher branch
    notification_transformation_item_list = [] #list of all the Notification items to be transformed & deployed in the next higher branch
    unique_folder_structure_list = [] #list of all the Distinct Folder structures to be created in the target repo clone directory
    new_tracker_files_list = [] #List of all tracker files with modified Airflow file names
    tracker_wrong_env_items_list = [] #list of all items with wrong env in tracker
    tracker_wrong_action_items_list = [] #list of all items with wrong action in tracker
    #git_expected_file_list = []
    comparison_list = []
    
    tracker_contents = ''
    names_of_successfull_deployed_object = ''
    tracker_wrong_env_items_list_text = ''
    tracker_wrong_action_items_list_text = ''
    env_specific_files_text = ''
    reconciliation_objects_text = ''
    log_details_list = []

    # Download, verify and unpack the Git RPM package
    LOG_TYPE = 'SUCCESS'
    
    try:
        EXEC_START_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")

    
        #CLONE THE REMOTE GIT REPOSITORY FROM SOURCE BRANCH
        TASK = 'CLONE SOURCE BRANCH-- ' + source_clone_branch_name
        
        source_branch_clone_command = ['git', 'clone', '--branch', source_clone_branch_name, push_url, git_repo_clone_source_dir]
        #print("source_branch_clone_command: ", source_branch_clone_command)
        
        print(subprocess.check_output(source_branch_clone_command, cwd = git_rpm_install_tmp_dir, stderr=subprocess.STDOUT, shell=False))
        
        print(os.system('ls %s' %source_repo_path))

    
        LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY" #For logging
        log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
        log_details_list.append(log_details)
        
        #CLONE THE REMOTE GIT REPOSITORY FROM TARGET BRANCH
        TASK = 'CLONE TARGET BRANCH-- ' + deploy_target_branch
        
        target_branch_clone_command = ['git', 'clone', '--branch', deploy_target_branch, push_url, git_repo_clone_target_dir]
        print("source_branch_clone_command: ", target_branch_clone_command)
        
        print(subprocess.check_output(target_branch_clone_command, cwd = git_rpm_install_tmp_dir, stderr=subprocess.STDOUT, shell=False))
        
        print(os.system('ls %s' %target_repo_path))
        
        
            
        LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY" #For logging
        log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
        log_details_list.append(log_details)    
    
        
        #READING TRACKER CONTENTS
        TASK = 'READING TRACKER FILE CONTENTS'
        with open('%s/%s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_source_dir,cp_tracker_name),'r') as tracker:
            tracker_contains = tracker.read()
    
        tracker_rows =  tracker_contains.splitlines()
        
        TASK = 'CREATING GIT ENV ITEMS TRANSFORMATION LIST FROM TRACKER'
        transformation_item_list = list(filter(lambda transformation_list_filter_items: git_env_matching_expression in transformation_list_filter_items, tracker_rows))
        print(transformation_item_list)
        
        TASK = 'CREATING GLUE ITEMS TRANSFORMATION LIST FROM TRACKER'
        glue_transformation_item_list = list(filter(lambda glue_transformation_list_filter_items: 'Glue/' in glue_transformation_list_filter_items, transformation_item_list))
        print(glue_transformation_item_list)
        
        TASK = 'CREATING AIRFLOW ITEMS TRANSFORMATION LIST FROM TRACKER'
        airflow_transformation_item_list = list(filter(lambda airflow_transformation_list_filter_items: 'Airflow/' in airflow_transformation_list_filter_items, transformation_item_list))
        print(airflow_transformation_item_list)
        
        TASK = 'CREATING NOTIFICATION ITEMS TRANSFORMATION LIST FROM TRACKER'
        notification_transformation_item_list = list(filter(lambda notification_transformation_list_filter_items: 'Notification/' in notification_transformation_list_filter_items, transformation_item_list))
        print(notification_transformation_item_list)
        
        #CREATION OF UNIQUE FOLDER STRUCTURE LIST, for wasting less time to recreate same folder multiple time, but still some of folder creation action will be done few times, result in a warning
        TASK = 'CREATING GIT BRANCH ENV SPECIFIC FOLDER STRUCTURE LIST FROM TRACKER'
        for transformation_list_items in transformation_item_list:
            transformation_file_path_list = transformation_list_items.split(',')
            transformation_file_path = transformation_file_path_list[0]
            transformation_items_folder_structure = transformation_file_path.rsplit('/',1)[0]
            if transformation_items_folder_structure not in unique_folder_structure_list:
                unique_folder_structure_list.append(transformation_items_folder_structure)
        print(unique_folder_structure_list)
        
        TASK = 'FOLDER STRUCTURE CREATION IN TARGET BRANCH DIRECTORY'
        for folder_struct in unique_folder_structure_list:
            folder_structure_in_tracker = folder_struct.split('/')
            folder_structure = folder_structure_in_tracker[0]
            
            print(os.system("cd %s && mkdir %s" % (target_repo_path,folder_structure))) #Creating the outer most folder of the folder path in the Target repo folder
            #Creation of all sub folders under the outer most folders one by one, each inside the previous one        
            for folder_name in folder_structure_in_tracker[1:]:
                print(os.system("cd %s%s && mkdir %s" % (target_repo_path,folder_structure,folder_name)))
                folder_structure = folder_structure + "/" + folder_name
                print(folder_structure)
        
        TASK= 'CREATING LIST OF ITEMS WHERE ENV OR ACTION IS WRONG'
        wrong_env_recon_list = []
        for tracker_each_line in tracker_rows[1:]:
            tracker_item_cols = tracker_each_line.split(',')
            if tracker_item_cols[2] not in ['dev','dev-qa','dev-qa-prod']:
                tracker_wrong_env_items_list.append(tracker_each_line)
                wrong_env_recon_list.append(tracker_item_cols[0])
            if tracker_item_cols[1].lower() not in ['upload','delete']:
                tracker_wrong_action_items_list.append(tracker_each_line)
        print(tracker_wrong_env_items_list)
        tracker_wrong_env_items_list_text = '/n'.join(tracker_wrong_env_items_list)
        print(tracker_wrong_action_items_list)
        tracker_wrong_action_items_list_text = '/n'.join(tracker_wrong_action_items_list)
        
        if len(tracker_wrong_env_items_list) != 0 or len(tracker_wrong_action_items_list) != 0:
            TASK = 'TRACKER CONTENTS PRECHECK VALIDATION'
            LOG_TYPE = 'ERROR'
            LOG_MSG = TASK + ' FAILED DUE TO WRONG TRACKER CONTENTS'
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            log_details_list.append(log_details)       
            
        #TRANSFORMATION OPERATION FOR GLUE ITEMS
        for glue_items in glue_transformation_item_list:
            TASK = 'TRANSFORMATION OPERATION FOR GLUE FILES'
            print(glue_items)
            glue_list_cols = glue_items.split(",")
            glue_file_full_path = glue_list_cols[0] #full path of the files mentioned in the tracker   
            glue_file_name = glue_file_full_path.split('/')[-1]
            glue_file_full_path_source_repo = source_repo_path + glue_file_full_path
            glue_file_full_path_target_repo = target_repo_path + glue_file_full_path
            
            if glue_list_cols[1].lower() == tracker_upload_action:
                #TRANSFORMATIONS FOR SQL FILES
                if glue_file_name.find('.sql') == -1:
                    print("Transformation not required for the SQL file-- %s" % glue_file_full_path)
                    print('---------------------------------------------------------------------------------------------')
                    
                #TRANSFORMATIONS FOR INI FILES
                if glue_file_name.find('.ini') != -1:
                    print("File to modify is-- %s" % glue_file_full_path)
                    parameter_transform(glue_file_full_path_source_repo,**ini_parameters_dict)
                    print('---------------------------------------------------------------------------------------------')
            
                print(os.system("'cp' -r %s %s" % (glue_file_full_path_source_repo,glue_file_full_path_target_repo)))
                print('---------------------------------------------------------------------------------------------')
                
                #FILE_NAME TRANSFORMATIONS FOR PY FILES
                if len(glue_file_full_path.split('/')) > 2 and glue_file_full_path.split('/')[-2].lower()== 'glue-jobs' and glue_file_name.find('.py') != -1:
                    print("File name to modify is-- %s" % glue_file_full_path)
                    print('---------------------------------------------------------------------------------------------')
                    print(glue_file_full_path[-2])
                    new_glue_job_file_name = glue_file_name.replace(list(gluejob_file_suffix_transform_dict.items())[0][0],list(gluejob_file_suffix_transform_dict.items())[0][1]).replace(list(gluejob_file_suffix_transform_dict.items())[0][0].lower(),list(gluejob_file_suffix_transform_dict.items())[0][1].lower()).replace(list(gluejob_file_suffix_transform_dict.items())[0][0].upper(),list(gluejob_file_suffix_transform_dict.items())[0][1].upper())
                    new_glue_job_file_path = glue_file_full_path.rsplit('/', 1)[0] + '/' + new_glue_job_file_name
                    print(new_glue_job_file_path)
                    
                    print(os.system("'cp' -r %s %s%s" % (glue_file_full_path_source_repo,target_repo_path,new_glue_job_file_path)))
                    print(os.system("rm %s" % glue_file_full_path_target_repo))
                    print('---------------------------------------------------------------------------------------------')
                
            if glue_list_cols[1].lower() == tracker_delete_action:
                if len(glue_file_full_path.split('/')) > 2 and glue_file_full_path.split('/')[-2].lower()== 'glue-jobs' and glue_file_name.find('.py') != -1:
                    new_glue_job_file_name = glue_file_name.replace(list(gluejob_file_suffix_transform_dict.items())[0][0],list(gluejob_file_suffix_transform_dict.items())[0][1]).replace(list(gluejob_file_suffix_transform_dict.items())[0][0].lower(),list(gluejob_file_suffix_transform_dict.items())[0][1].lower()).replace(list(gluejob_file_suffix_transform_dict.items())[0][0].upper(),list(gluejob_file_suffix_transform_dict.items())[0][1].upper())
                    new_glue_job_file_path = glue_file_full_path.rsplit('/', 1)[0] + '/' + new_glue_job_file_name
                    print(os.system('rm %s%s'% (target_repo_path,new_glue_job_file_path)))
                else:
                    print(os.system('rm %s'% glue_file_full_path_target_repo))
                
        #CONTENT AND FILE_NAME MODIFICATIONS FOR AIRFLOW FILES
        for airflow_items in airflow_transformation_item_list:
            TASK = 'TRANSFORMATION OPERATION FOR AIRFLOW FILES'
            print(airflow_items)
            airflow_list_cols = airflow_items.split(",")
            airflow_file_full_path = airflow_list_cols[0] #full path of the files mentioned in the tracker   
            airflow_folder_struct = airflow_file_full_path.split('/')
            airflow_folder_structure = airflow_file_full_path.rsplit('/',1)[0]
            airflow_file_name = airflow_file_full_path.rsplit('/',1)[1]
            airflow_file_full_path_source_repo = source_repo_path + airflow_file_full_path
            airflow_file_full_path_target_repo = target_repo_path + airflow_file_full_path
            
            if airflow_list_cols[1].lower() == tracker_upload_action:
                if len(airflow_folder_struct) < 4 and airflow_folder_struct[-2].strip() == 'DAGs':
                    print("File to modify is-- %s" % airflow_file_full_path)
                    print('---------------------------------------------------------------------------------------------')
                    new_airflow_file = airflow_file_name.replace(list(airflow_file_suffix_transform_dict.items())[0][0],list(airflow_file_suffix_transform_dict.items())[0][1]).replace(list(airflow_file_suffix_transform_dict.items())[0][0].lower(),list(airflow_file_suffix_transform_dict.items())[0][1].lower()).replace(list(airflow_file_suffix_transform_dict.items())[0][0].upper(),list(airflow_file_suffix_transform_dict.items())[0][1].upper())
                    new_airflow_file_name = airflow_folder_structure + '/' + new_airflow_file
                    print(new_airflow_file_name)
                    DAG_name = airflow_file_name.split('.')[0]
                    new_DAG_name = new_airflow_file.split('.')[0]
                    DAG_parameter_dict = {DAG_name:new_DAG_name}
                    parameter_transform(airflow_file_full_path_source_repo,**DAG_parameter_dict)
                    parameter_transform(airflow_file_full_path_source_repo,**airflow_parameters_dict)
                    
                    print(os.system("'cp' -r %s %s%s" % (airflow_file_full_path_source_repo,target_repo_path,new_airflow_file_name)))
                    print(os.system("rm %s" % airflow_file_full_path_target_repo))
                    print('---------------------------------------------------------------------------------------------')
                    
                elif len(airflow_folder_struct) > 3 and airflow_folder_struct[-3].strip() == 'DAGs' and airflow_folder_struct[-2].strip() == 'utils':
                    parameter_transform(airflow_file_full_path_source_repo,**airflow_parameters_dict)
                
                    print(os.system("'cp' -r %s %s" % (airflow_file_full_path_source_repo,airflow_file_full_path_target_repo)))
                    print('---------------------------------------------------------------------------------------------')
                    
                else:
                    new_airflow_file_name = airflow_file_full_path
                    print(new_airflow_file_name)
                
                    print(os.system("'cp' -r %s %s" % (airflow_file_full_path_source_repo,airflow_file_full_path_target_repo)))
                    print('---------------------------------------------------------------------------------------------')
            
            if airflow_list_cols[1].lower() == tracker_delete_action:
                if len(airflow_folder_struct) < 4 and airflow_folder_struct[-2].strip() == 'DAGs':
                    new_airflow_file = airflow_file_name.replace(list(airflow_file_suffix_transform_dict.items())[0][0],list(airflow_file_suffix_transform_dict.items())[0][1]).replace(list(airflow_file_suffix_transform_dict.items())[0][0].lower(),list(airflow_file_suffix_transform_dict.items())[0][1].lower()).replace(list(airflow_file_suffix_transform_dict.items())[0][0].upper(),list(airflow_file_suffix_transform_dict.items())[0][1].upper())
                    new_airflow_file_name = airflow_folder_structure + '/' + new_airflow_file
                    print(os.system('rm %s%s' % (target_repo_path,new_airflow_file_name)))
                    
                else:
                    print(os.system('rm %s' % airflow_file_full_path_target_repo))

        #TRANSFORMATION OPERATION FOR NOTIFICATION ITEMS
        for notification_items in notification_transformation_item_list:
            TASK = 'TRANSFORMATION OPERATION FOR NOTIFICATION FILES'
            print(notification_items)
            notification_list_cols = notification_items.split(",")
            notification_file_full_path = notification_list_cols[0] #full path of the files mentioned in the tracker   
            notification_file_name = notification_file_full_path.split('/')[-1]
            notification_file_full_path_source_repo = source_repo_path + notification_file_full_path
            notification_file_full_path_target_repo = target_repo_path + notification_file_full_path
            if notification_list_cols[1].lower() == tracker_upload_action:
                #TRANSFORMATIONS TO BE OVERLOOKED FOR SQL FILES
                if notification_file_name.find('.sql') == -1:
                    print("Transformation not required for the SQL file-- %s" % notification_file_full_path)
                    print('---------------------------------------------------------------------------------------------')
                    
                print(os.system("'cp' -r %s %s" % (notification_file_full_path_source_repo,notification_file_full_path_target_repo)))
                print('---------------------------------------------------------------------------------------------') 
     
                #TRANSFORMATIONS FOR JSON FILES
                if notification_file_name.find('.json') != -1:
                    print("File to modify is-- %s" % notification_file_full_path)
                    
                print(os.system("'cp' -r %s %s" % (notification_file_full_path_source_repo,notification_file_full_path_target_repo)))
                print('---------------------------------------------------------------------------------------------')
                
            if notification_list_cols[1].lower() == tracker_delete_action:
                print(os.system('rm %s'% notification_file_full_path_target_repo))
            
                
        #TRACKER CONTENTS TO BE MODIFIED
        TASK = 'TRACKER CONTENTS MODIFICATION'
        tracker_contents = open('%s%s' % (source_repo_path,cp_tracker_name),'r').read()
        content = tracker_contents.splitlines()
        new_content=""
        for ln in content:
            tracker_cols=ln.split(",")
            folder_struct_in_tracker = tracker_cols[0].split('/')
            if tracker_cols[0].split('/')[0].lower() == 'airflow' and len(tracker_cols[0].split('/')) < 4 and tracker_cols[0].split('/')[-2].strip() == 'DAGs':
                tracker_file_name_modified = tracker_cols[0].replace(list(airflow_file_suffix_transform_dict.items())[0][0],list(airflow_file_suffix_transform_dict.items())[0][1]).replace(list(airflow_file_suffix_transform_dict.items())[0][0].lower(),list(airflow_file_suffix_transform_dict.items())[0][1].lower()).replace(list(airflow_file_suffix_transform_dict.items())[0][0].upper(),list(airflow_file_suffix_transform_dict.items())[0][1].upper())
                tracker_cols[0] = tracker_file_name_modified

            elif folder_struct_in_tracker[0].lower() == 'glue' and len(folder_struct_in_tracker) > 2 and folder_struct_in_tracker[-2].lower()== 'glue-jobs' and folder_struct_in_tracker[-1].find('.py') != 1:
                tracker_file_name_modified = tracker_cols[0].replace(list(gluejob_file_suffix_transform_dict.items())[0][0],list(gluejob_file_suffix_transform_dict.items())[0][1]).replace(list(gluejob_file_suffix_transform_dict.items())[0][0].lower(),list(gluejob_file_suffix_transform_dict.items())[0][1].lower()).replace(list(gluejob_file_suffix_transform_dict.items())[0][0].upper(),list(gluejob_file_suffix_transform_dict.items())[0][1].upper())
                tracker_cols[0] = tracker_file_name_modified
            
            elif tracker_cols[0].split('/')[0].lower() == 'airflow' and len(folder_struct_in_tracker) > 3 and folder_struct_in_tracker[-3].strip() == 'DAGs' and folder_struct_in_tracker[-2].strip() == 'utils':
                tracker_cols[0] = tracker_cols[0]
                    
            else:
                tracker_cols[0] = tracker_cols[0]

            tracker_lines= tracker_cols[0]+ ',' +tracker_cols[1]+ ',' + tracker_cols[2] + ',' +tracker_cols[3]+ ',' + tracker_cols[4]
            new_tracker_files_list.append(tracker_lines)
            new_content+= tracker_lines + '\n'

        write_tracker = open('%s%s' % (source_repo_path,cp_tracker_name),'w')
        write_tracker.write(new_content)
        write_tracker.close() 
        
        TASK = 'CREATING GIT ENV ITEMS TRANSFORMATION LIST FROM TRACKER WITH MODIFIED AIRFLOW DAG FILES NAME'
        modified_transformation_item_list = list(filter(lambda modified_transformation_list_filter_items: git_env_matching_expression in modified_transformation_list_filter_items, new_tracker_files_list))
        
        print('modified_transformation_item_list',modified_transformation_item_list)
        #last_commit_id = ''
        
        IST = dateutil.tz.gettz('Asia/Kolkata')
        current_date = datetime.now(tz=IST)
        time_period_in_days = int(os.getenv('time_period_in_days_to_get_log_from_target_branch'))
        date_before_mentioned_time_period = current_date - relativedelta(days= time_period_in_days)
        date_before_mentioned_time_period_str = date_before_mentioned_time_period.strftime("%Y-%m-%d")
        print("Date before %s days from today: " % time_period_in_days + date_before_mentioned_time_period_str)
        
        TASK = 'DEFINING GIT OPERATIONS'
        EXEC_START_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
        
        git_branch = ['git', 'branch','-a'] #Command to find the current git branch
        git_status = ['git', 'status'] #Command to show git status
        config_email = ['git', 'config', '--global', 'user.email', "Ritesh.Dedhia@warnerbros.com"] #Git command to configure user email
        config_name = ['git', 'config', '--global', 'user.name' , "Ritesh Dedhia"] #Git command to configure user name
        
        
        TASK = 'DEFINING ADD COMMIT PUSH FUNCTION'
        
        git_add_commit_delay = int(os.getenv('git_add_commit_delay'))
        def git_add_commit(git_directory_of_the_file):
            git_add = ['git', 'add', '--all'] #Git command to add file to stage area
            git_commit = ['git', 'commit', '-m', "files are modified"] #Git command to commit staged file
            git_unstage = ['git', 'rm', '-r', '--cached', '.']
            
            print(subprocess.Popen(git_unstage , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file)))
            print('---------------------------------------------------------------------------------------------')
            time.sleep(5)            
            print(subprocess.Popen(git_add , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file))) #Running the git command using subprocess
            print('---------------------------------------------------------------------------------------------')
            time.sleep(git_add_commit_delay)
            print(subprocess.Popen(git_commit , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_directory_of_the_file)))
            print('---------------------------------------------------------------------------------------------')
            
        
        TASK = 'PERFORMING BASIC GIT OPERATIONS'
        print(subprocess.Popen(git_branch , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
        print('---------------------------------------------------------------------------------------------')
        #time.sleep(2)
        print(subprocess.Popen(git_status , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
        print('---------------------------------------------------------------------------------------------')
        #time.sleep(2)
        print(subprocess.Popen(config_email , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
        print('---------------------------------------------------------------------------------------------')
        #time.sleep(2)
        print(subprocess.Popen(config_name , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
        print('---------------------------------------------------------------------------------------------')
        #time.sleep(2)
        print(subprocess.Popen(['git','remote','add','origin2',push_url], cwd='%s/%s' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir))) # Adding new remote server origin2 to the repo
        print('---------------------------------------------------------------------------------------------')
        #time.sleep(2)
        
        TASK = 'GIT DEPLOYMENT OF TRACKER'
        print(os.system("'cp' -r %s%s %s%s" % (source_repo_path,cp_tracker_name,target_repo_path,cp_tracker_name))) #Copy the tracker into the target branch
        
        TASK = 'GIT DEPLOYMENT OF HIGHER ENV FILES MENTIONED IN TRACKER'
        comparison_list = []
        Deployed_items = ''
        source_checksum_dict = {}
        target_checksum_dict = {}
        
        modified_transformation_item_list_upload = list(filter(lambda modified_transformation_list_filter_items: tracker_upload_action in modified_transformation_list_filter_items, modified_transformation_item_list))
        print('modified_transformation_item_list with upload action: ',modified_transformation_item_list_upload)
        
        for transformation_objects in modified_transformation_item_list_upload: # Looping for the files to deploy in the higher git branch
            transformation_object_lines = transformation_objects.split(',')
            TASK = 'GIT DEPLOYMENT OF THE FILE - ' + transformation_object_lines[0]
     
            #Generating Dictionary of file_name:hash_value from target branch
            files = transformation_object_lines[0]
            source_checksum_dict = checksum_gen(target_repo_path, files, source_checksum_dict)   
                
        git_add_commit(git_repo_clone_target_dir)
        
        time.sleep(5)        
        git_push = ['git', 'push', 'origin2',deploy_target_branch] #Git command to push commited file
        print(subprocess.call(git_push , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
        print('---------------------------------------------------------------------------------------------')
        time.sleep(5)
            
        #CLONE THE REMOTE GIT REPOSITORY FROM SOURCE BRANCH
        TASK = 'GENERATING COMPARISON LIST and DEPLOYED ITEMS LIST '
        git_checksum_repo_clone_target_dir = 'target_checksum_clone'
        Deployed_items,comparison_list = comparison_list_gen(push_url,deploy_target_branch,source_checksum_dict,target_checksum_dict,modified_transformation_item_list_upload,git_rpm_install_tmp_dir,comparison_list,Deployed_items,git_checksum_repo_clone_target_dir)
        
        print("Final Comparison list: \n")
        print(comparison_list)
        
        names_of_successfull_deployed_object = names_of_successfull_deployed_object + Deployed_items + '\n' #For logging
        
        TASK = 'RETRY TO PUSH THOSE FILES WHICH WERE FAILED TO DEPLOY FOR THE FIRST TIME'
        for failed_items in comparison_list:
            print("The file to add to the next higher branch for another try is: " + failed_items)

        if len(comparison_list) != 0:
        
            git_add_commit(git_repo_clone_target_dir)
            
            time.sleep(2)
            git_push = ['git', 'push', 'origin2',deploy_target_branch] #Git command to push commited file
            print(subprocess.call(git_push , cwd='%s/%s/' % (git_rpm_install_tmp_dir,git_repo_clone_target_dir)))
            print('---------------------------------------------------------------------------------------------')
            time.sleep(5)
            
            comparison_list = []
            Deployed_items = ''
            target_checksum_dict = {}
                
            #CLONE THE REMOTE GIT REPOSITORY FROM TARGET BRANCH
            TASK = 'GENERATING COMPARISON LIST and DEPLOYED ITEMS LIST FOR REDEPLOYMENT '
            git_checksum_repo_clone_target_dir = 'target_redeploy_checksum_clone'
            Deployed_items,comparison_list = comparison_list_gen(push_url,deploy_target_branch,source_checksum_dict,target_checksum_dict,modified_transformation_item_list_upload,git_rpm_install_tmp_dir,comparison_list,Deployed_items,git_checksum_repo_clone_target_dir)
        
            print("Final Comparison list: \n")
            print(comparison_list)
        
        reconciliation_objects_text_head = '\n\n\nFiles present in tracker but not deployed to the higher branch are: \n\n'
        reconciliation_objects_text_tail = ''
        names_of_successfull_deployed_object = 'Final list of deployed items: \n' + '\n' + Deployed_items + '\n' #For logging 
        comparison_list += wrong_env_recon_list
        
        for comparison_list_objects in comparison_list:
            reconciliation_objects_text_tail = reconciliation_objects_text_tail + comparison_list_objects + '\n'
            
        reconciliation_objects_text = reconciliation_objects_text_head + reconciliation_objects_text_tail
        
        if len(comparison_list) == 0: #If the comparison list is empty the SUCCESS
            TASK = 'DEPLOY FILES TO THE BRANCH - ' + deploy_target_branch + ' & RECON ACTIVITY: FINAL COMPARISON BETWEEN DEPLOYED FILES LIST AND TRACKER FILES'
            LOG_MSG = TASK + " --COMPLETED SUCCESSFULLY"
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            EXEC_END_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
            lambda_invoke('LOG',BATCH_ID, lambda_function_name, source_clone_branch_name, deploy_target_branch, parameters, 'Git Branch Deployment Completed Sucessfully', Deployed_items, reconciliation_objects_text_tail, EXEC_START_TIME, EXEC_END_TIME)
            log_details_list.append(log_details)

        else: #If the comparison list is not null then ERROR
            TASK = 'RECON ACTIVITY: FINAL COMPARISON BETWEEN DEPLOYED FILES LIST AND TRACKER FILES'
            LOG_TYPE = 'ERROR'
            LOG_MSG = TASK + ' FAILED DUE TO (RECONCILIATION VALIDATION ERROR) : \n' + reconciliation_objects_text_tail + 'is/are not deployed to ' + deploy_target_branch
            log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
            EXEC_END_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
            lambda_invoke('RECON_ERROR',BATCH_ID, lambda_function_name, source_clone_branch_name, deploy_target_branch, parameters, 'Git Branch Deployment Failed', Deployed_items, reconciliation_objects_text_tail, EXEC_START_TIME, EXEC_END_TIME)
            log_details_list.append(log_details)
            
    except Exception as err:
       LOG_TYPE = 'ERROR'
       LOG_MSG = TASK + ' --FAILED DUE TO: ' + str(err)
       print(LOG_MSG)
       log_details = {'TASK': TASK, 'LOG_TYPE' : LOG_TYPE, 'LOG_MSG': LOG_MSG, 'names_of_successfull_deployed_object':names_of_successfull_deployed_object,'env_specific_files_text':env_specific_files_text,'reconciliation_objects_text':reconciliation_objects_text}
       EXEC_END_TIME = datetime.now(tz=IST).strftime("%Y-%m-%d")+ datetime.now(tz=IST).strftime(" %H:%M:%S")
       lambda_invoke(LOG_TYPE,BATCH_ID, lambda_function_name, source_clone_branch_name, deploy_target_branch, parameters, LOG_MSG, names_of_successfull_deployed_object, comparison_list, EXEC_START_TIME, EXEC_END_TIME)
       log_details_list.append(log_details) 
           
    logger(lambda_function_name, parameters, log_details_list, tracker_contents, tracker_wrong_env_items_list_text, tracker_wrong_action_items_list_text) #Calling the logger function

if __name__ == '__main__':
    input_args = ast.literal_eval(sys.argv[1])
    lambda_handler(input_args)
