import json
import sys
import os
import urllib
import boto3
from datetime import datetime
import dateutil

def logger(lambda_function_name, parameters, log_details_list, tracker_contents, tracker_wrong_env_items_list_text, tracker_wrong_action_items_list_text):

    s3_client = boto3.client('s3',aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
                      aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'))

    IST = dateutil.tz.gettz('Asia/Kolkata')
    current_time = datetime.now(tz=IST).strftime("%H:%M:%S")
    current_date = datetime.now(tz=IST).strftime("%Y%m%d")

    print("The parameters are: " + parameters)
    try:
        
        CICD_audit_file_name = 'cicd_audit_logger'

        audit_log_file_contents = 'FUNCTION NAME: %s \n\nWORKFLOW PARAMETERS: %s \n\nTRACKER FILE CONTENTS: \n%s\n\nITEMS WITH WRONG ENVIRONMENT MENTIONED IN TRACKER: \n %s\n\nITEMS WITH WRONG ACTION MENTIONED IN TRACKER: \n %s\n\n\n' % (lambda_function_name,parameters,tracker_contents,tracker_wrong_env_items_list_text,tracker_wrong_action_items_list_text)   

        for log_details_dicts in log_details_list:
            if 'FILES TO AWS' in log_details_dicts['TASK']:       
                names_of_successfull_deployed_object_text = log_details_dicts['names_of_successfull_deployed_object']
                final_comparison_list_of_deployed_objects = 'The files present in tracker but not deployed to AWS environment are: \n\n' +log_details_dicts['reconciliation_objects_text']
            
            if 'RECON ACTIVITY: FINAL COMPARISON BETWEEN DEPLOYED FILES LIST AND TRACKER FILES' in log_details_dicts['TASK']:
                names_of_successfull_deployed_object_text = log_details_dicts['names_of_successfull_deployed_object']
                final_comparison_list_of_deployed_objects = 'Files not deployed to the higher branch on the first push, but deployed with the re-run are: \n\n' +log_details_dicts['reconciliation_objects_text']
            
            if 'RESET TRACKER IN DEV BRANCH' in log_details_dicts['TASK']:
                names_of_successfull_deployed_object_text = log_details_dicts['names_of_successfull_deployed_object']
                final_comparison_list_of_deployed_objects = 'File not updated: \n\n' +log_details_dicts['reconciliation_objects_text']
                
            if 'FILES TO AWS' not in log_details_dicts['TASK'] and 'RECON ACTIVITY: FINAL COMPARISON BETWEEN DEPLOYED FILES LIST AND TRACKER FILES' not in log_details_dicts['TASK'] and 'RESET TRACKER IN DEV BRANCH' not in log_details_dicts['TASK']:
                names_of_successfull_deployed_object_text = ''
                final_comparison_list_of_deployed_objects = ''
            
            if 'FILES TO AWS' in log_details_dicts['TASK']:        
                expected_files_to_deploy_in_aws_env = 'THE FILES TO BE DEPLOYED IN THE AWS  ENVIRONMENT: \n\n' + log_details_dicts['env_specific_files_text']
                
            else:
                env_specific_files_text = ''
                expected_files_to_deploy_in_aws_env = ''
                
            audit_log_file_contents = audit_log_file_contents + 'TASK DESCRIPTION: %s' % log_details_dicts['TASK']+ '\n\n' + 'LOG MESSAGE: %s' % log_details_dicts['LOG_MSG'] + '\n\n' +  expected_files_to_deploy_in_aws_env + '\n\n' +names_of_successfull_deployed_object_text + '\n\n' + final_comparison_list_of_deployed_objects + '\n\n' +'--------------------------------------------------------------------'+ '\n\n'

    
        audit_logger_file_name_in_s3 = lambda_function_name + '_' + current_time + '.txt'
    
        print(os.system('cd /tmp/ && touch %s' % CICD_audit_file_name))
        with open('/tmp/%s' % CICD_audit_file_name, 'w+') as logger_contents:
            logger_contents.write(audit_log_file_contents)
            logger_contents.close()
            
        if next((dicts for dicts in log_details_list if dicts['LOG_TYPE'] == 'ERROR'),'no error found') == 'no error found':
            s3_client.upload_file("/tmp/%s" % CICD_audit_file_name, "cp-cicd-audit-qa", "CICD_LOGs/%s/%s" % (current_date,audit_logger_file_name_in_s3))
            
        else:
            s3_client.upload_file("/tmp/%s" % CICD_audit_file_name, "cp-cicd-audit-qa", "CICD_ERRORs/%s/%s" % (current_date,audit_logger_file_name_in_s3))
        
    
    except Exception as err:
        print("Unable to log details for the Lambda Function " + lambda_function_name + ": " + str(err))