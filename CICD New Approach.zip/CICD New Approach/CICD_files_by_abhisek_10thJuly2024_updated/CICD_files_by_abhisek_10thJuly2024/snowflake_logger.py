import sys
import os
from os import path
import json
import boto3

snowflake_logger_arn = os.getenv('snowflake_logger_arn')
def lambda_invoke(LOG_TYPE,BATCH_ID, Lambda_Function, Source_Branch, Deploy_Target_Branch, PARAMETERS, LOG_MESSAGE, DEPLOYED_ITEMS, OBJECT_DEPLOY_FAIL_LIST, EXEC_START_TIME, EXEC_END_TIME):
    client = boto3.client('lambda', aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'), aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'))
    inputParams = {
    "LOG_TYPE": LOG_TYPE,
    "BATCH_ID": BATCH_ID,
    "Lambda_Function": Lambda_Function,
    "Source_Branch": Source_Branch,
    "Deploy_Target_Branch": Deploy_Target_Branch,
    "PARAMETERS": PARAMETERS,
    "LOG_MESSAGE": LOG_MESSAGE, 
    "DEPLOYED_ITEMS": DEPLOYED_ITEMS,
    "OBJECT_DEPLOY_FAIL_LIST": OBJECT_DEPLOY_FAIL_LIST,
    "EXEC_START_TIME": EXEC_START_TIME,	
    "EXEC_END_TIME": EXEC_END_TIME
    }
    response = client.invoke(
    FunctionName = snowflake_logger_arn,
    InvocationType = 'RequestResponse',
    Payload = json.dumps(inputParams)
    )
    invoke = json.load(response['Payload'])
    print(invoke)